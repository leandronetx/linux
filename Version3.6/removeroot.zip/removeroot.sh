#!/bin/bash
touch /var/log/rootmaillog;
array=($(mailq | tail -n +2 | awk 'BEGIN { RS = "" } / root@'+`hostname`+'$/ { print $1 }'));
for i in ${array[@]}; do /usr/sbin/postcat -q $i >> /var/log/rootmaillog; echo "==============================================" >> maillog.log; /usr/sbin/postsuper -d $i; done;