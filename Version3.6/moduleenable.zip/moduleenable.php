<?php
require('/etc/sentora/panel/cnf/db.php');
$servername = $host;
$username = $user;
$password = $pass;
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('1', 'Change Appearance ', '1','change_appearance','user','you will customize the appearance of our cntrol panel','true')";

if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('1','$last_id')";
 $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('6', 'Autoresponder', '1','autoresponder','user','You can use autoresponders to automatically send a message back to anyone who sends an email to a specified account. ','true')";

if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
 $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES ('3', 'IP Domain', '1','ipdomain','user','We will change the appearance of IP ','true')";

if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('1','$last_id')";
 $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('5', 'SSL', '1','ssl','user','This module was helpful to create a SSL certification. ','true')";

if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
 $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('3', 'Name Server', '1','ns','user','This module was helpful to assign the name server. ','true')";

if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('1','$last_id')";
 $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('10', 'VirusScanner', '1','virusscanner','user','This module was helpful  for detecting trojans, viruses, malware & other malicious threats.','true')";

if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
 $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('6', 'Authentication', '1','authentication','user','Using this module you have the ability to create DKIM and SPF.','true')";

if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
 $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('2', 'Domain Forwarder', '1','domain_forwarder','user','This module enables you to setup and manage domain forwards.','true')";
if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
 $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('3', 'Account Level Filter', '1','account_filter','user','Account Level Filter enables you to add  rules to match subjects, addresses, or other parts of the message. You can then add  actions to take on a message such as to deliver the message to a different address and then discard it.','true')";
if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
 $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('10', 'CSF', '1','csf','user',' ConfigServer Security & Firewall .','true')";
if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('1','$last_id')";
 $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('0', 'Email Routing', '1','email_routing','modadmin',' Email Routing','true')";
if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
  $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('1','$last_id')";
  $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
} 

$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('5', 'CSR', '1','csr','user','This module was helpful to create a CSR certification.','true')";
if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
  $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
  $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
} 

$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('1', 'Server Time', '1','servertime','user','To ensure consistency, we strongly recommend that you reboot the server after you change the time zone.','true')";
if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
  $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('1','$last_id')";
  $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
} 


//*****************

$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('2', 'Addmime', '1','addmime','user','This module will give  information  about extension present in server','true')";
if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
 $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('1','$last_id')";
  $conn->query($sql);
  $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
  $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
} 


$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('6', 'Maillogtrack', '1','maillogtrack','user','This module provides mail log history details  ','true')";
if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
  $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
  $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
} 

$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('2', 'PHPmodule', '1','phpmodule','user','This module is helpful to install  PHP packages ','true')";
if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
  $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('1','$last_id')";
  $conn->query($sql);
  $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
  $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
} 

$sql = "INSERT INTO `x_modules` ( `mo_category_fk`, `mo_name_vc`, `mo_version_in`, `mo_folder_vc`, `mo_type_en`, `mo_desc_tx`,  `mo_enabled_en`) VALUES 
								('3', 'Apache status', '1','server-status','user','This module is helpful to show the apache full status ','true')";
if ($conn->query($sql) === TRUE) {
 $last_id = $conn->insert_id;
 $sql="DELETE FROM `x_permissions` WHERE `pe_module_fk`='$last_id'";
 $conn->query($sql);
  $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('1','$last_id')";
  $conn->query($sql);
  $sql="INSERT INTO `x_permissions`(`pe_group_fk`, `pe_module_fk`) VALUES ('3','$last_id')";
  $conn->query($sql);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

//*****************

$sql = "UPDATE `x_modules` SET mo_enabled_en='false' where mo_folder_vc='theme_manager'";
$conn->query($sql);
/* $sql = "UPDATE `x_modules` SET mo_enabled_en='false' where mo_folder_vc='csf'";
$conn->query($sql);
*/
 $sql = "UPDATE `x_modules` SET mo_enabled_en='true' where mo_folder_vc='webalizer_stats'";
 $conn->query($sql);
$conn->close();
?>
