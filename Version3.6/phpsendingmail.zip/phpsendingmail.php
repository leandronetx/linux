<?php 
function get_client_ip() {
   // return $_SERVER['SERVER_ADDR'];
$iparr=shell_exec("/bin/hostname -I");
$ip=array();
$ip=explode(" ",$iparr);
 return $ip[1];
}
  require('/etc/sentora/panel/cnf/db.php');
  $con = mysql_connect($host, $user, $pass) or  die("Could not connect: " . mysql_error());  
  mysql_select_db($dbname);  
  $result = mysql_query("select * from x_last_mail_exceed where x_date='".date("d/m/Y")."'");  
	if(mysql_num_rows($result)==0)
	{
		$to = 'akshith@hostingraja.in,arief@hostingraja.in,dinesh.m@hostingraja.in';
        //$to = 'sathiyasaravanababu91@gmail.com';
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From: Ticket Response List <saravana@hostingraja.in>' . "\r\n";
        $message = " Mail queue exceeded in the IP Address - ".get_client_ip();
                
        $subject = "Mail Queue exceeded - ".get_client_ip();
        mail($to, $subject, $message);
		$result = mysql_query("Update x_last_mail_exceed SET x_date='".date("d/m/Y")."'");  
	}
mysql_close($con);  
?>
