<?php
if($argc!==2)
{
	echo "could you please pass the parameters correctly.";
	exit();
}
require('/etc/sentora/panel/cnf/db.php');
include('/etc/sentora/panel/dryden/db/driver.class.php');
include('/etc/sentora/panel/dryden/debug/logger.class.php');
include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
include('/etc/sentora/panel/dryden/runtime/hook.class.php');
include('/etc/sentora/panel/dryden/sys/versions.class.php');
include('/etc/sentora/panel/dryden/ctrl/options.class.php');
include('/etc/sentora/panel/dryden/fs/director.class.php');
include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
include('/etc/sentora/panel/inc/dbc.inc.php');
try 
{
//     $zdbh = new db_driver("mysql:host=" . $host . ";dbname=" . $dbname . "", $user, $pass);
	$dsn = "mysql:dbname=$dbname;$ovi_socket_path";
	$zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
	$zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
exit();
}
$download=1;
if (isset($argv[1]) && $argv[1] != "") {  
	$username=trim($argv[1]);
	$rows = $zdbh->prepare("
				SELECT * FROM x_accounts 
				LEFT JOIN x_profiles ON (x_accounts.ac_id_pk=x_profiles.ud_user_fk) 
				LEFT JOIN x_groups   ON (x_accounts.ac_group_fk=x_groups.ug_id_pk) 
				LEFT JOIN x_packages ON (x_accounts.ac_package_fk=x_packages.pk_id_pk) 
				LEFT JOIN x_quotas   ON (x_accounts.ac_package_fk=x_quotas.qt_package_fk) 
				WHERE x_accounts.ac_user_vc= :ac_user_vc
				");
	$rows->bindParam(':ac_user_vc', $username);
	$rows->execute();
    $res_count = $rows->rowCount();
	if ($res_count != 0) {		
		$dbvals = $rows->fetch();
		$userid=$dbvals['ac_id_pk'];		
		$domainlist="";
		$rows = $zdbh->prepare("
					SELECT * FROM  x_vhosts 
					WHERE x_vhosts.vh_acc_fk=:ac_user_vc
		");
		$rows->bindParam(':ac_user_vc', $userid);
		$rows->execute();
        $res_count = $rows->rowCount();
		if ($res_count != 0 ) {
			$total_bk_size_in_kb=0;	
			while($dbvals = $rows->fetch())
			{
				$domainlist.=" ".$dbvals['vh_name_vc'];
				$path = "/var/sentora/vmail/".strtolower(trim($dbvals['vh_name_vc']))."/";
				$size = shell_exec("du -sc $path | cut -f1 | awk '{print $1; exit}'");
				$total_bk_size_in_kb += $size ;					 
			} 
		}
        else {
			echo "No domains Available for Mail Backup\n";
			exit;
		}
		$available_size_in_kb=(int)shell_exec("df | awk '{print $4}' | head -2 | tail -1");
        $overall_size_in_kb=(int)shell_exec("df | awk '{print $2}' | head -2 | tail -1");
	$total_bk_size_in_kb=(int)$total_bk_size_in_kb;
        if((int)$available_size_in_kb < (int)$total_bk_size_in_kb )
        {
            $msg="Due to disk space exceeed, your mail backup not working. kindly contact your administrator.";
            echo $msg;
            exit;
        }
        $remaining_kb=$available_size_in_kb - $total_bk_size_in_kb;
        $remaining_percentage = $remaining_kb / $overall_size_in_kb * 100 ;
        if($remaining_percentage < 5 )
        {
            $msg="Due to disk space exceeed, your mail backup not working. kindly contact your administrator.";
            echo $msg;
            exit;										
        }
		if ($backup = ExecuteBackup($userid, $username, $download,$domainlist)) {
			echo "backup completed.";			
		} else {			
			echo "<h2>Unauthorized Access!</h2>";
			echo "You have no permission to view this module.";			
		}
	}
	else
	{
	    echo "Username does not exists.";
	    exit();		
	}
}

function ExecuteBackup($userid, $username, $download = 0,$domainlist) {
    echo "backup Started. \n";
    shell_exec("mkdir -p /backup/$username");
	$timestampfile= date("M-d-Y_hms", time());
	$dest_path="/backup/".$username."/"."Mail_".$username . "_" .$timestampfile;
    $current_file_name="Mail_".$username . "_" . $timestampfile .".zip";
    shell_exec("echo $current_file_name > /backup/current_mail_$username");
	$src_path="/var/sentora/vmail/";
	$cmd="cd $src_path && zip -r $dest_path $domainlist 2>&1 ";
	$output=array();
	$return_val="";
	$output=passthru($cmd,$return_val);
	/* //////////////////////////////////////  symlink Creation Started ////////////////////////////////////// */
        $vhost_dir=ctrl_options::GetSystemOption('hosted_dir');
        $cmd="mkdir -p ".$vhost_dir.$username."/backups/"." &&  cd ".$vhost_dir.$username."/backups/ && ln -S ".$current_file_name." ".$dest_path.".zip";
        shell_exec($cmd);
        $wheris_chown=trim(shell_exec("whereis chown | awk '{print $2}'"));
        shell_exec("$wheris_chown -R $username:$username ".$vhost_dir.$username."/backups");
        shell_exec("chmod -R 0755 ".$vhost_dir.$username."/backups");
        shell_exec("$wheris_chown -R $username:$username /backup/".$username."/".$current_file_name);
        shell_exec("chmod -R 0755 /backup/".$username."/".$current_file_name);
        /* //////////////////////////////////////  symlink Creation End ////////////////////////////////////// */
	return TRUE;
}

?>
