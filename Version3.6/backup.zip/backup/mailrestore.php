<?php
// Filename.php username Filename
if($argc!==3)
{
	echo "could you please pass the parameters correctly.";
	exit();
}
if(!file_exists("/backup/".$argv[1]."/".$argv[2]))
{
	echo "File name does not exists in the given user backup folder";
	exit;
}
if(substr($argv[2], -3)!='zip')
{
	echo "Restore has accept only zip files";
	exit;
}
/* ///////////////////////////////////////////// Calculation start /////////////////////////////////// */
$path="/backup/".trim($argv[1])."/".trim($argv[2]);
$total_bk_size_in_kb=(int)shell_exec("unzip -l $path | tail -1 | awk '{print $1/1024}'");
$available_size_in_kb=(int)shell_exec("df | awk '{print $4}' | head -2 | tail -1");
$overall_size_in_kb=(int)shell_exec("df | awk '{print $2}' | head -2 | tail -1");
if($available_size_in_kb < $total_bk_size_in_kb )
{
	echo "Due to disk space exceeed, your restore does not working. kindly contact your administrator.";
	exit;
}
$remaining_kb=$available_size_in_kb - $total_bk_size_in_kb;
$remaining_percentage = $remaining_kb / $overall_size_in_kb * 100 ;
if($remaining_percentage < 5 )
{
	echo "Due to disk space exceeed, your restore not working. kindly contact your administrator.";
	exit;
}

/* ///////////////////////////////////////////// Calculation End /////////////////////////////////// */
require('/etc/sentora/panel/cnf/db.php');
include('/etc/sentora/panel/dryden/db/driver.class.php');
include('/etc/sentora/panel/dryden/db/mysqldriver.class.php');
include('/etc/sentora/panel/dryden/debug/logger.class.php');
include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
include('/etc/sentora/panel/dryden/runtime/hook.class.php');
include('/etc/sentora/panel/dryden/sys/versions.class.php');
include('/etc/sentora/panel/dryden/ctrl/options.class.php');
include('/etc/sentora/panel/dryden/fs/director.class.php');
include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
include('/etc/sentora/panel/inc/dbc.inc.php');
try 
{
    $dsn = "mysql:dbname=$dbname;$ovi_socket_path";
    $zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
    $zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) 
{
exit();
}
$download=1;
if (isset($argv[1]) && $argv[1] != "") { 
	$username=trim($argv[1]);
	$rows = $zdbh->prepare("SELECT a.* FROM x_accounts a,x_profiles p,x_groups g,x_packages pa,x_quotas q  WHERE a.ac_id_pk=p.ud_user_fk AND a.ac_group_fk=g.ug_id_pk AND a.ac_package_fk=pa.pk_id_pk AND a.ac_package_fk=q.qt_package_fk AND a.ac_user_vc= :ac_user_vc");
	$rows->bindParam(':ac_user_vc', $username);
	$rows->execute();
	if ($rows->fetch()) {	
		$rows = $zdbh->prepare("SELECT a.* FROM x_accounts a,x_profiles p,x_groups g,x_packages pa,x_quotas q  WHERE a.ac_id_pk=p.ud_user_fk AND a.ac_group_fk=g.ug_id_pk AND a.ac_package_fk=pa.pk_id_pk AND a.ac_package_fk=q.qt_package_fk AND a.ac_user_vc= :ac_user_vc");
        $rows->bindParam(':ac_user_vc', $username);
        $rows->execute();	
		$dbvals = $rows->fetch();
		$userid=$dbvals['ac_id_pk'];		
					
	    if ($backup = ExecuteRestore($userid, $username, $download,$argv[2])) {			
			echo "Restore completed.";			
		} else {			
    		//echo "<h2>Unauthorized Access!</h2>";
			echo "You have no permission to view this module.";			
		}
	}
	else
	{
	    echo "Username does not exists.";
	    exit();		
	}
}
function ExecuteRestore($userid, $username, $download = 0,$filename) {
    echo "Restart started. \n";
	$dest_path="/var/sentora/vmail/";
	$src_path="/backup/".$username."/";
	$cmd="cd $src_path && unzip -o $filename -d $dest_path 2>&1 ";
	$output=array();
	$return_val="";
	$output=passthru($cmd,$return_val);
	passthru("chown -R vmail:mail $dest_path");
	passthru("chmod -R 0755 $dest_path");
	return TRUE;
}

?>
