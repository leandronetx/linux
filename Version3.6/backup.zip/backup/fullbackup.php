<?php
if($argc!==2)
{
	echo "could you please pass the parameters correctly.";
	exit();
}
require('/etc/sentora/panel/cnf/db.php');
include('/etc/sentora/panel/dryden/db/driver.class.php');
include('/etc/sentora/panel/dryden/debug/logger.class.php');
include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
include('/etc/sentora/panel/dryden/runtime/hook.class.php');
include('/etc/sentora/panel/dryden/sys/versions.class.php');
include('/etc/sentora/panel/dryden/ctrl/options.class.php');
include('/etc/sentora/panel/dryden/fs/director.class.php');
include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
include('/etc/sentora/panel/inc/dbc.inc.php');
try 
{
        $dsn = "mysql:dbname=$dbname;$ovi_socket_path";
        $zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
        $zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $mysqli=mysqli_connect("localhost",$user, $pass);
} catch (PDOException $e) {
    exit();
}
$vhost_path = ctrl_options::GetSystemOption('hosted_dir');
$download=1;
if (isset($argv[1]) && $argv[1] != "") {  
	$username=trim($argv[1]);
	$rows = $zdbh->prepare("SELECT a.* FROM x_accounts a,x_profiles p,x_groups g,x_packages pa,x_quotas q 
                                WHERE a.ac_id_pk=p.ud_user_fk AND a.ac_group_fk=g.ug_id_pk AND a.ac_package_fk=pa.pk_id_pk 
                                AND a.ac_package_fk=q.qt_package_fk AND a.ac_user_vc= :ac_user_vc AND a.ac_deleted_ts is NULL");
	$rows->bindParam(':ac_user_vc', $username);
	$rows->execute();
     	$res_count = $rows->rowCount();
	if($res_count > 0) {
	//if ($rows->fetch()) {		
	//$rows = $zdbh->prepare("SELECT a.* FROM x_accounts a,x_profiles p,x_groups g,x_packages pa,x_quotas q  WHERE a.ac_id_pk=p.ud_user_fk AND a.ac_group_fk=g.ug_id_pk AND a.ac_package_fk=pa.pk_id_pk AND a.ac_package_fk=q.qt_package_fk AND a.ac_user_vc= :ac_user_vc");
        //$rows->bindParam(':ac_user_vc', $username);
        //$rows->execute();
        $dbvals = $rows->fetch();
        $userid=$dbvals['ac_id_pk'];		
        /* ////////////////////////////  Home Backup Start ///////////////////////// */						
        echo "backup Started. \n";
        $time_stamp=date("M-d-Y_hms", time());
        $dest_path="/backup/".$username."/"."Full_".$username . "_" .$time_stamp ;
        shell_exec("mkdir -p /backup/$username");
        $cur_file_name="Full_".$username . "_" . $time_stamp.".zip";		
        shell_exec("echo $cur_file_name > /backup/current_full_$username");
        $src_path=$vhost_path.$username."/";
        //$cmd="cd $src_path && zip -r $dest_path public_html 2>&1 ";
        $cmd="cd $src_path && zip -r $dest_path ./* -x ./backups/\* 2>&1 ";
        $output=array();
        $return_val="";
        $output=passthru($cmd,$return_val);    
        /* ////////////////////////////  Home Backup End ///////////////////////// */

        /* ////////////////////////////  Mysql Backup Start ///////////////////////// */
        $DBList="";
        $rows = $zdbh->prepare("
            SELECT * FROM  x_mysql_databases 
            WHERE x_mysql_databases.my_acc_fk=:ac_user_vc AND  x_mysql_databases.my_deleted_ts IS NULL
        ");
        $rows->bindParam(':ac_user_vc', $userid);
        $rows->execute();
        // $res_count = $rows->rowCount();
        if ($rows->fetch()) {

        $rows = $zdbh->prepare("SELECT * FROM  x_mysql_databases WHERE x_mysql_databases.my_acc_fk=:ac_user_vc AND  x_mysql_databases.my_deleted_ts IS NULL");
        $rows->bindParam(':ac_user_vc', $userid);
        $rows->execute();
            while($dbvals = $rows->fetch())
            {            
                if (mysqli_select_db($mysqli,$dbvals['my_name_vc'])) {
                    $DBList.=" ".$dbvals['my_name_vc'];
                }
            } 
        }
        else
        {
            echo "No Database Available for Backup\n";
        }
        if($DBList=="")
        {
            echo "No Database Available for Backup\n";
        }
        else
        {
            exec("mkdir -p ".$vhost_path.$username."/backups/mysql");
            // $dest_path="/var/sentora/hostdata/".$username."/backups/"."MySQL_".$username . "_" . date("M-d-Y_hms", time());
            $src_path=$vhost_path.$username."/backups/";
            $cmd="cd $src_path && zip -ur $dest_path mysql 2>&1 ";
            $dbname=md5(sha1($username."SQL"));
            //--single-transaction - Since I am using InnoDB tables, I will want to use this option.
            $bkcommand =" cd $vhost_path$username/backups/mysql && ".ctrl_options::GetSystemOption('mysqldump_exe')." -h ".$host." -u ".$user." -p'".$pass."' --databases $DBList > ".$dbname.".sql ";
            $output=passthru($bkcommand,$return_val);           
            $output=array();
            $return_val="";
            $output=passthru($cmd,$return_val);
            passthru(" rm -fr ".$vhost_path.$username."/backups/mysql");

        }
        /* ////////////////////////////  Mysql Backup End ///////////////////////// */	
        /* ////////////////////////////  Mail Backup Start  ///////////////////////// */	
        $domainlist="";
        $rows = $zdbh->prepare("
            SELECT * FROM  x_vhosts 
            WHERE x_vhosts.vh_acc_fk=:ac_user_vc
            ");
        $rows->bindParam(':ac_user_vc', $userid);
        $rows->execute();
        // $res_count = $rows->rowCount();
        if ($rows->fetch()) {
		$rows = $zdbh->prepare("SELECT * FROM  x_vhosts WHERE x_vhosts.vh_acc_fk=:ac_user_vc");
		$rows->bindParam(':ac_user_vc', $userid);
		$rows->execute();
            while($dbvals = $rows->fetch())
            {
                $domainlist.=" ".$dbvals['vh_name_vc'];
            }    
            $mail_zip="Mail";
            $dest_path1="/backup/".$username."/".$mail_zip;
            
            $src_path1="/var/sentora/vmail/";
            $cmd1="cd $src_path1 && zip -r $dest_path1 $domainlist 2>&1 ";
            
            
            $output=array();
            $return_val="";
            $output=passthru($cmd1,$return_val);
            $cmdfinal="cd /backup/$username/ && zip -ur $dest_path $mail_zip.zip 2>&1";
            $output=passthru($cmdfinal,$return_val);
            //exit;
            exec("rm -fr $dest_path1".".zip");
            //exec("chown apache. -R /backup/$username");
            exec("chown $username:$username -R /backup/$username");
            exec("chmod 644 -R /backup/$username");
        }
        else
        {
            echo "No domains Available for Mail Backup\n";
            // exit;
        }
        /* ////////////////////////////  Mail Backup End ///////////////////////// */	
    
        /* ////////////////////////  symlink Creation Started ////////////////////////
        $dest_path="/backup/".$username."/"."Full_".$username . "_" .$time_stamp ;
        shell_exec("mkdir -p /backup/$username");
        $cur_file_name="Full_".$username . "_" . $time_stamp.".zip";		
        */
        
        $vhost_dir=ctrl_options::GetSystemOption('hosted_dir');
        $cmd="mkdir -p ".$vhost_dir.$username."/backups/"." &&  cd ".$vhost_dir.$username."/backups/ && ln -S ".$cur_file_name." ".$dest_path.".zip";
        shell_exec($cmd);
	$wheris_chown=trim(shell_exec("whereis chown | awk '{print $2}'"));
        shell_exec("$wheris_chown -R $username:$username ".$vhost_dir.$username."/backups");
        /* ///////////////////////////  symlink Creation End ////////////////////////// */
    }
    else
    {
        echo "Username does not exists.";
        exit();		
    }
}


?>
