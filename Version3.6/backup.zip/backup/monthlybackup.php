<?php
require('/etc/sentora/panel/cnf/db.php');
include('/etc/sentora/panel/dryden/db/driver.class.php');
include('/etc/sentora/panel/dryden/debug/logger.class.php');
include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
include('/etc/sentora/panel/dryden/runtime/hook.class.php');
include('/etc/sentora/panel/dryden/sys/versions.class.php');
include('/etc/sentora/panel/dryden/ctrl/options.class.php');
include('/etc/sentora/panel/dryden/fs/director.class.php');
include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
include('/etc/sentora/panel/inc/dbc.inc.php');
$z_db_user = $user;
$z_db_pass = $pass;
try 
{
//    $zdbh = new db_driver("mysql:host=" . $host . ";dbname=" . $dbname . "", $user, $pass);
	$dsn = "mysql:dbname=$dbname;$ovi_socket_path";
	$zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
	$zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$mysqli=mysqli_connect("localhost",$user, $pass);
} catch (PDOException $e) {
exit();
}
        $sql = "SELECT * FROM  x_accounts WHERE ac_id_pk IN ( SELECT  bk_user_id FROM x_backup_setting WHERE bk_type='monthly' AND bk_enable='On') AND ac_deleted_ts IS NULL ";
		$numrows = $zdbh->prepare($sql);
        $numrows->execute();
		while($res=$numrows->fetch()) 
		{
                
				$download=1;
				$username=trim($res['ac_user_vc']);
				$backup_user_id=trim($res['ac_id_pk']);
				$backup_mail_acc=trim($res['ac_email_vc']);
/* ////////////////////////////////////////// PURGE DATA Start ///////////////////////////////////////////////////// */				
				$purge_date=6;
				$backupdir = ctrl_options::GetSystemOption('hosted_dir') . $username . "/backups/";
                if ($handle = @opendir($backupdir)) {
                    while (false !== ($file = readdir($handle))) {
                        if ($file != "." && $file != "..") {
                            $filetime = @filemtime($backupdir . $file);
                            if ($filetime == NULL) {
                                $filetime = @filemtime(utf8_decode($backupdir . $file));
                            }
                          echo  $filetime = floor((time() - $filetime) / 86400);
                            echo "" . $file . " - " . $purge_date . " - " . $filetime . "";
                            if ($purge_date <= $filetime) {
                                //delete the file
                                echo " - Deleting file..." . fs_filehandler::NewLine();
                                unlink($backupdir . $file);
                            } else {
                                echo " - Skipping file..." . fs_filehandler::NewLine();
                            }
                        }
                    }
                }

	/* ////////////////////////////////////////// PURGE DATA End ///////////////////////////////////////////////////// */	
	/* ///////////////////////////////////////// Calculating all data start //////////////////////////////////////////////////// */
			$total_bk_size_in_kb=0;
			$mysqlsql = $zdbh->query("SELECT my_id_pk, my_name_vc FROM x_mysql_databases WHERE my_deleted_ts IS NULL AND my_acc_fk='$backup_user_id'");
		try
	{
			while ($database = $mysqlsql->fetch()) 
			{
				//$currentdb = new db_driver("mysql:host=$host;dbname=" . $database['my_name_vc'] . "", $z_db_user, $z_db_pass);
				$data = $database['my_name_vc'];
				$dsn = "mysql:dbname=$data;$ovi_socket_path";
				$currentdb = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
				$currentdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$dbsize = $currentdb->query("SHOW TABLE STATUS");
				$dbgetsize = 0;
				while ($row = $dbsize->fetch()) 
				{
					$dbgetsize = $dbgetsize + ($row['Data_length'] + $row['Index_length']);
					$dbgetsize *= 0.00012207;
				}
				$total_bk_size_in_kb += $dbgetsize;
			}
}catch(Exception $e)
{

}
			$sql = "SELECT * FROM x_mailboxes WHERE  mb_deleted_ts IS NULL AND mb_acc_fk='$backup_user_id'";
			$sql = $zdbh->prepare($sql);
			$sql->execute();
			while ($rowmailboxes = $sql->fetch()) 
			{
				$mail_input = $rowmailboxes['mb_address_vc'];
				$maill_array = explode( '@', $mail_input ) ;
				$path = "/var/sentora/vmail/";
				$mail_path = $maill_array[0];
				$domain_path = $maill_array[1];
				$total = $path."".$domain_path."/".$maill_array[0];
				$size = shell_exec("du -sc $total | cut -f1 | awk '{print $1; exit}'");
				$total_bk_size_in_kb += $size ;

			}

			$full_path=ctrl_options::GetSystemOption('hosted_dir').$username."/";
			$size = shell_exec("du -sc $full_path --exclude=".$full_path."backups | cut -f1 | awk '{print $1; exit}'");
			$total_bk_size_in_kb += $size ;
			$total_bk_size_in_kb=(int) $total_bk_size_in_kb;
			$available_size_in_kb=(int)shell_exec("df | awk '{print $4}' | head -2 | tail -1");
			$overall_size_in_kb=(int)shell_exec("df | awk '{print $2}' | head -2 | tail -1");
			if((int)$available_size_in_kb < (int)$total_bk_size_in_kb )
			{
			$msg="Due to disk space exceeed, your monthly backup not working. kindly contact your administrator.";
				mail($backup_mail_acc,"Monthly Backup Failure",$msg);
			continue;
			}
			$remaining_kb=$available_size_in_kb - $total_bk_size_in_kb;
			 echo "remaining_kb :  $remaining_kb  \n ";

			$remaining_percentage = $remaining_kb / $overall_size_in_kb * 100 ;
			echo "Remaining percentage : $remaining_percentage \n";
			if($remaining_percentage < 5 )
			{
				$msg="Due to disk space exceeed, your monthly backup not working. kindly contact your administrator.";
				mail($backup_mail_acc,"Monthly Backup Failure",$msg);
				continue;
			}

	/* ///////////////////////////////////////// Calculating all data end /////////////////////////////////////////////////// */

							$rows = $zdbh->prepare("
							SELECT * FROM x_accounts 
							LEFT JOIN x_profiles ON (x_accounts.ac_id_pk=x_profiles.ud_user_fk) 
							LEFT JOIN x_groups   ON (x_accounts.ac_group_fk=x_groups.ug_id_pk) 
							LEFT JOIN x_packages ON (x_accounts.ac_package_fk=x_packages.pk_id_pk) 
							LEFT JOIN x_quotas   ON (x_accounts.ac_package_fk=x_quotas.qt_package_fk) 
							WHERE x_accounts.ac_user_vc= :ac_user_vc
							");
							$rows->bindParam(':ac_user_vc', $username);
							$rows->execute();
				if ($rows->fetchColumn() != 0) {		
								$rows = $zdbh->prepare("
								SELECT * FROM x_accounts 
								LEFT JOIN x_profiles ON (x_accounts.ac_id_pk=x_profiles.ud_user_fk) 
								LEFT JOIN x_groups   ON (x_accounts.ac_group_fk=x_groups.ug_id_pk) 
								LEFT JOIN x_packages ON (x_accounts.ac_package_fk=x_packages.pk_id_pk) 
								LEFT JOIN x_quotas   ON (x_accounts.ac_package_fk=x_quotas.qt_package_fk) 
								WHERE x_accounts.ac_user_vc= :ac_user_vc
								");
								$rows->bindParam(':ac_user_vc', $username);
								$rows->execute();
								$dbvals = $rows->fetch();
								$userid=$dbvals['ac_id_pk'];		
											/*	if ($backup = ExecuteBackup($userid, $username, $download)) {

												echo "backup completed.";

												} else {

												echo "<h2>Unauthorized Access!</h2>";
												echo "You have no permission to view this module.";

												}  */
						/* ////////////////////////////  Home Backup Start ///////////////////////// */						
						echo "backup Started. \n";
						$dest_path=ctrl_options::GetSystemOption('hosted_dir').$username."/backups/"."Full_".$username . "_" . date("M-d-Y_hms", time());
						$src_path=ctrl_options::GetSystemOption('hosted_dir').$username."/";
						$cmd="cd $src_path && zip -r $dest_path ./* -x ./backups/\* 2>&1 ";
						$output=array();
						$return_val="";
						$output=passthru($cmd,$return_val);    
						/* ////////////////////////////  Home Backup End ///////////////////////// */
						/* ////////////////////////////  Mysql Backup Start ///////////////////////// */
						$DBList="";
								$rows = $zdbh->prepare("
								SELECT * FROM  x_mysql_databases 
								WHERE x_mysql_databases.my_acc_fk=:ac_user_vc AND  x_mysql_databases.my_deleted_ts IS NULL
								");
								$rows->bindParam(':ac_user_vc', $userid);
								$rows->execute();
								if ($rows->fetchColumn() != 0) {
										$rows = $zdbh->prepare("
								SELECT * FROM  x_mysql_databases 
								WHERE x_mysql_databases.my_acc_fk=:ac_user_vc AND  x_mysql_databases.my_deleted_ts IS NULL
								");
								$rows->bindParam(':ac_user_vc', $userid);
								$rows->execute();
								 while($dbvals = $rows->fetch())
								{
								
									if (mysqli_select_db($mysqli,$dbvals['my_name_vc'])) {
										$DBList.=" ".$dbvals['my_name_vc'];
									}
									//$DBList.=" ".$dbvals['my_name_vc'];
								} 
								}else
								{
									echo "No Database Available for Backup\n";
									//exit;
								}
								//echo $DBList;
								if($DBList=="")
								{
									echo "No Database Available for Backup\n";
									// exit;	
								}else
								{
										exec("mkdir -p ".ctrl_options::GetSystemOption('hosted_dir').$username."/backups/mysql");
										// $dest_path="/var/sentora/hostdata/".$username."/backups/"."MySQL_".$username . "_" . date("M-d-Y_hms", time());
										$src_path=ctrl_options::GetSystemOption('hosted_dir').$username."/backups/";
										$cmd="cd $src_path && zip -ur $dest_path mysql 2>&1 ";
										$dbname=md5(sha1($username."SQL"));
										//--single-transaction - Since I am using InnoDB tables, I will want to use this option.
										$bkcommand =" cd ".ctrl_options::GetSystemOption('hosted_dir')."$username/backups/mysql && ".ctrl_options::GetSystemOption('mysqldump_exe')." -h ". $host . " -u " . $user . " -p" . $pass . " --databases $DBList > " . $dbname . ".sql  2>&1  ";
										$output=passthru($bkcommand,$return_val);           
										$output=array();
										$return_val="";
										$output=passthru($cmd,$return_val);
										passthru(" rm -fr ".ctrl_options::GetSystemOption('hosted_dir').$username."/backups/mysql");

								}
						/* ////////////////////////////  Mysql Backup End ///////////////////////// */	
						/* ////////////////////////////  Mail Backup Start  ///////////////////////// */	
							$domainlist="";
							$rows = $zdbh->prepare("
								SELECT * FROM  x_vhosts 
								WHERE x_vhosts.vh_acc_fk=:ac_user_vc
								");
								$rows->bindParam(':ac_user_vc', $userid);
								$rows->execute();
								if ($rows->fetchColumn() != 0) {
										$rows = $zdbh->prepare("
								SELECT * FROM  x_vhosts 
								WHERE x_vhosts.vh_acc_fk=:ac_user_vc
								");
								$rows->bindParam(':ac_user_vc', $userid);
								$rows->execute();
								 while($dbvals = $rows->fetch())
								{
									$domainlist.=" ".$dbvals['vh_name_vc'];
								} 
										$mail_zip="Mail";
										$dest_path1=ctrl_options::GetSystemOption('hosted_dir').$username."/backups/".$mail_zip;
										
										$src_path1="/var/sentora/vmail/";
										$cmd1="cd $src_path1 && zip -r $dest_path1 $domainlist 2>&1 ";
										$output=array();
										$return_val="";
										$output=passthru($cmd1,$return_val);
										$cmdfinal="cd $src_path && zip -ur $dest_path $mail_zip.zip 2>&1";
										$output=passthru($cmdfinal,$return_val);
									exec("rm -fr $dest_path1".".zip");
								}else
								{
									echo "No domains Available for Mail Backup\n";
									// exit;
								}
						/* ////////////////////////////  Mail Backup End ///////////////////////// */	
				}
				else
				{
				echo "Username does not exists.";
				exit();		
				}
			
		}

?>
