<?php
// Filename.php username Filename
if($argc!==3)
{
	echo "could you please pass the parameters correctly.";
	exit();
}
if(!file_exists("/backup/".$argv[1]."/".$argv[2]))
{
	echo "File name does not exists in the given user backup folder";
	exit;
}
if(substr($argv[2], -3)!='zip')
{
	echo "Restore has accept only zip files";
	exit;
}
/* ///////////////////////////////////////////// Calculation start /////////////////////////////////// */
$path="/backup/".trim($argv[1])."/".trim($argv[2]);
$total_bk_size_in_kb=(int)trim(shell_exec("unzip -l $path | tail -1 | awk '{print $1/1024}'"));
$available_size_in_kb=(int)trim(shell_exec("df | awk '{print $4}' | head -2 | tail -1"));
$overall_size_in_kb=(int)trim(shell_exec("df | awk '{print $2}' | head -2 | tail -1"));
echo "\ntotal_bk_size_in_kb ".$total_bk_size_in_kb;
echo "\navailable_size_in_kb ".$available_size_in_kb;
echo "\noverall_size_in_kb ".$overall_size_in_kb;
if($available_size_in_kb < $total_bk_size_in_kb )
{
	echo "Due to disk space exceeed, your restore does not working. kindly contact your administrator.";
	exit;
}
$remaining_kb=$available_size_in_kb - $total_bk_size_in_kb;
$remaining_percentage = $remaining_kb / $overall_size_in_kb * 100 ;
echo "\nremaining_kb ".$remaining_kb;
echo "\nremaining_percentage ".$remaining_percentage;
if($remaining_percentage < 5 )
{
	echo "Due to disk space exceeed, your restore not working. kindly contact your administrator.";
	exit;
}

/* ///////////////////////////////////////////// Calculation End /////////////////////////////////// */
require('/etc/sentora/panel/cnf/db.php');
include('/etc/sentora/panel/dryden/db/driver.class.php');
include('/etc/sentora/panel/dryden/debug/logger.class.php');
include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
include('/etc/sentora/panel/dryden/runtime/hook.class.php');
include('/etc/sentora/panel/dryden/sys/versions.class.php');
include('/etc/sentora/panel/dryden/ctrl/options.class.php');
include('/etc/sentora/panel/dryden/fs/director.class.php');
include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
include('/etc/sentora/panel/inc/dbc.inc.php');
try 
{
    $dsn = "mysql:dbname=$dbname;$ovi_socket_path";
    $zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
    $zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} 
catch (PDOException $e) 
{
    exit();
}
$vhost_path = ctrl_options::GetSystemOption('hosted_dir');
$download=1;
if (isset($argv[1]) && $argv[1] != "") {
  
    $username=trim($argv[1]);
	$rows = $zdbh->prepare("SELECT a.* FROM x_accounts a,x_profiles p,x_groups g,x_packages pa,x_quotas q 
                                WHERE a.ac_id_pk=p.ud_user_fk AND a.ac_group_fk=g.ug_id_pk AND a.ac_package_fk=pa.pk_id_pk 
                                AND a.ac_package_fk=q.qt_package_fk AND a.ac_user_vc= :ac_user_vc AND a.ac_deleted_ts is NULL");	
	$rows->bindParam(':ac_user_vc', $username);
	$rows->execute();
	$res_count = $rows->rowCount();
	if($res_count > 0) {
	//if ($rows->fetch()) {	
	//$rows = $zdbh->prepare("SELECT a.* FROM x_accounts a,x_profiles p,x_groups g,x_packages pa,x_quotas q  WHERE a.ac_id_pk=p.ud_user_fk AND a.ac_group_fk=g.ug_id_pk AND a.ac_package_fk=pa.pk_id_pk AND a.ac_package_fk=q.qt_package_fk AND a.ac_user_vc= :ac_user_vc");
	//$rows->bindParam(':ac_user_vc', $username);
        //$rows->execute();	
        $dbvals = $rows->fetch();
        $userid=$dbvals['ac_id_pk'];		
        $filename=$argv[2];		
        echo "Restore started. \n";
        //$dest_path="/var/sentora/hostdata/".$username."/";
        $dest_path=$vhost_path.$username."/";
        # $dest_path="/backup/".$username."/";
        $src_path="/backup/".$username."/";
        //$cmd="cd $src_path && unzip -n $filename -d $dest_path 2>&1 ";
 echo       $cmd="cd $src_path && unzip  -o $filename -d $dest_path 2>&1 ";
        $output=array();
        $return_val="";
        $output=passthru($cmd,$return_val);
        //exec("chown -R apache:apache $dest_path");
        exec("chown -R $username:$username $dest_path");
	$find_ser = trim(exec("whereis find | awk '{ print $2 }'"));
	exec("$find_ser $dest_path -type d -exec chmod 0755 {} \;");
	exec("$find_ser $dest_path -type f -exec chmod 0644 {} \;");
        //exec("chmod -R 0755 $dest_path");
        //$mail_path=$vhost_path."Mail.zip";
        $mail_path=$dest_path."Mail.zip";
	if(file_exists($mail_path))
        {
            $mail_dest_path="/var/sentora/vmail/";
            $src_path="/backup/".$username."/";
            //$cmd="cd $dest_path && unzip -n Mail.zip -d $mail_dest_path 2>&1 ";
            $cmd="cd $dest_path && unzip -o Mail.zip -d $mail_dest_path 2>&1 ";
            $output=array();
            $return_val="";
            $output=passthru($cmd,$return_val);
            passthru("chown -R vmail:mail $mail_dest_path");
            passthru("chmod -R 0755 $mail_dest_path");
            exec("rm -fr $mail_path ");
        }else
        {
            echo "Mailbackup not available";
        }
        $dbname=md5(sha1($username."SQL")).".sql";
        //if(file_exists("/var/sentora/hostdata/".$username."/mysql/".$dbname))
        if(file_exists($dest_path."/mysql/".$dbname))
        {
            //$cmd="mysql -u $user -p$pass < /var/sentora/hostdata/$username/mysql/$dbname"; 
            $cmd="mysql -u $user -p'$pass' < $dest_path/mysql/$dbname"; 
            $output=passthru($cmd,$return_val);
            $output=array();
            $return_val="";
            $output=passthru($cmd,$return_val);
            $cmd="rm -fr $dest_path/mysql";
            exec($cmd);
            return TRUE;
        }
	}
	else
	{
	    echo "Username does not exists.";
	    exit();		
	}
}


?>
