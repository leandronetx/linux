<?php
require('/etc/sentora/panel/cnf/db.php');
include('/etc/sentora/panel/dryden/db/driver.class.php');
include('/etc/sentora/panel/dryden/debug/logger.class.php');
include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
include('/etc/sentora/panel/dryden/runtime/hook.class.php');
include('/etc/sentora/panel/dryden/sys/versions.class.php');
include('/etc/sentora/panel/dryden/ctrl/options.class.php');
include('/etc/sentora/panel/dryden/fs/director.class.php');
include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
include('/etc/sentora/panel/inc/dbc.inc.php');
	try {                                                    
		$dsn = "mysql:dbname=$dbname;$ovi_socket_path";
                $zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
         	$zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
     	} catch (PDOException $e) {        
                echo "MYSQL error : $e";          
		exit();                       
	}       
        $sql = "SELECT * FROM  x_accounts WHERE ac_id_pk IN ( SELECT  bk_user_id FROM x_backup_setting WHERE bk_type='weekly' AND bk_enable='On') AND ac_deleted_ts IS NULL ";
		$numrows = $zdbh->prepare($sql);
        	$numrows->execute();
		if ($numrows->rowCount() <= 0 ){
			echo "Weekly backup account is not initialed for any account";
			exit;
		}
		while($res=$numrows->fetch()) 
		{

					$download=1;
					$username=trim($res['ac_user_vc']);
					echo "username $username \n";	
/* ////////////////////////////////////////// PURGE DATA Start ///////////////////////////////////////////////////// */			
				$purge_date=6;
				$backupdir = ctrl_options::GetSystemOption('hosted_dir') . $username . "/backups/";
                if ($handle = @opendir($backupdir)) {
                    while (false !== ($file = readdir($handle))) {
                        if ($file != "." && $file != "..") {
                            $filetime = @filemtime($backupdir . $file);
                            if ($filetime == NULL) {
                                $filetime = @filemtime(utf8_decode($backupdir . $file));
                            }
                          echo  $filetime = floor((time() - $filetime) / 86400);
                            echo "" . $file . " - " . $purge_date . " - " . $filetime . "";
                            if ($purge_date <= $filetime) {
                                //delete the file
                                echo " - Deleting file..." . fs_filehandler::NewLine();
                                unlink($backupdir . $file);
                            } else {
                                echo " - Skipping file..." . fs_filehandler::NewLine();
                            }
                        }
                    }
                }

/* ////////////////////////////////////////// PURGE DATA End ///////////////////////////////////////////////////// */			
		
							$rows = $zdbh->prepare("
							SELECT * FROM x_accounts 
							LEFT JOIN x_profiles ON (x_accounts.ac_id_pk=x_profiles.ud_user_fk) 
							LEFT JOIN x_groups   ON (x_accounts.ac_group_fk=x_groups.ug_id_pk) 
							LEFT JOIN x_packages ON (x_accounts.ac_package_fk=x_packages.pk_id_pk) 
							LEFT JOIN x_quotas   ON (x_accounts.ac_package_fk=x_quotas.qt_package_fk) 
							WHERE x_accounts.ac_user_vc= :ac_user_vc
							");
							$rows->bindParam(':ac_user_vc', $username);
							$rows->execute();
				if ($rows->fetchColumn() != 0) {		
								$rows = $zdbh->prepare("
								SELECT * FROM x_accounts 
								LEFT JOIN x_profiles ON (x_accounts.ac_id_pk=x_profiles.ud_user_fk) 
								LEFT JOIN x_groups   ON (x_accounts.ac_group_fk=x_groups.ug_id_pk) 
								LEFT JOIN x_packages ON (x_accounts.ac_package_fk=x_packages.pk_id_pk) 
								LEFT JOIN x_quotas   ON (x_accounts.ac_package_fk=x_quotas.qt_package_fk) 
								WHERE x_accounts.ac_user_vc= :ac_user_vc
								");
								$rows->bindParam(':ac_user_vc', $username);
								$rows->execute();
								$dbvals = $rows->fetch();
								$userid=$dbvals['ac_id_pk'];		
											/*	if ($backup = ExecuteBackup($userid, $username, $download)) {

												echo "backup completed.";

												} else {

												echo "<h2>Unauthorized Access!</h2>";
												echo "You have no permission to view this module.";

												}  */
						/* ////////////////////////////  Home Backup Start ///////////////////////// */		
						echo "backup Started. \n";
						$dest_path=ctrl_options::GetSystemOption('hosted_dir').$username."/backups/"."Full_".$username . "_" . date("M-d-Y_hms", time());
                                                $src_path=ctrl_options::GetSystemOption('hosted_dir').$username."/";
                                                $cmd="cd $src_path && zip -r $dest_path ./* -x ./backups/\* 2>&1 ";
                                                $output=array();	
						$return_val="";
						$output=passthru($cmd,$return_val);    
						/* ////////////////////////////  Home Backup End ///////////////////////// */
						/* ////////////////////////////  Mysql Backup Start ///////////////////////// */
						$DBList="";
								$rows = $zdbh->prepare("
								SELECT * FROM  x_mysql_databases 
								WHERE x_mysql_databases.my_acc_fk=:ac_user_vc AND  x_mysql_databases.my_deleted_ts IS NULL
								");
								$rows->bindParam(':ac_user_vc', $userid);
								$rows->execute();
								if ($rows->rowCount() != 0) {
								 	while($dbvals = $rows->fetch()){
								
										if (mysqli_select_db($mysqli,$dbvals['my_name_vc'])) {
											$DBList.=" ".$dbvals['my_name_vc'];
										}
											//$DBList.=" ".$dbvals['my_name_vc'];
									} 
								}else
								{
									echo "No Database Available for Backup\n";
									//exit;
								}
								//echo $DBList;
								if($DBList=="")
								{
									echo "No Database Available for Backup\n";
									// exit;	
								}else
								{
										exec("mkdir -p ".ctrl_options::GetSystemOption('hosted_dir').$username."/backups/mysql");
										$src_path=ctrl_options::GetSystemOption('hosted_dir').$username."/backups/";
										$cmd="cd $src_path && zip -ur $dest_path mysql 2>&1 ";
										$dbname=md5(sha1($username."SQL"));
										//--single-transaction - Since I am using InnoDB tables, I will want to use this option.
										$bkcommand =" cd ".ctrl_options::GetSystemOption('hosted_dir')."$username/backups/mysql && ".ctrl_options::GetSystemOption('mysqldump_exe')." -h ". $host . " -u " . $user . " -p" . $pass . " --databases $DBList > " . $dbname . ".sql  2>&1  ";
										$output=passthru($bkcommand,$return_val);           
										$output=array();
										$return_val="";
										$output=passthru($cmd,$return_val);
										passthru(" rm -fr ".ctrl_options::GetSystemOption('hosted_dir').$username."/backups/mysql");
								}
						/* ////////////////////////////  Mysql Backup End ///////////////////////// */	
						/* ////////////////////////////  Mail Backup Start  ///////////////////////// */	
							$domainlist="";
							$rows = $zdbh->prepare("
								SELECT * FROM  x_vhosts 
								WHERE x_vhosts.vh_acc_fk=:ac_user_vc
								");
								$rows->bindParam(':ac_user_vc', $userid);
								$rows->execute();
								if ($rows->fetchColumn() != 0) {
										$rows = $zdbh->prepare("
								SELECT * FROM  x_vhosts 
								WHERE x_vhosts.vh_acc_fk=:ac_user_vc
								");
								$rows->bindParam(':ac_user_vc', $userid);
								$rows->execute();
								 while($dbvals = $rows->fetch())
								{
									$domainlist.=" ".$dbvals['vh_name_vc'];
								} 
										$mail_zip="Mail";
										$dest_path1=ctrl_options::GetSystemOption('hosted_dir').$username."/backups/".$mail_zip;
	
										$src_path1="/var/sentora/vmail/";
										$cmd1="cd $src_path1 && zip -r $dest_path1 $domainlist 2>&1 ";
										$output=array();
										$return_val="";
										$output=passthru($cmd1,$return_val);
										$cmdfinal="cd $src_path && zip -ur $dest_path $mail_zip.zip 2>&1";
										$output=passthru($cmdfinal,$return_val);
									exec("rm -fr $dest_path1".".zip");
								}else
								{
									echo "No domains Available for Mail Backup\n";
									// exit;
								}
						/* ////////////////////////////  Mail Backup End ///////////////////////// */	
				}
				else
				{
				echo "Username does not exists.";
				exit();		
				}
			
		}

?>

