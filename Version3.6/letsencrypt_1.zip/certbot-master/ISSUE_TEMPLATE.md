## My operating system is (include version):


## I installed Certbot with (certbot-auto, OS package manager, pip, etc):


## I ran this command and it produced this output:


## Certbot's behavior differed from what I expected because:


## Here is a Certbot log showing the issue (if available):
###### Logs are stored in `/var/log/letsencrypt` by default. Feel free to redact domains, e-mail and IP addresses as you see fit.
