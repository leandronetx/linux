#!/bin/bash

# Simple filter to plug SpamAssassin into the Postfix MTA
#
# Modified by Sathiya Saarabana Babu
#
# This script should probably live at /usr/bin/spamfilter.sh
# ... and have 'chown root:root' and 'chmod 755' applied to it.
#
# For use with:
#     Postfix 20010228 or later
#     SpamAssassin 2.42 or later

# Note: Modify the file locations to suit your particular
#       server and installation of SpamAssassin.
# File locations:
# (CHANGE AS REQUIRED TO SUIT YOUR SERVER)

LOGFILE=/var/sentora/spamd/SpamFilterChecking.log
SPAMASSASSIN=/usr/bin/spamc
SENDER_MAIL_ID=$3
BLOCKED_MAIL_LIST_FILE=/var/sentora/spamd/BlockedMails.txt
SENDMAIL=/usr/sbin/sendmail

echo $SENDER_MAIL_ID >> $LOGFILE
FromDomainName=`cut -d '@' -f2 <<< $SENDER_MAIL_ID`
echo "FromDomainName : $FromDomainName" >> $LOGFILE

#Domain Directory for check the domain with us or not
DOMAIN_DIRECTORY_CONF_PATH="/etc/sentora/configs/apache/domains/$FromDomainName.conf"
echo "DOMAIN_DIRECTORY_CONF_PATH : $DOMAIN_DIRECTORY_CONF_PATH" >> $LOGFILE

if [ -f "$DOMAIN_DIRECTORY_CONF_PATH" ];
then
    echo "Sender Email $SENDER_MAIL_ID" >> $LOGFILE
    #Checking If Blocked mails txt file is exists or not. If doesn't exists we are creating
    if [ ! -f $BLOCKED_MAIL_LIST_FILE ]
    then
        echo "File $BLOCKED_MAIL_LIST_FILE Does not exists so creating " >> $LOGFILE
        touch $BLOCKED_MAIL_LIST_FILE
        chown spamd:spamd $BLOCKED_MAIL_LIST_FILE
    else
        #Checking this sender email id is blocked or not
        checkBlocked=`grep $SENDER_MAIL_ID $BLOCKED_MAIL_LIST_FILE`
        echo "Check Mail Id Output : $checkMailId" >> $LOGFILE
        if [ ! -z $checkBlocked ]
        then
            echo "Mail id $SENDER_MAIL_ID has been Blocked" >> $LOGFILE
            exit $?
        else
            echo "Mail id $SENDER_MAIL_ID Not blocked" >> $LOGFILE
        fi
    fi
    TMPFP=`mktemp`
    cat | $SPAMASSASSIN > $TMPFP
    echo $TMPFP >> $LOGFILE
    echo $@ >> $LOGFILE
    echo "Each Mail id : "$To >> $LOGFILE

    # Make temp File For Each Email
    From=`grep '^From.*$' $TMPFP | grep -E -o "\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,6}\b" | cut -d ':' -f2`
    #Getting From email id from mail request
    #From=$SENDER_MAIL_ID
    #echo "From: $From" >> $LOGFILE
    #Getting To email id from mail request
    #To=`grep '^To.*$' $TMPFP | grep -E -o "\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,6}\b" | cut -d ':' -f2`
    To=$4
    echo "To email id: $To" >> $LOGFILE
    #Getting Date from mail request
    Date=`grep '^Date.*$' $TMPFP | cut -d ',' -f2 | cut -d '+' -f1`
    echo "Date: $Date" >> $LOGFILE

    #Getting Spam score of the email
    SpamScore=`grep 'X-Spam-Status' $TMPFP | grep score | cut -d " " -f3 | cut -d '=' -f2`
    echo "Spam Score : $SpamScore" >> $LOGFILE

    UserAgent=`grep 'User-Agent' $TMPFP | cut -d ":" -f2`
    echo "User Agent : $UserAgent" >> $LOGFILE

    # Checking The mail is Incoming or Outgoing by checking the from mail id domain directory is exists with us or not
    dom=`echo $To | awk -F\@ '{print $2}'`
    dom_low=`echo $dom | awk '{print tolower($0)}'`

    if [[ $dom_low =~ "outlook.com" || $dom_low =~ "gmail.com" || $dom_low =~ "hotmail.com" ]]
    then
        #Checking to email id is valid or not.
        PHP_PATH=`whereis php | awk '{print $2}'`
        ### by nandhini 2.8 sending mail converter to string lower 
	sendingmail=${To,,}
        echo "$PHP_PATH /usr/bin/validate_outgoing_emailid.php $sendingmail" >> $LOGFILE
        out=`$PHP_PATH /usr/bin/validate_outgoing_emailid.php $sendingmail`
        
        echo "Output of check valid email $sendingmail : $out" >> $LOGFILE
        if [[ $out = *"invalid"* ]]
        then
           echo "Invalid email id $sendingmail" >> $LOGFILE
            (
                echo "To: $From"
                echo "Subject: Sending mail to invalid email id"
                echo "Content-Type: text/html"
                echo
                echo "Dear User,<br><br> The email id you trying to send <b>$To</b> is invalid id. Please avoid sending more emails to invalid email ids like this. If you are keep sending then gmail or outlook will block this server."
               echo
            ) | $SENDMAIL -t
            exit $?
        else
            echo "Mail id is valid " >> $LOGFILE
        fi
    fi

    MailOutGoingLogDir=/var/sentora/spamd/OutGoingMailLogs
    MailOutGoingLogPath=$MailOutGoingLogDir/outmaillog.log
    EachMailCountsDir=$MailOutGoingLogDir/EmailsCounts
    EachMailCountsFilePath=$EachMailCountsDir/$From
    mkdir -p $MailOutGoingLogDir
    chown -R spamd:spamd $MailOutGoingLogDir
    # Mail Outgoing log file is created, if does not exists
    if [ ! -f $MailOutGoingLogPath ]
    then
        touch $MailOutGoingLogPath
    fi

    mkdir -p $EachMailCountsDir
    chown -R spamd:spamd $EachMailCountsDir
    # Each Mail id file is created for store mail counts within hour, if does not exists
    if [ ! -f $EachMailCountsFilePath ]
    then
        touch $EachMailCountsFilePath
        echo 0 > $EachMailCountsFilePath
    fi
    echo "Outgoing Mail so spam filter check" >> $LOGFILE
    # Checking the each mail id file is modified with in one hour or not
    ModifiedDiff=$(( (`date +%s` - `stat -L --format %Y $EachMailCountsFilePath`) > (60*60) ))
    echo "File Modified status if it is 0 then it has modified within one hour, else it will return 1 $ModifiedDiff" >> $LOGFILE
    if [ $ModifiedDiff -eq 0 ]
    then
        COUNT=`cat $EachMailCountsFilePath`
        # Checking the email count is greater than 40 with in a hour
        if [ $COUNT -ge 40 ]
        then
            checkBlocked=`grep $From $BLOCKED_MAIL_LIST_FILE`
            echo "Check Mail Id Spam Output : $checkMailId" >> $LOGFILE

            #Checking this mail id is already added in blacklisted or not.
            if [ -z $checkBlocked ]
            then
                echo $From >> $BLOCKED_MAIL_LIST_FILE
            fi

            writeToOutMailLog="$Date ==> $From ==> $To ==> $SpamScore ==> $UserAgent ==> No ==> More than 40 mails has sent with in one hour"
            (
                echo "To: $From"
                echo "Subject: Your Mail id $From is Blocked"
                echo "Content-Type: text/html"
                echo
                echo "Dear Client,<br><br> Your Mail id <b>$From</b> has been blocked due to sending more than 40 mails within one Hour. Somebody may be hacked your email or due to Virus/Malware its sending spam emails. So please change your email password strong. And unblock your email using your cPanel."
                echo
            ) | $SENDMAIL -t

            echo $writeToOutMailLog >> $LOGFILE

            #Storing Outgoing mail status In Log
            echo $writeToOutMailLog >> $MailOutGoingLogPath
            exit $?
        fi
        ((COUNT++))
    else
        COUNT=1
    fi

    #Storing mail count to each mail id path, If spam score is above required spam score
    require_spam_score=`grep required_score $SPAM__SCORE_CONFIGURATION_FILE_PATH | cut -d ' ' -f2`
    #if [[ $(bc -l <<< "$SpamScore > $require_spam_score") -eq 0 ]]
    if [[ $SpamScore -ge $require_spam_score ]]
    then
        echo "Count of mails : $COUNT" >> $LOGFILE
        echo $COUNT > $EachMailCountsFilePath
    fi

    writeToOutMailLog="$Date ==> $From ==> $To ==> $SpamScore ==> $UserAgent ==> Yes"
    echo $writeToOutMailLog >> $LOGFILE

    #Storing Outgoing mail status In Log
    echo $writeToOutMailLog >> $MailOutGoingLogPath


    # Checking 100 Email per day, if outgoing email id is Gmail,yahoo,rediff,hotmail
    # Start
    EachEmailCountsPerdayDir=$MailOutGoingLogDir/EmailCountsPerday
    EachMailCountsPerdayFilePath=$EachEmailCountsPerdayDir/$From

    mkdir -p $EachEmailCountsPerdayDir
    chown -R spamd:spamd $EachEmailCountsPerdayDir
    # Each Mail id file is created for store mail counts within hour, if does not exists
    if [ ! -f $EachMailCountsPerdayFilePath ]
    then
        touch $EachMailCountsPerdayFilePath
        echo "gmail - 0" > $EachMailCountsPerdayFilePath
        echo "yahoo - 0" >> $EachMailCountsPerdayFilePath
        echo "hotmail - 0" >> $EachMailCountsPerdayFilePath
        echo "rediff - 0" >> $EachMailCountsPerdayFilePath
    else
        CURRENT_TIME=`date "+%Y-%m-%d %H:%M:%S"  | awk '{print $2}' | cut -d ':' -f1`
        FILE_MODIFIED_DATE=`stat -c %y $EachMailCountsPerdayFilePath | awk '{print $1}'`
        CURRENT_DATE=`date "+%Y-%m-%d"`
        FILE_MODIFIED_DIFF=$(( ($(date -d "$CURRENT_DATE UTC" +%s) - $(date -d "$FILE_MODIFIED_DATE UTC" +%s) )/(60*60*24) ))
        if [[ $CURRENT_TIME -ge 0 && $FILE_MODIFIED_DIFF -gt 0 ]]
        then
            echo "Reset Outgoing mail data per day 100 limit: " >> $LOGFILE
            echo "gmail - 0" > $EachMailCountsPerdayFilePath
            echo "yahoo - 0" >> $EachMailCountsPerdayFilePath
            echo "hotmail - 0" >> $EachMailCountsPerdayFilePath
            echo "rediff - 0" >> $EachMailCountsPerdayFilePath
        fi
    fi
    for addr in $(echo $To | tr "\n" "\n")
    do
        echo "Email : $addr"
    done

    dom=`echo $To | awk -F\@ '{print $2}'`
    dom_low=`echo $dom | awk '{print tolower($0)}'`
    echo $dom_low >> $LOGFILE
    if [[ $dom_low =~ "gmail.com" || $dom_low =~ "hotmail.com" || $dom_low =~ "rediffmail" || $dom_low =~ "yahoo" || $dom_low =~ "ymail" || $dom_low =~ "outlook" ]]
    then
        if [[ $dom_low =~ "gmail.com" ]]
        then
            SearchToAddress="gmail"
        fi
        if [[ $dom_low =~ "hotmail.com" || $dom_low =~ "outlook" ]]
        then
            SearchToAddress="hotmail"
        fi
        if [[ $dom_low =~ "rediffmail" ]]
        then
            SearchToAddress="rediff"
        fi
        if [[ $dom_low =~ "yahoo" || $dom_low =~ "ymail" ]]
        then
            SearchToAddress="yahoo"
        fi
        echo "Sending to $SearchToAddress"
        echo "Checking email count per day of $SearchToAddress : grep -n "$SearchToAddress" $EachMailCountsPerdayFilePath |cut -f1 -d:" >> $LOGFILE
        LINE_NUMBER=`grep -n "$SearchToAddress" $EachMailCountsPerdayFilePath |cut -f1 -d:`
        #COUNT=`grep -r $SearchToAddress $EachMailCountsPerdayFilePath | awk '{print tolower($3)}'`
		COUNT=`grep sasl_username=$From /var/log/maillog|awk {'print $NF'} |sort |uniq -c |sort -n | awk {'print $1'}`
        # Checking the email count is greater than 100 by today
                # code add by Kesav
		WHERE_MYSQL=`whereis mysql | awk '{ print $2 }'`
		DB_MAIL_COUNT=""
                DB_NAME='sentora_core'
		username='MAILQ_MYSQL_USERNAME'
		password='MAILQ_MYSQL_PASSWORD'
		DB_MAIL_COUNT=$(echo "select mailperhrlimt_size from x_mailboxes where mb_address_vc='$From';" | $WHERE_MYSQL --user=$username --password=$password --socket=/usr/local/mysql/mysql.sock sentora_core --skip-column-names 2>/dev/null)

        if [ $COUNT -gt $DB_MAIL_COUNT ]
        then	
            echo "Today email count for the email id $From to $SearchToAddress is greater than $DB_MAIL_COUNT so block" >> $LOGFILE
            (
                echo "To: $From"
                echo "Subject: Your Mail id $From has sent more than $DB_MAIL_COUNT email today to $SearchToAddress"
                echo "Content-Type: text/html"
                echo
                echo "Dear Client,<br><br> From this email $From you have sent $COUNT emails per day that is more than $DB_MAIL_COUNT emails per day you have set for $From email account . If you send more than emails per day, your email ID most likely be black listed. Your domain and IP address will be black listed. If you want to send marketing Email or spamming, which is not allowed with Ovi Hosting servers. "
                echo
            ) | $SENDMAIL -t
            exit $?
        else
            echo "Email not more than $DB_MAIL_COUNT so update the count for $SearchToAddress" >> $LOGFILE
            ((COUNT++))
            ReplaceValue="$SearchToAddress - $COUNT"
            echo $ReplaceValue
            sed -i "${LINE_NUMBER}s/.*/$ReplaceValue/" "$EachMailCountsPerdayFilePath"
            echo "sed -i "${LINE_NUMBER}s/.*/$ReplaceValue/" "$EachMailCountsPerdayFilePath"" >> $LOGFILE
        fi
    fi
    #End of outgoing mail 100 limit validation
    cat $TMPFP | ${SENDMAIL} "$@"
    echo "Temp File is : "$TMPFP >> $LOGFILE
    rm -f $TMPFP
    exit $?
else
    echo "Incoming Mail so send it " >> $LOGFILE
fi

SPAMASSASSIN=/usr/bin/spamc
touch /etc/postfix/log_test;
touch /var/log/rootmaillog;
SENDER_MAIL_ID=$3

mailqcount=`mailq | grep -c "^[A-F0-9]"`;
mailqneededcount=100;
if [ "$mailqcount" -gt "$mailqneededcount" ];then
sh /usr/bin/removeroot.sh;
fi
mailqcount=`mailq | grep -c "^[A-F0-9]"`;
mailqneededcount=100;
if [ "$mailqcount" -gt "$mailqneededcount" ];then
php /usr/bin/phpsendingmail.php;
fi

${SPAMASSASSIN} | ${SENDMAIL} "$@"

declare RECIPIENT="unset"
declare SENDER="unset"
declare SASL_USERNAME="unset"
declare CLIENT_IP="unset"
declare AUTHENTICATED="unset"
declare AUTORESPONSE_MESSAGE="unset"
declare DISABLE_AUTORESPONSE="unset"
declare ENABLE_AUTORESPONSE="unset"
declare DELETE_AUTORESPONSE="unset"
declare SEND_RESPONSE="unset"
declare RESPONSES_DIR="/var/spool/autoresponse/responses"
declare SENDMAIL="/usr/sbin/sendmail"
declare RATE_LOG_DIR="/var/spool/autoresponse/log"
declare LOGGER="/usr/bin/logger"
#There are two different modes of operation:
#   MODE="0" represents the actions that can not be executed from the command line
#   MODE="1" represents the actions that can be executed from the command line
declare MODE="0"
#Time limit, in seconds that determines how often an
#autoresponse will be sent, per e-mail address (3600 = 1 hour, 86400 = 1 day)
declare RESPONSE_RATE="10"
SENDER=$3;
SEND_RESPONSE=1;
COUNTD=$#;
ALLDATA=$@;
INC_D=$(( $COUNTD - 3 ));

AUTO_D=${*: -$INC_D};

if [ "${MODE}" = "0" ]; then

    rate_log_check() {
        #Only send one autoresponse per e-mail address per the time limit (in seconds) designated by the RESPONSE_RATE variable
        if [ -f "${RATE_LOG_DIR}/${RECIPIENT}/${SENDER}" ]; then
            declare ELAPSED_TIME=`echo $[\`date +%s\` - \`stat -c %X "${RATE_LOG_DIR}/${RECIPIENT}/${SENDER}"\`]`
            if [ "${ELAPSED_TIME}" -lt "${RESPONSE_RATE}" ]; then
                ${LOGGER} -i -t autoresponse -p mail.notice "An autoresponse has already been sent from ${RECIPIENT} to ${SENDER} within the last ${RESPONSE_RATE} seconds"
                SEND_RESPONSE=0
            fi
        fi
    }

    for g in  $AUTO_D;
    do
        RECIPIENT=$g;
        if [ -f "${RESPONSES_DIR}/${RECIPIENT}" ]; then
            rate_log_check
            #If SEND_RESPONSE still equals "1" after the rate_log_check function, send an autoresponse.
            #   if [ "${SEND_RESPONSE}" = "1" ] && [ "${RECIPIENT}" != "${SENDER}" ]; then
             if [ "${SEND_RESPONSE}" = "1" ]; then
                (cat "${RESPONSES_DIR}/${RECIPIENT}") | sed -e "0,/^$/ { s/^To:.*/To: <${SENDER}>/ }" -e '0,/^$/ { /^Date:/ d }' | ${SENDMAIL} -i -f "${RECIPIENT}" "${SENDER}"
                mkdir -p "${RATE_LOG_DIR}/${RECIPIENT}"
                touch "${RATE_LOG_DIR}/${RECIPIENT}/${SENDER}"
                ${LOGGER} -i -t autoresponse -p mail.notice "Autoresponse sent from ${RECIPIENT} to ${SENDER}"
            fi
        fi
        #   exec ${SENDMAIL} -i -f "${SENDER}" "${RECIPIENT}"
    done


fi 
