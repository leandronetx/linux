-- MySQL dump 10.13  Distrib 5.7.25, for Linux (x86_64)
--
-- Host: localhost    Database: sentora_core
-- ------------------------------------------------------
-- Server version	5.7.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `sentora_core`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sentora_core` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `sentora_core`;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `sortname` varchar(3) NOT NULL,
  `name` varchar(150) NOT NULL,
  `phonecode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'AF','Afghanistan',93),(2,'AL','Albania',355),(3,'DZ','Algeria',213),(4,'AS','American Samoa',1684),(5,'AD','Andorra',376),(6,'AO','Angola',244),(7,'AI','Anguilla',1264),(8,'AQ','Antarctica',0),(9,'AG','Antigua And Barbuda',1268),(10,'AR','Argentina',54),(11,'AM','Armenia',374),(12,'AW','Aruba',297),(13,'AU','Australia',61),(14,'AT','Austria',43),(15,'AZ','Azerbaijan',994),(16,'BS','Bahamas The',1242),(17,'BH','Bahrain',973),(18,'BD','Bangladesh',880),(19,'BB','Barbados',1246),(20,'BY','Belarus',375),(21,'BE','Belgium',32),(22,'BZ','Belize',501),(23,'BJ','Benin',229),(24,'BM','Bermuda',1441),(25,'BT','Bhutan',975),(26,'BO','Bolivia',591),(27,'BA','Bosnia and Herzegovina',387),(28,'BW','Botswana',267),(29,'BV','Bouvet Island',0),(30,'BR','Brazil',55),(31,'IO','British Indian Ocean Territory',246),(32,'BN','Brunei',673),(33,'BG','Bulgaria',359),(34,'BF','Burkina Faso',226),(35,'BI','Burundi',257),(36,'KH','Cambodia',855),(37,'CM','Cameroon',237),(38,'CA','Canada',1),(39,'CV','Cape Verde',238),(40,'KY','Cayman Islands',1345),(41,'CF','Central African Republic',236),(42,'TD','Chad',235),(43,'CL','Chile',56),(44,'CN','China',86),(45,'CX','Christmas Island',61),(46,'CC','Cocos (Keeling) Islands',672),(47,'CO','Colombia',57),(48,'KM','Comoros',269),(49,'CG','Congo',242),(50,'CD','Congo The Democratic Republic Of The',242),(51,'CK','Cook Islands',682),(52,'CR','Costa Rica',506),(53,'CI','Ivoire (Ivory Coast)',225),(54,'HR','Croatia (Hrvatska)',385),(55,'CU','Cuba',53),(56,'CY','Cyprus',357),(57,'CZ','Czech Republic',420),(58,'DK','Denmark',45),(59,'DJ','Djibouti',253),(60,'DM','Dominica',1767),(61,'DO','Dominican Republic',1809),(62,'TP','East Timor',670),(63,'EC','Ecuador',593),(64,'EG','Egypt',20),(65,'SV','El Salvador',503),(66,'GQ','Equatorial Guinea',240),(67,'ER','Eritrea',291),(68,'EE','Estonia',372),(69,'ET','Ethiopia',251),(70,'XA','External Territories of Australia',61),(71,'FK','Falkland Islands',500),(72,'FO','Faroe Islands',298),(73,'FJ','Fiji Islands',679),(74,'FI','Finland',358),(75,'FR','France',33),(76,'GF','French Guiana',594),(77,'PF','French Polynesia',689),(78,'TF','French Southern Territories',0),(79,'GA','Gabon',241),(80,'GM','Gambia The',220),(81,'GE','Georgia',995),(82,'DE','Germany',49),(83,'GH','Ghana',233),(84,'GI','Gibraltar',350),(85,'GR','Greece',30),(86,'GL','Greenland',299),(87,'GD','Grenada',1473),(88,'GP','Guadeloupe',590),(89,'GU','Guam',1671),(90,'GT','Guatemala',502),(91,'XU','Guernsey and Alderney',44),(92,'GN','Guinea',224),(93,'GW','Guinea-Bissau',245),(94,'GY','Guyana',592),(95,'HT','Haiti',509),(96,'HM','Heard and McDonald Islands',0),(97,'HN','Honduras',504),(98,'HK','Hong Kong S.A.R.',852),(99,'HU','Hungary',36),(100,'IS','Iceland',354),(101,'IN','India',91),(102,'ID','Indonesia',62),(103,'IR','Iran',98),(104,'IQ','Iraq',964),(105,'IE','Ireland',353),(106,'IL','Israel',972),(107,'IT','Italy',39),(108,'JM','Jamaica',1876),(109,'JP','Japan',81),(110,'XJ','Jersey',44),(111,'JO','Jordan',962),(112,'KZ','Kazakhstan',7),(113,'KE','Kenya',254),(114,'KI','Kiribati',686),(115,'KP','Korea North',850),(116,'KR','Korea South',82),(117,'KW','Kuwait',965),(118,'KG','Kyrgyzstan',996),(119,'LA','Laos',856),(120,'LV','Latvia',371),(121,'LB','Lebanon',961),(122,'LS','Lesotho',266),(123,'LR','Liberia',231),(124,'LY','Libya',218),(125,'LI','Liechtenstein',423),(126,'LT','Lithuania',370),(127,'LU','Luxembourg',352),(128,'MO','Macau S.A.R.',853),(129,'MK','Macedonia',389),(130,'MG','Madagascar',261),(131,'MW','Malawi',265),(132,'MY','Malaysia',60),(133,'MV','Maldives',960),(134,'ML','Mali',223),(135,'MT','Malta',356),(136,'XM','Man (Isle of)',44),(137,'MH','Marshall Islands',692),(138,'MQ','Martinique',596),(139,'MR','Mauritania',222),(140,'MU','Mauritius',230),(141,'YT','Mayotte',269),(142,'MX','Mexico',52),(143,'FM','Micronesia',691),(144,'MD','Moldova',373),(145,'MC','Monaco',377),(146,'MN','Mongolia',976),(147,'MS','Montserrat',1664),(148,'MA','Morocco',212),(149,'MZ','Mozambique',258),(150,'MM','Myanmar',95),(151,'NA','Namibia',264),(152,'NR','Nauru',674),(153,'NP','Nepal',977),(154,'AN','Netherlands Antilles',599),(155,'NL','Netherlands The',31),(156,'NC','New Caledonia',687),(157,'NZ','New Zealand',64),(158,'NI','Nicaragua',505),(159,'NE','Niger',227),(160,'NG','Nigeria',234),(161,'NU','Niue',683),(162,'NF','Norfolk Island',672),(163,'MP','Northern Mariana Islands',1670),(164,'NO','Norway',47),(165,'OM','Oman',968),(166,'PK','Pakistan',92),(167,'PW','Palau',680),(168,'PS','Palestinian Territory Occupied',970),(169,'PA','Panama',507),(170,'PG','Papua new Guinea',675),(171,'PY','Paraguay',595),(172,'PE','Peru',51),(173,'PH','Philippines',63),(174,'PN','Pitcairn Island',0),(175,'PL','Poland',48),(176,'PT','Portugal',351),(177,'PR','Puerto Rico',1787),(178,'QA','Qatar',974),(179,'RE','Reunion',262),(180,'RO','Romania',40),(181,'RU','Russia',70),(182,'RW','Rwanda',250),(183,'SH','Saint Helena',290),(184,'KN','Saint Kitts And Nevis',1869),(185,'LC','Saint Lucia',1758),(186,'PM','Saint Pierre and Miquelon',508),(187,'VC','Saint Vincent And The Grenadines',1784),(188,'WS','Samoa',684),(189,'SM','San Marino',378),(190,'ST','Sao Tome and Principe',239),(191,'SA','Saudi Arabia',966),(192,'SN','Senegal',221),(193,'RS','Serbia',381),(194,'SC','Seychelles',248),(195,'SL','Sierra Leone',232),(196,'SG','Singapore',65),(197,'SK','Slovakia',421),(198,'SI','Slovenia',386),(199,'XG','Smaller Territories of the UK',44),(200,'SB','Solomon Islands',677),(201,'SO','Somalia',252),(202,'ZA','South Africa',27),(203,'GS','South Georgia',0),(204,'SS','South Sudan',211),(205,'ES','Spain',34),(206,'LK','Sri Lanka',94),(207,'SD','Sudan',249),(208,'SR','Suriname',597),(209,'SJ','Svalbard And Jan Mayen Islands',47),(210,'SZ','Swaziland',268),(211,'SE','Sweden',46),(212,'CH','Switzerland',41),(213,'SY','Syria',963),(214,'TW','Taiwan',886),(215,'TJ','Tajikistan',992),(216,'TZ','Tanzania',255),(217,'TH','Thailand',66),(218,'TG','Togo',228),(219,'TK','Tokelau',690),(220,'TO','Tonga',676),(221,'TT','Trinidad And Tobago',1868),(222,'TN','Tunisia',216),(223,'TR','Turkey',90),(224,'TM','Turkmenistan',7370),(225,'TC','Turks And Caicos Islands',1649),(226,'TV','Tuvalu',688),(227,'UG','Uganda',256),(228,'UA','Ukraine',380),(229,'AE','United Arab Emirates',971),(230,'GB','United Kingdom',44),(231,'US','United States',1),(232,'UM','United States Minor Outlying Islands',1),(233,'UY','Uruguay',598),(234,'UZ','Uzbekistan',998),(235,'VU','Vanuatu',678),(236,'VA','Vatican City State (Holy See)',39),(237,'VE','Venezuela',58),(238,'VN','Vietnam',84),(239,'VG','Virgin Islands (British)',1284),(240,'VI','Virgin Islands (US)',1340),(241,'WF','Wallis And Futuna Islands',681),(242,'EH','Western Sahara',212),(243,'YE','Yemen',967),(244,'YU','Yugoslavia',38),(245,'ZM','Zambia',260),(246,'ZW','Zimbabwe',263);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacont`
--

DROP TABLE IF EXISTS `datacont`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datacont` (
  `id` int(6) unsigned NOT NULL,
  `data` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacont`
--

LOCK TABLES `datacont` WRITE;
/*!40000 ALTER TABLE `datacont` DISABLE KEYS */;
INSERT INTO `datacont` VALUES (1,_binary '<h2>OVIPanel is customized for</h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li>1. Automatic Website Optimization for Speed</li>\r\n	<li>2. Website Security Enhancement</li>\r\n	<li>3. Cache for Static Files, Faster Website Loading</li>\r\n	<li>4. Light Weight Control Panel</li>\r\n	<li>5. Option to Choose Apache Vs Ngnix (The fastest web server)</li>\r\n	<li>6. Gmail like Webmail Client (rainloop)</li>\r\n</ol>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<div class=\"note\">Note: The above features are not available in other control panel.</div>\r\n\r\n<p>&nbsp;</p>\r\n'),(2,_binary '<h1>Your hosting space is ready... </h1><p>Your web hosting space is now active and ready to be used.</p><p><b>To get started:</b><ol><li><p>Login to your OVIPanel</p></li><li><p>Create an FTP account</p></li><li><p>Replace or delete this file (index.php)</p></li></ol></p><p>Thank you for using OVIPanel to manage your hosting!</p><p><b>For more information and help using OVIPanel please </b> <a href=\"https://www.youtube.com/watch?v=WNlsR-R1fZo\" target=\"_blank\">Click</a> here.</p><p>Kind regards,<br>Your hosting company.</p>');
/*!40000 ALTER TABLE `datacont` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vps_migration_process`
--

DROP TABLE IF EXISTS `vps_migration_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vps_migration_process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mig_userid` int(11) NOT NULL,
  `flag` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_registered_email_id` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip_address` varchar(20) NOT NULL,
  `backup_file_name` varchar(255) NOT NULL,
  `ftp_user` varchar(50) NOT NULL,
  `ftp_pass` varchar(50) NOT NULL,
  `backup_download_link` varchar(255) NOT NULL,
  `backup_status` int(11) NOT NULL,
  `restore_status` int(11) NOT NULL,
  `create_user` varchar(255) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vps_migration_process`
--

LOCK TABLES `vps_migration_process` WRITE;
/*!40000 ALTER TABLE `vps_migration_process` DISABLE KEYS */;
/*!40000 ALTER TABLE `vps_migration_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_accounts`
--

DROP TABLE IF EXISTS `x_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_accounts` (
  `ac_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `ac_user_vc` varchar(50) DEFAULT NULL,
  `ac_pass_vc` varchar(200) DEFAULT NULL,
  `ac_email_vc` varchar(250) DEFAULT NULL,
  `ac_reseller_fk` int(6) DEFAULT NULL,
  `ac_package_fk` int(6) DEFAULT NULL,
  `ac_group_fk` int(6) DEFAULT NULL,
  `ac_usertheme_vc` varchar(45) DEFAULT NULL,
  `ac_usercss_vc` varchar(45) DEFAULT NULL,
  `ac_enabled_in` int(1) DEFAULT '1',
  `ac_lastlogon_ts` int(30) DEFAULT NULL,
  `ac_notice_tx` text,
  `ac_resethash_tx` text,
  `ac_passsalt_vc` varchar(22) DEFAULT NULL,
  `ac_catorder_vc` varchar(255) DEFAULT NULL,
  `ac_created_ts` int(30) DEFAULT NULL,
  `ac_deleted_ts` int(30) DEFAULT NULL,
  `ip_deleted` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ac_id_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_accounts`
--

LOCK TABLES `x_accounts` WRITE;
/*!40000 ALTER TABLE `x_accounts` DISABLE KEYS */;
INSERT INTO `x_accounts` VALUES (1,'zadmin','cQ7syEv.UjqRHHcb9WyJOSS/VQ8hMia','saravana@hostingraja.in',1,1,1,'acp-master','default',1,1548332585,'',NULL,'Y93hYPtNLyQEM4xxXvIW4y','[\"1\",\"6\",\"8\",\"5\",\"4\",\"3\",\"7\",\"2\",\"9\"]',0,NULL,NULL);
/*!40000 ALTER TABLE `x_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_aliases`
--

DROP TABLE IF EXISTS `x_aliases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_aliases` (
  `al_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `al_acc_fk` int(6) DEFAULT NULL,
  `al_address_vc` varchar(255) DEFAULT NULL,
  `al_destination_vc` varchar(255) DEFAULT NULL,
  `al_created_ts` int(30) DEFAULT NULL,
  `al_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`al_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_aliases`
--

LOCK TABLES `x_aliases` WRITE;
/*!40000 ALTER TABLE `x_aliases` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_aliases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_apache_setting`
--

DROP TABLE IF EXISTS `x_apache_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_apache_setting` (
  `x_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_parameter` varchar(100) NOT NULL,
  `x_value` varchar(100) NOT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_apache_setting`
--

LOCK TABLES `x_apache_setting` WRITE;
/*!40000 ALTER TABLE `x_apache_setting` DISABLE KEYS */;
INSERT INTO `x_apache_setting` VALUES (1,'KeepAlive_setting','On'),(2,'StartServers','2'),(3,'MinSpareServers','5'),(4,'MaxSpareServers','10'),(5,'MaxRequestWorkers','400'),(6,'ServerLimit','500'),(7,'MaxRequestsPerChild','0');
/*!40000 ALTER TABLE `x_apache_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_apachesapm_filters`
--

DROP TABLE IF EXISTS `x_apachesapm_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_apachesapm_filters` (
  `x_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_user_id` int(11) NOT NULL,
  `x_domain_list` blob NOT NULL,
  `x_flag` varchar(25) NOT NULL,
  `x_updatedtime` int(30) NOT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_apachesapm_filters`
--

LOCK TABLES `x_apachesapm_filters` WRITE;
/*!40000 ALTER TABLE `x_apachesapm_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_apachesapm_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_apachespam_settings`
--

DROP TABLE IF EXISTS `x_apachespam_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_apachespam_settings` (
  `x_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_status` varchar(10) NOT NULL,
  `x_auto_delete` varchar(10) NOT NULL,
  `x_score` varchar(10) NOT NULL,
  `x_spam_enable` varchar(20) NOT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_apachespam_settings`
--

LOCK TABLES `x_apachespam_settings` WRITE;
/*!40000 ALTER TABLE `x_apachespam_settings` DISABLE KEYS */;
INSERT INTO `x_apachespam_settings` VALUES (1,'No','No','5','1');
/*!40000 ALTER TABLE `x_apachespam_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_autorespond`
--

DROP TABLE IF EXISTS `x_autorespond`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_autorespond` (
  `vh_id` int(11) NOT NULL AUTO_INCREMENT,
  `vh_mail` varchar(150) DEFAULT NULL,
  `vh_sub` varchar(100) DEFAULT NULL,
  `vh_from` varchar(100) DEFAULT NULL,
  `vh_html_status` int(1) DEFAULT NULL,
  `vh_body` text,
  `vh_acc_fk` int(11) DEFAULT NULL,
  `vh_did` int(11) DEFAULT NULL,
  `vh_deleted` varchar(15) DEFAULT NULL,
  `vh_created` varchar(15) DEFAULT NULL,
  `vh_updated` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`vh_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_autorespond`
--

LOCK TABLES `x_autorespond` WRITE;
/*!40000 ALTER TABLE `x_autorespond` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_autorespond` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_autouser`
--

DROP TABLE IF EXISTS `x_autouser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_autouser` (
  `my_id_pk` int(11) NOT NULL AUTO_INCREMENT,
  `my_acc_pk` varchar(20) DEFAULT NULL,
  `my_user_vc` varchar(30) DEFAULT NULL,
  `my_pass_vc` varchar(30) DEFAULT NULL,
  `my_created_ts` varchar(20) DEFAULT NULL,
  `my_exp_ts` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`my_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_autouser`
--

LOCK TABLES `x_autouser` WRITE;
/*!40000 ALTER TABLE `x_autouser` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_autouser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_backup_setting`
--

DROP TABLE IF EXISTS `x_backup_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_backup_setting` (
  `bk_id` int(6) NOT NULL AUTO_INCREMENT,
  `bk_user_id` int(6) NOT NULL,
  `bk_type` varchar(30) NOT NULL,
  `bk_enable` varchar(5) NOT NULL,
  PRIMARY KEY (`bk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_backup_setting`
--

LOCK TABLES `x_backup_setting` WRITE;
/*!40000 ALTER TABLE `x_backup_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_backup_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_bandwidth`
--

DROP TABLE IF EXISTS `x_bandwidth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_bandwidth` (
  `bd_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `bd_acc_fk` int(6) DEFAULT NULL,
  `bd_month_in` int(6) DEFAULT NULL,
  `bd_transamount_bi` bigint(20) DEFAULT NULL,
  `bd_diskamount_bi` bigint(20) DEFAULT NULL,
  `bd_diskover_in` int(6) DEFAULT NULL,
  `bd_diskcheck_in` int(6) DEFAULT NULL,
  `bd_transover_in` int(6) DEFAULT NULL,
  `bd_transcheck_in` int(6) DEFAULT NULL,
  PRIMARY KEY (`bd_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_bandwidth`
--

LOCK TABLES `x_bandwidth` WRITE;
/*!40000 ALTER TABLE `x_bandwidth` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_bandwidth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_changeip`
--

DROP TABLE IF EXISTS `x_changeip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_changeip` (
  `ci_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `ci_acc_fk` int(6) DEFAULT NULL,
  `ci_user_vc` varchar(255) DEFAULT NULL,
  `ci_ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ci_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_changeip`
--

LOCK TABLES `x_changeip` WRITE;
/*!40000 ALTER TABLE `x_changeip` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_changeip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_cronemail`
--

DROP TABLE IF EXISTS `x_cronemail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_cronemail` (
  `ce_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `ce_acc_fk` int(6) DEFAULT NULL,
  `ce_email_vc` varchar(255) DEFAULT NULL,
  `ce_created_ts` int(30) DEFAULT NULL,
  `ce_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`ce_id_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_cronemail`
--

LOCK TABLES `x_cronemail` WRITE;
/*!40000 ALTER TABLE `x_cronemail` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_cronemail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_cronjobs`
--

DROP TABLE IF EXISTS `x_cronjobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_cronjobs` (
  `ct_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `ct_acc_fk` int(6) DEFAULT NULL,
  `ct_script_vc` varchar(255) DEFAULT NULL,
  `ct_timing_vc` varchar(255) DEFAULT NULL,
  `ct_fullpath_vc` varchar(255) DEFAULT NULL,
  `ct_description_tx` text,
  `ct_created_ts` int(30) DEFAULT NULL,
  `ct_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`ct_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_cronjobs`
--

LOCK TABLES `x_cronjobs` WRITE;
/*!40000 ALTER TABLE `x_cronjobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_cronjobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_csr`
--

DROP TABLE IF EXISTS `x_csr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_csr` (
  `csr_no` int(20) NOT NULL AUTO_INCREMENT,
  `userid` int(20) NOT NULL,
  `csr_domain` varchar(250) NOT NULL,
  `csr_organization` varchar(250) NOT NULL,
  `csr_department` varchar(250) NOT NULL,
  `csr_city` varchar(250) NOT NULL,
  `csr_state` varchar(250) NOT NULL,
  `csr_country` varchar(250) NOT NULL,
  `csr_created` int(30) DEFAULT NULL,
  `csr_delete` int(30) DEFAULT NULL,
  PRIMARY KEY (`csr_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_csr`
--

LOCK TABLES `x_csr` WRITE;
/*!40000 ALTER TABLE `x_csr` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_csr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_database_settings`
--

DROP TABLE IF EXISTS `x_database_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_database_settings` (
  `ds_id_pk` int(11) NOT NULL AUTO_INCREMENT,
  `ds_enabled_in` int(4) NOT NULL,
  `ds_user_vc` varchar(25) NOT NULL,
  `ds_updated_vc` varchar(200) NOT NULL,
  PRIMARY KEY (`ds_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_database_settings`
--

LOCK TABLES `x_database_settings` WRITE;
/*!40000 ALTER TABLE `x_database_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_database_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_diskusage`
--

DROP TABLE IF EXISTS `x_diskusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_diskusage` (
  `ac_id_pk` int(6) unsigned NOT NULL,
  `ac_used_space` varchar(250) DEFAULT '0',
  PRIMARY KEY (`ac_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_diskusage`
--

LOCK TABLES `x_diskusage` WRITE;
/*!40000 ALTER TABLE `x_diskusage` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_diskusage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_distlists`
--

DROP TABLE IF EXISTS `x_distlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_distlists` (
  `dl_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `dl_acc_fk` int(6) DEFAULT NULL,
  `dl_address_vc` varchar(255) DEFAULT NULL,
  `dl_created_ts` int(30) DEFAULT NULL,
  `dl_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`dl_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_distlists`
--

LOCK TABLES `x_distlists` WRITE;
/*!40000 ALTER TABLE `x_distlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_distlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_distlistusers`
--

DROP TABLE IF EXISTS `x_distlistusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_distlistusers` (
  `du_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `du_distlist_fk` int(6) DEFAULT NULL,
  `du_address_vc` varchar(255) DEFAULT NULL,
  `du_created_ts` int(30) DEFAULT NULL,
  `du_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`du_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_distlistusers`
--

LOCK TABLES `x_distlistusers` WRITE;
/*!40000 ALTER TABLE `x_distlistusers` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_distlistusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_dns`
--

DROP TABLE IF EXISTS `x_dns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_dns` (
  `dn_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `dn_acc_fk` int(6) DEFAULT NULL,
  `dn_name_vc` varchar(255) DEFAULT NULL,
  `dn_vhost_fk` int(6) DEFAULT NULL,
  `dn_type_vc` varchar(50) DEFAULT NULL,
  `dn_host_vc` varchar(100) DEFAULT NULL,
  `dn_ttl_in` int(30) DEFAULT NULL,
  `dn_target_vc` varchar(512) DEFAULT NULL,
  `dn_texttarget_tx` text,
  `dn_priority_in` int(50) DEFAULT NULL,
  `dn_weight_in` int(50) DEFAULT NULL,
  `dn_port_in` int(50) DEFAULT NULL,
  `dn_created_ts` int(30) DEFAULT NULL,
  `dn_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`dn_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_dns`
--

LOCK TABLES `x_dns` WRITE;
/*!40000 ALTER TABLE `x_dns` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_dns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_dns_create`
--

DROP TABLE IF EXISTS `x_dns_create`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_dns_create` (
  `dc_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `dc_acc_fk` int(6) DEFAULT NULL,
  `dc_type_vc` varchar(50) DEFAULT NULL,
  `dc_host_vc` varchar(100) DEFAULT NULL,
  `dc_ttl_in` int(30) DEFAULT NULL,
  `dc_target_vc` varchar(512) DEFAULT NULL,
  `dc_priority_in` int(50) DEFAULT NULL,
  `dc_weight_in` int(50) DEFAULT NULL,
  `dc_port_in` int(50) DEFAULT NULL,
  PRIMARY KEY (`dc_id_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_dns_create`
--

LOCK TABLES `x_dns_create` WRITE;
/*!40000 ALTER TABLE `x_dns_create` DISABLE KEYS */;
INSERT INTO `x_dns_create` VALUES (1,0,'A','@',3600,':IP:',NULL,NULL,NULL),(2,0,'CNAME','www',3600,'@',NULL,NULL,NULL),(3,0,'CNAME','ftp',3600,'@',NULL,NULL,NULL),(4,0,'A','mail',86400,':IP:',NULL,NULL,NULL),(5,0,'MX','@',86400,'mail.:DOMAIN:',10,NULL,NULL),(6,0,'A','ns1',172800,':IP:',NULL,NULL,NULL),(7,0,'A','ns2',172800,':IP:',NULL,NULL,NULL),(8,0,'NS','@',172800,'ns1.:DOMAIN:',NULL,NULL,NULL),(9,0,'NS','@',172800,'ns2.:DOMAIN:',NULL,NULL,NULL);
INSERT INTO x_dns_create (dc_acc_fk,dc_type_vc,dc_host_vc,dc_ttl_in,dc_target_vc,dc_priority_in,dc_weight_in,dc_port_in) VALUES ('0', 'TXT', '@', '3600', 'v=spf1 a mx mx::DOMAIN: ip4::IP: ~all', 'NULL', 'NULL', 'NULL');
INSERT INTO x_dns_create (dc_acc_fk,dc_type_vc,dc_host_vc,dc_ttl_in,dc_target_vc,dc_priority_in,dc_weight_in,dc_port_in) VALUES ('0', 'TXT', '_dmarc', '3600', 'v=DMARC1; p=none;', 'NULL', 'NULL', 'NULL');
/*!40000 ALTER TABLE `x_dns_create` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_faqs`
--

DROP TABLE IF EXISTS `x_faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_faqs` (
  `fq_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `fq_acc_fk` int(6) DEFAULT NULL,
  `fq_question_tx` text,
  `fq_answer_tx` text,
  `fq_global_in` int(1) DEFAULT NULL,
  `fq_created_ts` int(30) DEFAULT NULL,
  `fq_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`fq_id_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_faqs`
--

LOCK TABLES `x_faqs` WRITE;
/*!40000 ALTER TABLE `x_faqs` DISABLE KEYS */;
INSERT INTO `x_faqs` VALUES (1,1,'How can I update my personal contact details?','From the control panel homepage please click on the &quot;My Account&quot; icon to enable you to update your personal details.',1,NULL,NULL),(2,1,'How do I change my password?','Your Ovipanel and MySQL password can be easily changed using the &quot;Change Password&quot; icon on the control panel.',1,NULL,NULL),(3,1,'I don&#39;t think one of the services(Apache, MySQL, FTP, etc) are running. Is there any easy way to check?','Ovipanel comes with a service monitoring system that checks to make sure all the services are up and running, Simply go to your Control Panel Home and select the module called &quot;Service Status&quot;. From there you will be able to see if any of the services are down or up.',1,NULL,NULL),(7,1,'How can I create a MySQL Database?','To create a MySQL database simply go to the section of the panel called &quot;Database Management&quot; and select the module called &quot;MySQL Databases&quot; from here you will easily be able to add and manage databases on your account.',1,NULL,NULL),(8,1,'What is phpMyAdmin?','phpMyAdmin is an open source tool intended to handle the administration of MySQL databases. It can perform various tasks such as creating, modifying or deleting databases, tables, fields or rows or executing SQL statements',1,NULL,NULL),(9,1,'How do I create FTP Accounts?','You can create FTP accounts by going to &quot;FTP Accounts&quot; from their you can add accounts and manage quotas and directories. ',1,NULL,NULL),(11,1,'How do I create an E-Mail Account?','Go to the Mail section of Ovipanel and select the module called &quot;Mailboxes&quot;, from here you can create E-Mail account for each domain setup on your account. You can also reset passwords to previously created accounts.',1,NULL,NULL),(12,1,'How do I create a Mail Alias?','Go to the Mail section of Ovipanel and select the module called &quot;Aliases&quot;, from here you can create Alias E-Mail accounts for each previously created E-Mail account. All mail sent to the alias will be delivered to the master e-mail account.',1,NULL,NULL),(13,1,'How can I create a Mailing List?','Mailing lists can be setup by going to the Mail section of Ovipanel and select the module called &quot;Distribution Lists&quot;, from here you can create Mailing lists by creating an E-mail Account. ',1,NULL,NULL),(14,1,'How do I use Mail Forwards?','Go to the Mail section of Ovipanel and select the module called &quot;Forwards&quot;, from here you can create E-Mail address on your domains that will forward to other E-Mail addresses that are on different servers like &quot;G-Mail, Yahoo, and MSN&quot;. ',1,NULL,NULL),(15,1,'What are Subdomains?','A subdomain combines a unique identifier with a domain name to become essentially a &quot;domain within a domain.&quot; The unique identifier simply replaces the www in the web address. Yahoo!, for example, uses subdomains such as mail.yahoo.com and music.yahoo.com to reference its mail and music services, under the umbrella of www.yahoo.com. They can be created by using the Subdomain module in the Domains section. You can assign directories for each sub domain from the module.',1,NULL,NULL),(16,1,'How can I view how much Data I have used?','You can view how much data you have used by accessing the &quot;Usage Viewer&quot; under the Account Information section of Ovipanel. It displays account information in different formats. It displays Data Usage, Domain Usage, Bandwidth Usage, MySQL Usage, and much more.',1,NULL,NULL),(17,1,'How can I access Webmail?','Go to the Mail section of Ovipanel and select the module called &quot;Webmail&quot;, from here you can login to your E-Mail account and view and create messages. ',1,NULL,NULL);
/*!40000 ALTER TABLE `x_faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_forwarded_domains`
--

DROP TABLE IF EXISTS `x_forwarded_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_forwarded_domains` (
  `fd_id_pk` int(11) NOT NULL AUTO_INCREMENT,
  `vh_fk_id` int(11) NOT NULL DEFAULT '0',
  `fd_acc_fk` int(11) NOT NULL DEFAULT '0',
  `fd_name` varchar(75) NOT NULL DEFAULT '',
  `fd_type_id` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1=redirect, 2=forward',
  `fd_protocol` varchar(5) NOT NULL DEFAULT 'http',
  `www_yn` tinyint(1) NOT NULL DEFAULT '1',
  `fd_created_ts` int(30) NOT NULL DEFAULT '0',
  `fd_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`fd_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_forwarded_domains`
--

LOCK TABLES `x_forwarded_domains` WRITE;
/*!40000 ALTER TABLE `x_forwarded_domains` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_forwarded_domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_forwarders`
--

DROP TABLE IF EXISTS `x_forwarders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_forwarders` (
  `fw_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `fw_acc_fk` int(6) DEFAULT NULL,
  `fw_address_vc` varchar(255) DEFAULT NULL,
  `fw_destination_vc` varchar(255) DEFAULT NULL,
  `fw_keepmessage_in` int(1) DEFAULT '1',
  `fw_created_ts` int(30) DEFAULT NULL,
  `fw_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`fw_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_forwarders`
--

LOCK TABLES `x_forwarders` WRITE;
/*!40000 ALTER TABLE `x_forwarders` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_forwarders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_frequently_access`
--

DROP TABLE IF EXISTS `x_frequently_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_frequently_access` (
  `ac_id_pk` int(6) NOT NULL,
  `mo_folder_vc` varchar(255) NOT NULL,
  `access_count` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_frequently_access`
--

LOCK TABLES `x_frequently_access` WRITE;
/*!40000 ALTER TABLE `x_frequently_access` DISABLE KEYS */;
INSERT INTO `x_frequently_access` VALUES (1,'manage_clients',1);
/*!40000 ALTER TABLE `x_frequently_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_ftpaccounts`
--

DROP TABLE IF EXISTS `x_ftpaccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_ftpaccounts` (
  `ft_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `ft_acc_fk` int(6) DEFAULT NULL,
  `ft_user_vc` varchar(50) DEFAULT NULL,
  `ft_directory_vc` varchar(255) DEFAULT NULL,
  `ft_access_vc` varchar(20) DEFAULT NULL,
  `ft_password_vc` varchar(50) DEFAULT NULL,
  `ft_created_ts` int(6) DEFAULT NULL,
  `ft_deleted_ts` int(6) DEFAULT NULL,
  `ip_deleted` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ft_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_ftpaccounts`
--

LOCK TABLES `x_ftpaccounts` WRITE;
/*!40000 ALTER TABLE `x_ftpaccounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_ftpaccounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_groups`
--

DROP TABLE IF EXISTS `x_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_groups` (
  `ug_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `ug_name_vc` varchar(20) DEFAULT NULL,
  `ug_notes_tx` text,
  `ug_reseller_fk` int(6) DEFAULT NULL,
  PRIMARY KEY (`ug_id_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_groups`
--

LOCK TABLES `x_groups` WRITE;
/*!40000 ALTER TABLE `x_groups` DISABLE KEYS */;
INSERT INTO `x_groups` VALUES (1,'Administrators','The main administration group, this group allows access to all areas of Ovipanel.',1),(2,'Resellers','Resellers have the ability to manage, create and maintain user accounts within Ovipanel.',1),(3,'Users','Users have basic access to Ovipanel.',1);
/*!40000 ALTER TABLE `x_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_header_checks`
--

DROP TABLE IF EXISTS `x_header_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_header_checks` (
  `x_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_filtername` varchar(100) NOT NULL,
  `x_rule_1` varchar(255) NOT NULL,
  `x_rule_2` varchar(255) NOT NULL,
  `x_rule_3` varchar(255) NOT NULL,
  `x_actions_1` varchar(100) NOT NULL,
  `x_created_by` int(10) NOT NULL,
  `x_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_header_checks`
--

LOCK TABLES `x_header_checks` WRITE;
/*!40000 ALTER TABLE `x_header_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_header_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_htaccess`
--

DROP TABLE IF EXISTS `x_htaccess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_htaccess` (
  `ht_id_pk` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ht_acc_fk` int(6) DEFAULT NULL,
  `ht_user_vc` varchar(10) DEFAULT NULL,
  `ht_dir_vc` varchar(255) DEFAULT NULL,
  `ht_created_ts` int(30) DEFAULT NULL,
  `ht_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`ht_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_htaccess`
--

LOCK TABLES `x_htaccess` WRITE;
/*!40000 ALTER TABLE `x_htaccess` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_htaccess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_htpasswd_file`
--

DROP TABLE IF EXISTS `x_htpasswd_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_htpasswd_file` (
  `x_htpasswd_file_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_htpasswd_file_target` varchar(255) NOT NULL,
  `x_htpasswd_file_message` varchar(255) NOT NULL,
  `x_htpasswd_file_created` int(11) NOT NULL,
  `x_htpasswd_file_deleted` int(11) DEFAULT NULL,
  `x_htpasswd_sentora_user_id` int(11) NOT NULL,
  PRIMARY KEY (`x_htpasswd_file_id`),
  UNIQUE KEY `x_htpasswd_file_target` (`x_htpasswd_file_target`),
  KEY `x_htpasswd_file_x_htpasswd_sentora_user_id_idx` (`x_htpasswd_sentora_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_htpasswd_file`
--

LOCK TABLES `x_htpasswd_file` WRITE;
/*!40000 ALTER TABLE `x_htpasswd_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_htpasswd_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_htpasswd_mapper`
--

DROP TABLE IF EXISTS `x_htpasswd_mapper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_htpasswd_mapper` (
  `x_htpasswd_mapper_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_htpasswd_file_id` int(11) NOT NULL,
  `x_htpasswd_user_id` int(11) NOT NULL,
  PRIMARY KEY (`x_htpasswd_mapper_id`),
  KEY `x_htpasswd_mapper_x_htpasswd_file_id_idx` (`x_htpasswd_file_id`),
  KEY `x_htpasswd_mapper_x_htpasswd_user_id_idx` (`x_htpasswd_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_htpasswd_mapper`
--

LOCK TABLES `x_htpasswd_mapper` WRITE;
/*!40000 ALTER TABLE `x_htpasswd_mapper` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_htpasswd_mapper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_htpasswd_user`
--

DROP TABLE IF EXISTS `x_htpasswd_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_htpasswd_user` (
  `x_htpasswd_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_htpasswd_user_username` varchar(255) NOT NULL,
  `x_htpasswd_user_password` varchar(255) NOT NULL,
  `x_htpasswd_user_created` int(11) NOT NULL,
  `x_htpasswd_user_deleted` int(11) DEFAULT NULL,
  `x_htpasswd_sentora_user_id` int(11) NOT NULL,
  PRIMARY KEY (`x_htpasswd_user_id`),
  UNIQUE KEY `x_htpasswd_user_username` (`x_htpasswd_user_username`),
  UNIQUE KEY `x_htpasswd_user_password` (`x_htpasswd_user_password`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_htpasswd_user`
--

LOCK TABLES `x_htpasswd_user` WRITE;
/*!40000 ALTER TABLE `x_htpasswd_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_htpasswd_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_last_mail_exceed`
--

DROP TABLE IF EXISTS `x_last_mail_exceed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_last_mail_exceed` (
  `x_id` int(2) NOT NULL AUTO_INCREMENT,
  `x_date` varchar(250) NOT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_last_mail_exceed`
--

LOCK TABLES `x_last_mail_exceed` WRITE;
/*!40000 ALTER TABLE `x_last_mail_exceed` DISABLE KEYS */;
INSERT INTO `x_last_mail_exceed` VALUES (1,'31/08/1991');
/*!40000 ALTER TABLE `x_last_mail_exceed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_logAttempts`
--

DROP TABLE IF EXISTS `x_logAttempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_logAttempts` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `remote_address` varchar(255) NOT NULL,
  `log_fail` int(11) NOT NULL,
  `log_time` varchar(255) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_logAttempts`
--

LOCK TABLES `x_logAttempts` WRITE;
/*!40000 ALTER TABLE `x_logAttempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_logAttempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_logs`
--

DROP TABLE IF EXISTS `x_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_logs` (
  `lg_id_pk` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `lg_user_fk` int(6) NOT NULL DEFAULT '1',
  `lg_code_vc` varchar(10) DEFAULT NULL,
  `lg_module_vc` varchar(25) DEFAULT NULL,
  `lg_detail_tx` text,
  `lg_stack_tx` text,
  `lg_when_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`lg_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_logs`
--

LOCK TABLES `x_logs` WRITE;
/*!40000 ALTER TABLE `x_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_mailboxes`
--

DROP TABLE IF EXISTS `x_mailboxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_mailboxes` (
  `mb_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `mb_acc_fk` int(6) DEFAULT NULL,
  `mb_address_vc` varchar(255) DEFAULT NULL,
  `mb_size` int(50) DEFAULT NULL,
  `mailperhrlimt_size` int(11) NOT NULL,
  `mb_enabled_in` int(1) DEFAULT '1',
  `mb_created_ts` int(30) DEFAULT NULL,
  `mb_deleted_ts` int(30) DEFAULT NULL,
  `mb_quota` bigint(10) DEFAULT NULL,
  `ip_deleted` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`mb_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_mailboxes`
--

LOCK TABLES `x_mailboxes` WRITE;
/*!40000 ALTER TABLE `x_mailboxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_mailboxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_main_domain`
--

DROP TABLE IF EXISTS `x_main_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_main_domain` (
  `x_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_user_id` int(11) NOT NULL,
  `x_domain_id` int(11) NOT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_main_domain`
--

LOCK TABLES `x_main_domain` WRITE;
/*!40000 ALTER TABLE `x_main_domain` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_main_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_modcats`
--

DROP TABLE IF EXISTS `x_modcats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_modcats` (
  `mc_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `mc_name_vc` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`mc_id_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_modcats`
--

LOCK TABLES `x_modcats` WRITE;
/*!40000 ALTER TABLE `x_modcats` DISABLE KEYS */;
INSERT INTO `x_modcats` VALUES (1,'Settings'),(2,'Server Admin'),(3,'Others'),(4,'DB'),(5,'Domain'),(6,'Mail Manager'),(7,'Reseller'),(8,'File Manager'),(9,'Varnish Cache Server'),(10,'Web Security'),(11,'Application');
/*!40000 ALTER TABLE `x_modcats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_modsecurity`
--

DROP TABLE IF EXISTS `x_modsecurity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_modsecurity` (
  `x_mod_no` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `x_domain_id` int(6) NOT NULL,
  `x_mod_status` varchar(30) NOT NULL,
  `x_mod_hook` int(6) DEFAULT '1',
  PRIMARY KEY (`x_mod_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_modsecurity`
--

LOCK TABLES `x_modsecurity` WRITE;
/*!40000 ALTER TABLE `x_modsecurity` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_modsecurity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_modules`
--

DROP TABLE IF EXISTS `x_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_modules` (
  `mo_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `mo_category_fk` int(6) NOT NULL DEFAULT '1',
  `mo_name_vc` varchar(200) NOT NULL,
  `mo_version_in` int(10) DEFAULT NULL,
  `mo_folder_vc` varchar(255) DEFAULT NULL,
  `mo_type_en` enum('user','system','modadmin','lang') NOT NULL DEFAULT 'user',
  `mo_desc_tx` text,
  `mo_installed_ts` int(30) DEFAULT NULL,
  `mo_enabled_en` enum('true','false') NOT NULL DEFAULT 'true',
  `mo_updatever_vc` varchar(10) DEFAULT NULL,
  `mo_updateurl_tx` text,
  PRIMARY KEY (`mo_id_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_modules`
--

LOCK TABLES `x_modules` WRITE;
/*!40000 ALTER TABLE `x_modules` DISABLE KEYS */;
INSERT INTO `x_modules` VALUES (1,2,'PHP Configuration',100,'phpinfo','user','PHPInfo provides you with information regarding the version of PHP running on this system as well as installed PHP extensions and configuration details.',0,'false','',''),(3,2,'Shadowing',100,'shadowing','user','From here you can shadow any of your client\'s accounts, this enables you to automatically login as the user which enables you to offer remote help by seeing what they see!',0,'false','',''),(4,2,'Ovipanel Config',100,'sentoraconfig','user','Changes made here affect the entire Ovipanel configuration, please double check everything before saving changes.',0,'false','',''),(5,2,'OVIpanel News',100,'news','user','Find out all the latest news and information from the OVIpanel project.',0,'false','',''),(6,1,'Updates',100,'updates','user','Check to see if there are any available updates to your version of the Ovipanel software.',0,'true','',''),(8,4,'phpMyAdmin',100,'phpmyadmin','user','phpMyAdmin is a web based tool that enables you to manage your Ovipanel MySQL databases via. the web.',0,'true','',''),(9,1,'Update Contact Information',100,'my_account','user','Current personal details that you have provided us with, We ask that you keep these upto date in case we require to contact you regarding your hosting package.\r\n',0,'true','',''),(10,6,'WebMail',100,'webmail','user','Webmail is a convenient way for you to check your email accounts online without the need to configure an email client.',0,'true','',''),(11,1,'Change Password',100,'password_assistant','user','Change your current control panel password.',0,'true','',''),(12,8,'Backup',100,'backupmgr','user','The backup manager module enables you to backup your entire hosting account including all your MySQL&reg; databases.',0,'true','',''),(14,2,'Service Status',100,'services','user','Here you can check the current status of our services and see what services are up and running and which are down and not.',0,'true','',''),(15,5,'Addon Domains',100,'domains','user','This module enables you to add or configure domain web hosting on your account.',0,'true','',''),(16,5,'Parked Domains',100,'parked_domains','user','Domain parking refers to the registration of an Internet domain name without that domain being used to provide services such as e-mail or a website. If you have any domains that you are not using, then simply park them!',0,'true','',''),(17,5,'Sub Domains',100,'sub_domains','user','This module enables you to add or configure domain web hosting on your account.',0,'true','',''),(18,2,'Module Admin',100,'moduleadmin','user','Administer or configure modules registered with module admin',0,'true','',''),(19,7,'Manage Clients',100,'manage_clients','user','The account manager enables you to view, update and create client accounts.',0,'true','',''),(20,7,'Package Manager',100,'packages','user','Welcome to the Package Manager, using this module enables you to create and manage existing reseller packages on your Ovipanel hosting account.',0,'true','',''),(22,2,'Cron Manager',100,'cron','user','Here you can configure PHP scripts to run automatically at different time intervals.',0,'true','',''),(23,2,'phpSysInfo',100,'phpsysinfo','user','phpSysInfo is a web-based server hardware monitoring tool which enables you to see detailed hardware statistics of your server.',0,'true','',''),(24,4,'MySQL Database',100,'mysql_databases','user','MySQL&reg; databases are used by many PHP applications such as forums and ecommerce systems, below you can manage and create MySQL&reg; databases.',0,'true','',''),(25,8,'Disk Space Usage',100,'usage_viewer','user','The account usage screen enables you to see exactly what you are currently using on your hosting package.',0,'true','',''),(26,8,'FTP Accounts',100,'ftp_management','user','Using this module you can create FTP accounts which will enable you and any other accounts you create to have the ability to upload and manage files on your hosting space.',0,'true','',''),(27,1,'FAQ\'s',100,'faqs','user','Please find a list of the most common questions from users, if you are unable to find a solution to your problem below please then contact your hosting provider. Simply click on the FAQ below to view the solution.',NULL,'true','',''),(28,0,'Apache Config',100,'apache_admin','modadmin','This module enables you to configure Apache Vhost settings for your hosting accounts.',0,'true','',''),(29,5,'DNS Zone Editor',100,'dns_manager','user',NULL,0,'true','',''),(30,0,'DNS Config',100,'dns_admin','modadmin','This module enables you to configure DNS settings for the DNS Manager',NULL,'true','',''),(31,7,'Manage Groups',100,'manage_groups','user','Manage user groups to enable greater control over module permission.',0,'false','',''),(32,6,'Email Manager',100,'mailboxes','user','Using this module you have the ability to create IMAP and POP3 Mailboxes.',0,'true','',''),(33,6,'Email Forwarding',100,'forwarders','user','Using this module you have the ability to create mail forwarders.',0,'true','',''),(34,6,'Mailing Lists',100,'distlists','user','This module enables you to create and manage email distribution groups.',0,'true','',''),(35,6,'Aliases',100,'aliases','user','Using this module you have the ability to create alias mailboxes to existing accounts.',0,'true','',''),(36,0,'Mail Config',100,'mail_admin','modadmin','This module enables you to configure your mail options',NULL,'true','',''),(39,4,'MySQL Users',100,'mysql_users','user','MySQL&reg; Users allows you to add users and permissions to your MySQL&reg; databases.',NULL,'true','',''),(40,0,'FTP Config',100,'ftp_admin','modadmin','This module enables you to configure FTP settings for your hosting accounts.',NULL,'true','',''),(41,0,'Backup Config',100,'backup_admin','modadmin','This module enables you to configure Backup settings for your hosting accounts.',NULL,'true','',''),(42,7,'Client Notice Manager',100,'client_notices','user','Enables resellers to set global notices for their clients.',NULL,'true','',''),(46,1,'Change Style',100,'theme_manager','user','Enables the reseller to set themes configurations for their clients.',0,'false','',''),(47,11,'Webalizer Stats',100,'webalizer_stats','user','You can view many statistics such as visitor infomation, bandwidth used, referal infomation and most viewed pages etc. Web stats are based on Domains and sub-domains so to view web stats for a particular domain or subdomain use the drop-down menu to select the domain or sub-domain you want to view web stats for.',0,'true','',''),(48,10,'Protected Directories',200,'protected_directories','user','Password protect your web applications and directories.',NULL,'true','',''),(50,8,'File Manager',100,'filemanager','user','Manage Your Files',0,'true','100','https://www.ovipanel.com/'),(51,2,'Log Viewer',101,'logviewer','user','This module lets you view Apache logs for your websites.',1468828190,'true',NULL,NULL),(52,11,'Site Software',30000,'sentastico','user','Site Software is an open-source package installation tool which will quickly and effortlessly copy a wide range of open-source web scripts to your hosting space and then re-direct you to the installer to enable you to personalize your setup! By using Site Software you save time and bandwidth by not needing to upload large web scripts to your hosting space.',1468906639,'true','',''),(53,1,'shortcuts',100,'shortcuts','user','UCP shortcuts are links you can add to your desktop or your browserâ€™s bookmarks toolbar. They are an easy way to access UCP.',0,'true','100','https://www.ovipanel.com/'),(54,8,'Backup & Restore',100,'backupwizard','user','The backup manager module enables you to backup your entire hosting account including all your MySQL&reg; databases.',0,'true','','https://www.ovipanel.com/'),(55,0,'Web Server',1,'webserver','user','Welcome to the Web Server, using this module restart your webserver.',0,'true','100','https://www.ovipanel.com/'),(56,0,'Varnish Cache',1,'varnish','user','Welcome to the Web Server, using this module you will enable the varnish cache.',0,'true','100','https://www.ovipanel.com/'),(57,6,'PHPMail Log',1,'mailinfo','user','Php mail log information.',0,'true','100','https://www.ovipanel.com/'),(58,6,'Apache SpamAssassin',1,'apachespamassassin','user','SpamAssassin is a computer program used for e-mail spam filtering.',0,'true','','https://www.ovipanel.com/'),(59,6,'Mail Log',100,'maillog','user','check the mail log',1473156703,'true','',''),(60,2,'PHP Version',1,'phpversion','user','PHP version module is used for upgrade / downgrade your PHP version.',0,'true','','https://www.ovipanel.com/'),(61,10,'PHPExecution Log',1,'phpexecution','user','PHPExecution Log is used to avoid unnecessary file execution in some particular folder.',0,'true','','https://www.ovipanel.com/'),(62,2,'PHP Configuration Editor',1,'phpconfig','user','You may edit your PHP configuration in Basic Mode or in Advanced Mode.',0,'true','',''),(63,2,'Server Information',1,'hardware_info','user','You will see the Server Information',NULL,'true',NULL,NULL),(64,6,'Mail Queue Management',1,'mailq_management','user','You will manage the mail queue',NULL,'true',NULL,NULL),(65,5,'List ParkedDomain',1,'parkeddomainlist','user',' ',NULL,'true',NULL,NULL),(66,5,'List Subdomain',1,'subdomainlist','user',' ',NULL,'true',NULL,NULL),(67,6,'Rain Loop',1,'rainloop','user','Rain loop  is Simple, Modern & Fast web-based Email Client',NULL,'true',NULL,NULL),(68,4,'Database Hosting Settings',1,'database_settings','user','Using this module you can add prefix and underscore to the beginning of database name and username.',NULL,'true',NULL,NULL),(69,1,'Password Strength Configuration',1,'password_strength','user','Using this module you can enable or disable password strength of email,ftp,mysql users,UCP accounts.',NULL,'true',NULL,NULL),(70,2,'Add IP',1,'addip','user','Add server private ip with public ip',NULL,'true',NULL,NULL),(71,4,'Remote MYSQL',100,'remote_mysql_users','user','Add a specific domain name to allow visitors to connect to your MySQL databases. Applications like bulletin boards, online shopping carts, and content management systems require databases to operate. For more information, read the documentation.',0,'true',NULL,NULL),(72,2,'Mod http2',100,'modhttp','user','Enable disable mod http2  for domain',NULL,'false',NULL,NULL),(73,2,'Apache module',100,'apachemodule','user','You can enable and disable unwanted apache module',NULL,'true',NULL,NULL),(74,2,'Secure Upload',1,'cxscgilog','user','You will avoid unnecessary file uploads',NULL,'true',NULL,NULL),(75,1,'Change Appearance ',1,'change_appearance','user','you will customize the appearance of our cntrol panel',NULL,'true',NULL,NULL),(76,6,'Email Auto Reply',1,'autoresponder','user','You can use autoresponders to automatically send a message back to anyone who sends an email to a specified account. ',NULL,'true',NULL,NULL),(77,3,'IP Domain',1,'ipdomain','user','We will change the appearance of IP ',NULL,'false',NULL,NULL),(78,5,'SSL',1,'ssl','user','This module is helpful to create a SSL certification. ',NULL,'true',NULL,NULL),(79,5,'Name Server',1,'ns','user','This module is helpful to assign the name server. ',NULL,'true',NULL,NULL),(80,10,'VirusScanner',1,'virusscanner','user','This module is helpful  for detecting trojans, viruses, malware & other malicious threats.',NULL,'true',NULL,NULL),(81,6,'Authentication',1,'authentication','user','Using this module you have the ability to create DKIM and SPF.',NULL,'true',NULL,NULL),(82,5,'Domain Forwarder',1,'domain_forwarder','user','This module enables you to setup and manage domain forwards.',NULL,'true',NULL,NULL),(83,6,'Account Level Filter',1,'account_filter','user','Account Level Filter enables you to add  rules to match subjects, addresses, or other parts of the message. You can then add  actions to take on a message such as to deliver the message to a different address and then discard it.',NULL,'true',NULL,NULL),(84,10,'CSF',1,'csf','user','<h3> ConfigServer Security & Firewall</h3><br/><b>Kindly open the new tab in browser and give https://yourip:8088 as mentioned below. Refer your server details mail to know the csf usernme and password. Click right top corner Video Tutorial icon to get the documentation</b>',NULL,'true',NULL,NULL),(85,6,'Email Routing',1,'email_routing','modadmin',' Email Routing',NULL,'true',NULL,NULL),(86,5,'CSR',1,'csr','user','This module is helpful to create a CSR certification.',NULL,'true',NULL,NULL),(87,1,'Server Time Zone',1,'servertime','user','To ensure consistency, we strongly recommend that you reboot the server after you change the time zone.',NULL,'true',NULL,NULL),(88,2,'Addmime',1,'addmime','user','This module will give  information  about extension present in server',NULL,'true',NULL,NULL),(89,6,'Maillogtrack',1,'maillogtrack','user','This module provides mail log history details  ',NULL,'true',NULL,NULL),(90,2,'PHPmodule',1,'phpmodule','user','This module is helpful to install  PHP packages ',NULL,'true',NULL,NULL),(91,2,'Apache status',1,'server-status','user','This module is helpful to show the apache full status ',NULL,'true',NULL,NULL),(92,4,'Show MySQL Processes',1,'show_mysql_processes','user','This module is helpful to displaying mysql process list.',0,'true','','https://www.ovipanel.com/'),(93,2,'Graceful Reboot',1,'gracefulreboot','user','This Module helpful to reboot the server gracefully.',0,'true','','https://www.ovipanel.com/'),(94,6,'Email Spam Check',100,'emailspamcheck','user','From here you can check why the mails are going to spam folder. It will take more than a minute to test. So please be patience.',0,'true',NULL,NULL),(95,2,'Cpanel Migration Tool',1,'migration','user','Using this tool, you can either migrate your cpanel account or download it.Enter the IP address, username and password of your cpanel account hosted in another server to migrate or download.',0,'true','',''),(96,2,'Hostname Change',100,'hostname_change','user','From here you can change your hostname.',0,'true',NULL,NULL),(97,11,'One click Wordpress Installation',100,'wordpress_installation','user','Install Your Wordpress Blog website for your domain in One Click By fill up the below.',0,'true',NULL,NULL),(98,4,'Change MySQL Root Password',100,'change_mysql_root_password','user','Change MySQL Root Password can be change using this module',0,'true',NULL,NULL),(99,2,'Assign Domain-IP',100,'assign_domain_for_ip','user','This modules helpful to assign domain to particular IP',0,'true',NULL,NULL),(100,6,'Unblock spam sent emails',100,'unblockemailsfromspam','user','Use this module for unblock the email ids who has sent spam email within One hour',0,'true',NULL,NULL),(101,2,'Apache/MySQL Log Settings',100,'enableErrorlogs','user','You can improve the performance of the system, by disabling the Mysql and Apache logs. You can enable, When you want. ',0,'true',NULL,NULL),(102,5,'SSL CRT',1,'ssl_crt','user','This module is helpful to install a SSL certification from third party CRT.',NULL,'true',NULL,NULL),(103,2,'ModSecurity',1,'mod_security','user','ModSecurity is enabled for all of your domains. You can Disable ModSecurity for your domains.',NULL,'true',NULL,NULL),(104,0,'Apache Setting',1,'apache_setting','user','Welcome to the Web Server , using this module you will enable the Apache',0,'true','1','https://www.ovipanel.com/'),(105,6,'Outgoing Mail Statistics',1,'OutgoingEmailStatistics','user','Outgoing Mail Statistics',0,'true','1','https://www.ovipanel.com/'),(106,11,'Softaculous',100,'softaculous','user','It may helpful to install scripts like WordPress, Joomla, Drupal, Dolphin, PrestaShop and many more through Softaculous.',0,'true',NULL,NULL),(107,8,'View Bandwidth Usage',1,'View_Bandwidth_Usage','user','Welcome to View Bandwidth Usage',0,'true','1','https://www.ovipanel.com/'),(108,2,'Change Site’s IPAddress',1,'Change_Site_IPAddress','user','Welcome to the Change Site’s IPAddress Module',0,'true','1','https://www.ovipanel.com/'),(109,11,'Weebly',1,'weebly','user','Using this module Create Site,Edit Site and Publish your website.',NULL,'true',NULL,NULL),(110,0,'Nginx Setting',1,'nginx_setting','user','Welcome to the Nginx Setting Module',0,'true','1','https://www.ovipanel.com/'),(111,4,'Repair a MySQL Database',1,'Repair_a_MySQL_Database','user','Welcome to the Repair a MySQL Database',0,'true','1','https://www.ovipanel.com/'),(112,10,'Secure Panel',100,'secure_panel','user','From here you can configure HTTPS for the OVI Panel based on your hostname. After enable the SecurePanel you can  also access Admin Control Panel using(ACP)  and User Control Panel (UCP) with  anyone of hosted domain name within this server  ( Ex: yourdomainname.com/acp or yourdomainname.com/ucp.) <br><br><b>Note:</b> It will take minimum 2 minutes to complete. Please be patient...',0,'true','1','https://www.ovipanel.com/'),(113,11,'WHMCS',238,'whmcs','user','WHMCS is a licensed billing system. This module allows you to connect WHMCS to the hosting control panel.',1563794976,'true',NULL,NULL),(114,11,'WHM* Migration',100,'whm_migration','user','From this module, you can migrate the whole account from WHM* cPanel* to OVI Panel.',0,'true',NULL,NULL),(115,11,'Terminal',1,'terminal','user','This user interface help to command line access on root server',0,'true',NULL,'https://ww.ovipanel.com/'),(116,0,'Managed SSH',1,'managedssh','user','This Jail and Normal SSH access allow for client',0,'true',NULL,'https://ww.ovipanel.com/'),(117,10,'Security Log',1,'security_log','user','List of file and Directory with 777 permission.',0,'true',NULL,'https://ww.ovipanel.com/'),(118,11,'CloudLinux* Manager',1,'cloudlinux','user','CloudLinux Manager module helps to improve your server Security level and manage your user package',0,'true',NULL,'https://ww.ovipanel.com/'),(119,11,'Hotlink Protector',1,'hotlink_protection','user','Hotlink Protector is help to hidden extension in URLs such as .png,.html,.php',0,false,NULL,'https://ww.ovipanel.com/'),(120,11,'managed ssh key',1,'managed_ssh_key','user','managed ssh key is modules helps to create authorized for user based access',0,true,NULL,'https://ww.ovipanel.com/'),(121,11,'Softaculous',100,'softaculousacp','user','From this module, you can control your user to access Softaculous.',1563794976,'true',NULL,NULL),(122,2,'Change Main IP',100,'main_server_ip','user','switch main server IP address',NULL,'true',NULL,NULL),(123,2,'modsecurity Id remover',100,'mod_id_remover','user','modsecurity Id remover',NULL,'true',NULL,NULL);
/*!40000 ALTER TABLE `x_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_mysql_databases`
--

DROP TABLE IF EXISTS `x_mysql_databases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_mysql_databases` (
  `my_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `my_acc_fk` int(6) DEFAULT NULL,
  `my_name_vc` varchar(64) DEFAULT NULL,
  `my_usedspace_bi` bigint(50) DEFAULT '0',
  `my_created_ts` int(30) DEFAULT NULL,
  `my_deleted_ts` int(30) DEFAULT NULL,
  `ip_deleted` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`my_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_mysql_databases`
--

LOCK TABLES `x_mysql_databases` WRITE;
/*!40000 ALTER TABLE `x_mysql_databases` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_mysql_databases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_mysql_dbmap`
--

DROP TABLE IF EXISTS `x_mysql_dbmap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_mysql_dbmap` (
  `mm_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `mm_acc_fk` int(6) DEFAULT NULL,
  `mm_user_fk` int(6) DEFAULT NULL,
  `mm_database_fk` int(6) DEFAULT NULL,
  PRIMARY KEY (`mm_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_mysql_dbmap`
--

LOCK TABLES `x_mysql_dbmap` WRITE;
/*!40000 ALTER TABLE `x_mysql_dbmap` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_mysql_dbmap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_mysql_users`
--

DROP TABLE IF EXISTS `x_mysql_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_mysql_users` (
  `mu_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `mu_acc_fk` int(6) DEFAULT NULL,
  `mu_name_vc` varchar(40) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `mu_database_fk` int(6) DEFAULT NULL,
  `mu_access_vc` varchar(40) DEFAULT NULL,
  `mu_pass_vc` varchar(40) DEFAULT NULL,
  `mu_created_ts` int(30) DEFAULT NULL,
  `mu_deleted_ts` int(30) DEFAULT NULL,
  `ip_deleted` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`mu_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_mysql_users`
--

LOCK TABLES `x_mysql_users` WRITE;
/*!40000 ALTER TABLE `x_mysql_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_mysql_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_new_theme_settings`
--

DROP TABLE IF EXISTS `x_new_theme_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_new_theme_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `x_key` varchar(255) DEFAULT NULL,
  `x_value` varchar(1024) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_new_theme_settings`
--

LOCK TABLES `x_new_theme_settings` WRITE;
/*!40000 ALTER TABLE `x_new_theme_settings` DISABLE KEYS */;
INSERT INTO `x_new_theme_settings` VALUES (1,'x_notice_settings','1'),(2,'link1_caption','OVIPanel'),(3,'link1_value','https://www.ovipanel.com/'),(4,'link2_caption','Forum'),(5,'link2_value','https://forum.ovipanel.com/'),(6,'link3_caption','Documentation'),(7,'link3_value','https://www.ovipanel.com/tutorials/'),(8,'theme_logo_file_name','logo.png'),(9,'powered_by_file_name','hostingraja.png'),(10,'powered_by_URL','https://www.ovipanel.com/'),(11,'powered_by_content','OVIPanel'),(12,'themed_by_content','Theme is powered by OVIPanel!');
/*!40000 ALTER TABLE `x_new_theme_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_nodejs`
--

DROP TABLE IF EXISTS `x_nodejs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_nodejs` (
  `nd_id` int(11) NOT NULL AUTO_INCREMENT,
  `nd_domain` varchar(255) DEFAULT NULL,
  `nd_created` int(30) DEFAULT NULL,
  `nd_deleted` int(30) DEFAULT NULL,
  `nd_port` varchar(7) DEFAULT NULL,
  `nd_acc_fk` int(11) DEFAULT NULL,
  `nd_vh_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`nd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_nodejs`
--

LOCK TABLES `x_nodejs` WRITE;
/*!40000 ALTER TABLE `x_nodejs` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_nodejs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_ns`
--

DROP TABLE IF EXISTS `x_ns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_ns` (
  `ns_no` int(20) NOT NULL AUTO_INCREMENT,
  `userid` int(20) NOT NULL,
  `ns1` varchar(200) NOT NULL,
  `ns2` varchar(200) NOT NULL,
  `ns_create` int(30) DEFAULT NULL,
  PRIMARY KEY (`ns_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_ns`
--

LOCK TABLES `x_ns` WRITE;
/*!40000 ALTER TABLE `x_ns` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_ns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_packages`
--

DROP TABLE IF EXISTS `x_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_packages` (
  `pk_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `pk_name_vc` varchar(30) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `pk_reseller_fk` int(6) DEFAULT NULL,
  `pk_enablephp_in` int(1) DEFAULT '0',
  `pk_created_ts` int(30) DEFAULT NULL,
  `pk_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`pk_id_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_packages`
--

LOCK TABLES `x_packages` WRITE;
/*!40000 ALTER TABLE `x_packages` DISABLE KEYS */;
INSERT INTO `x_packages` VALUES (1,'Administration',1,1,NULL,NULL);
/*!40000 ALTER TABLE `x_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_password_strength`
--

DROP TABLE IF EXISTS `x_password_strength`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_password_strength` (
  `ps_id_pk` int(11) NOT NULL AUTO_INCREMENT,
  `ps_cpenabled_in` int(4) NOT NULL,
  `ps_eaenabled_in` int(4) NOT NULL,
  `ps_faenabled_in` int(4) NOT NULL,
  `ps_muenabled_in` int(4) NOT NULL,
  `ps_user_vc` varchar(25) NOT NULL,
  `ps_updated_vc` varchar(200) NOT NULL,
  PRIMARY KEY (`ps_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_password_strength`
--

LOCK TABLES `x_password_strength` WRITE;
/*!40000 ALTER TABLE `x_password_strength` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_password_strength` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_permissions`
--

DROP TABLE IF EXISTS `x_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_permissions` (
  `pe_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `pe_group_fk` int(6) DEFAULT NULL,
  `pe_module_fk` int(6) DEFAULT NULL,
  PRIMARY KEY (`pe_id_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=314 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_permissions`
--

LOCK TABLES `x_permissions` WRITE;
/*!40000 ALTER TABLE `x_permissions` DISABLE KEYS */;

INSERT INTO `x_permissions` VALUES (2,3,83),(3,1,70),(4,1,88),(5,3,88),(6,3,15),(7,3,35),(8,1,28),(9,1,73),(10,3,58),(11,1,91),(12,3,91),(13,3,81),(14,3,76),(15,3,12),(17,3,54),(18,1,75),(19,1,11),(20,2,11),(21,3,11),(24,1,42),(25,3,22),(26,1,84),(27,3,86),(29,2,68),(30,3,68),(31,1,25),(32,2,25),(33,3,25),(35,3,29),(36,3,82),(37,3,32),(38,1,85),(39,3,94),(40,1,27),(41,2,27),(42,3,27),(43,3,50),(44,3,33),(45,3,26),(47,1,93),(48,1,77),(49,1,65),(50,1,66),(51,3,51),(52,1,36),(53,1,59),(54,1,64),(55,3,34),(56,3,89),(57,1,19),(58,0,31),(59,3,72),(61,3,24),(62,3,39),(63,1,79),(64,1,20),(65,3,16),(66,3,69),(67,1,1),(68,2,1),(69,3,1),(70,1,62),(71,2,62),(72,3,62),(73,3,60),(74,1,61),(75,2,61),(76,3,61),(77,1,57),(80,1,90),(81,2,90),(82,3,90),(83,1,8),(84,2,8),(85,3,8),(89,3,48),(91,3,71),(95,1,63),(96,2,63),(97,3,63),(98,1,87),(99,1,14),(100,2,14),(101,3,14),(102,1,3),(103,2,3),(104,1,53),(105,3,53),(106,1,92),(107,2,92),(108,3,52),(109,3,78),(110,3,17),(111,1,9),(112,2,9),(113,3,9),(114,1,6),(115,1,56),(116,1,80),(117,2,80),(118,3,80),(119,1,55),(120,3,47),(121,3,10),(122,3,51),(123,1,74),(124,3,95),(125,1,96),(126,3,97),(127,1,98),(128,1,99),(129,1,100),(300,1,101),(301,3,102),(302,3,103),(303,1,104),(304,1,105),(305,1,29),(306,3,106),(307,1,47),(308,1,107),(309,1,108),(310,3,109),(311,1,110),(312,1,111),(313,1,112),(314,1,113),(315,1,114),(316,1,115),(317,3,115),(318,1,116),(319,2,116),(320,1,117),(321,2,117),(322,3,117),(323,1,118),(324,1,120),(325,1,121),(326,1,122),(327,1,123);
/*!40000 ALTER TABLE `x_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_pg_databases`
--

DROP TABLE IF EXISTS `x_pg_databases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_pg_databases` (
  `my_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `my_acc_fk` int(6) DEFAULT NULL,
  `my_name_vc` varchar(40) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `my_usedspace_bi` bigint(50) DEFAULT '0',
  `my_created_ts` int(30) DEFAULT NULL,
  `my_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`my_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_pg_databases`
--

LOCK TABLES `x_pg_databases` WRITE;
/*!40000 ALTER TABLE `x_pg_databases` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_pg_databases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_pg_dbmap`
--

DROP TABLE IF EXISTS `x_pg_dbmap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_pg_dbmap` (
  `mm_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `mm_acc_fk` int(6) DEFAULT NULL,
  `mm_user_fk` int(6) DEFAULT NULL,
  `mm_database_fk` int(6) DEFAULT NULL,
  PRIMARY KEY (`mm_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_pg_dbmap`
--

LOCK TABLES `x_pg_dbmap` WRITE;
/*!40000 ALTER TABLE `x_pg_dbmap` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_pg_dbmap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_pg_users`
--

DROP TABLE IF EXISTS `x_pg_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_pg_users` (
  `mu_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `mu_acc_fk` int(6) DEFAULT NULL,
  `mu_name_vc` varchar(40) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `mu_database_fk` int(6) DEFAULT NULL,
  `mu_access_vc` varchar(40) DEFAULT NULL,
  `mu_pass_vc` varchar(40) DEFAULT NULL,
  `mu_created_ts` int(30) DEFAULT NULL,
  `mu_deleted_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`mu_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_pg_users`
--

LOCK TABLES `x_pg_users` WRITE;
/*!40000 ALTER TABLE `x_pg_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_pg_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_php_config`
--

DROP TABLE IF EXISTS `x_php_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_php_config` (
  `x_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_clearname` varchar(100) NOT NULL,
  `x_value` varchar(400) NOT NULL,
  `x_old_value` varchar(400) NOT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_php_config`
--

LOCK TABLES `x_php_config` WRITE;
/*!40000 ALTER TABLE `x_php_config` DISABLE KEYS */;
INSERT INTO `x_php_config` VALUES (1,'file_uploads','On','1'),(2,'max_execution_time','300','1'),(3,'max_input_time','600','1'),(4,'memory_limit','128','1'),(5,'session_save_path','/tmp/','1'),(6,'upload_max_filesize','512','1'),(7,'post_max_size','512','1'),(8,'x_update_flag','0','1'),(9,'max_input_vars','1000','1');
/*!40000 ALTER TABLE `x_php_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_php_page_block`
--

DROP TABLE IF EXISTS `x_php_page_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_php_page_block` (
  `x_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_filepath` blob NOT NULL,
  `x_count` int(11) NOT NULL,
  `x_status` varchar(10) NOT NULL,
  `x_last_update` varchar(100) NOT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_php_page_block`
--

LOCK TABLES `x_php_page_block` WRITE;
/*!40000 ALTER TABLE `x_php_page_block` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_php_page_block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_phpversion_upgrade`
--

DROP TABLE IF EXISTS `x_phpversion_upgrade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_phpversion_upgrade` (
  `x_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_client_id` int(11) NOT NULL,
  `x_php_version` varchar(10) NOT NULL,
  `x_update_time` int(30) NOT NULL,
  `x_flag` varchar(5) NOT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_phpversion_upgrade`
--

LOCK TABLES `x_phpversion_upgrade` WRITE;
/*!40000 ALTER TABLE `x_phpversion_upgrade` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_phpversion_upgrade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_picdata`
--

DROP TABLE IF EXISTS `x_picdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_picdata` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `logo_path` varchar(200) NOT NULL,
  `favicon_path` varchar(200) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `flag` int(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_picdata`
--

LOCK TABLES `x_picdata` WRITE;
/*!40000 ALTER TABLE `x_picdata` DISABLE KEYS */;
INSERT INTO `x_picdata` VALUES (1,'1491825834_334x101.jpg','1491825798_favicon.jpg','2019-01-24 08:20:14',1),(2,'1491825834_334x101.jpg','1491825834_334x101.jpg','2018-11-19 05:40:18',1);
/*!40000 ALTER TABLE `x_picdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_profiles`
--

DROP TABLE IF EXISTS `x_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_profiles` (
  `ud_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `ud_user_fk` int(6) DEFAULT NULL,
  `ud_fullname_vc` varchar(100) DEFAULT NULL,
  `ud_language_vc` varchar(10) DEFAULT 'en',
  `ud_group_fk` int(6) DEFAULT NULL,
  `ud_package_fk` int(6) DEFAULT NULL,
  `ud_address_tx` text,
  `ud_postcode_vc` varchar(20) DEFAULT NULL,
  `ud_phone_vc` varchar(20) DEFAULT NULL,
  `ud_created_ts` int(30) DEFAULT NULL,
  PRIMARY KEY (`ud_id_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_profiles`
--

LOCK TABLES `x_profiles` WRITE;
/*!40000 ALTER TABLE `x_profiles` DISABLE KEYS */;
INSERT INTO `x_profiles` VALUES (1,1,'Default Zadmin','en',1,1,'1 Example Road,\r\nIpswich,\r\nSuffolk','IP9 2HL','+44(1473) 000 000',0);
/*!40000 ALTER TABLE `x_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_quotas`
--

DROP TABLE IF EXISTS `x_quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_quotas` (
  `qt_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `qt_package_fk` int(6) DEFAULT NULL,
  `qt_domains_in` int(6) DEFAULT '0',
  `qt_subdomains_in` int(6) DEFAULT '0',
  `qt_parkeddomains_in` int(6) DEFAULT '0',
  `qt_mailboxes_in` int(6) DEFAULT '0',
  `qt_fowarders_in` int(6) DEFAULT '0',
  `qt_domain_forwarders_in` int(6) NOT NULL DEFAULT '0',
  `qt_distlists_in` int(6) DEFAULT '0',
  `qt_ftpaccounts_in` int(6) DEFAULT '0',
  `qt_mysql_in` int(6) DEFAULT '0',
  `qt_diskspace_bi` bigint(20) DEFAULT '0',
  `qt_bandwidth_bi` bigint(20) DEFAULT '0',
  `qt_bwenabled_in` int(1) DEFAULT '0',
  `qt_dlenabled_in` int(1) DEFAULT '0',
  `qt_totalbw_fk` int(30) DEFAULT NULL,
  `qt_minbw_fk` int(30) DEFAULT NULL,
  `qt_maxcon_fk` int(30) DEFAULT NULL,
  `qt_filesize_fk` int(30) DEFAULT NULL,
  `qt_filespeed_fk` int(30) DEFAULT NULL,
  `qt_filetype_vc` varchar(30) NOT NULL DEFAULT '*',
  `qt_modified_in` int(1) DEFAULT '0',
  PRIMARY KEY (`qt_id_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_quotas`
--

LOCK TABLES `x_quotas` WRITE;
/*!40000 ALTER TABLE `x_quotas` DISABLE KEYS */;
INSERT INTO `x_quotas` VALUES (1,1,-1,-1,-1,-1,-1,0,-1,-1,-1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,'*',1);
/*!40000 ALTER TABLE `x_quotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_remote_mysql_hosts`
--

DROP TABLE IF EXISTS `x_remote_mysql_hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_remote_mysql_hosts` (
  `re_id_pk` int(11) NOT NULL AUTO_INCREMENT,
  `re_host_vc` varchar(30) NOT NULL,
  `re_acc_fk` int(11) DEFAULT NULL,
  `re_created_ts` int(11) DEFAULT NULL,
  `re_deleted_ts` int(11) DEFAULT NULL,
  `ip_deleted` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`re_id_pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_remote_mysql_hosts`
--

LOCK TABLES `x_remote_mysql_hosts` WRITE;
/*!40000 ALTER TABLE `x_remote_mysql_hosts` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_remote_mysql_hosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_serverip`
--

DROP TABLE IF EXISTS `x_serverip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_serverip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `priv_ip` varchar(20) DEFAULT NULL,
  `public_ip` varchar(20) DEFAULT NULL,
  `ip_created` varchar(20) DEFAULT NULL,
  `ip_deleted` varchar(20) DEFAULT NULL,
  `ip_modified` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_serverip`
--

LOCK TABLES `x_serverip` WRITE;
/*!40000 ALTER TABLE `x_serverip` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_serverip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_settings`
--

DROP TABLE IF EXISTS `x_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_settings` (
  `so_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `so_name_vc` varchar(50) DEFAULT NULL,
  `so_cleanname_vc` varchar(50) DEFAULT NULL,
  `so_value_tx` text,
  `so_defvalues_tx` text,
  `so_desc_tx` text,
  `so_module_vc` varchar(50) DEFAULT NULL,
  `so_usereditable_en` enum('true','false') DEFAULT 'false',
  PRIMARY KEY (`so_id_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_settings`
--

LOCK TABLES `x_settings` WRITE;
/*!40000 ALTER TABLE `x_settings` DISABLE KEYS */;
INSERT INTO `x_settings` VALUES (6,'dbversion','Ovipanel version','3.3 Beta',NULL,'Database Version','Ovipanel Config','false'),(7,'sentora_root','Ovipanel root path','/etc/sentora/panel/',NULL,'Ovipanel Web Root','Ovipanel Config','true'),(8,'module_icons_pr','Icons per Row','10',NULL,'Set the number of icons to display before beginning a new line.','Ovipanel Config','false'),(10,'Sentora_df','Date Format','H:i jS M Y T',NULL,'Set the date format used by modules.','Ovipanel Config','true'),(13,'servicechk_to','Service Check Timeout','10',NULL,'Service Check Timeout','Ovipanel Config','true'),(14,'root_drive','Root Drive','/',NULL,'The root drive where Ovipanel is installed.','Ovipanel Config','true'),(16,'php_exer','PHP executable','/usr/bin/php',NULL,'PHP Executable','Ovipanel Config','false'),(17,'temp_dir','Temp Directory','/var/sentora/temp/',NULL,'Global temp directory.','Ovipanel Config','true'),(18,'news_url','Ovipanel News API URL','https://d.ovipanel.com/latestnews.json',NULL,'Ovipanel News URL','Ovipanel Config','false'),(19,'update_url','Ovipanel Update API URL','http://d.ovipanel.com/latestversion.json',NULL,'Ovipanel Update URL','Ovipanel Config','false'),(21,'server_ip','Server IP Address','103.120.179.7',NULL,'If set this will use this manually entered server IP address which is the prefered method for use behind a firewall.','Ovipanel Config','true'),(22,'zip_exe','ZIP Exe','zip',NULL,'Path to the ZIP Executable','Ovipanel Config','true'),(24,'disable_hostsen','Disable auto HOSTS file entry','false','true|false','Disable Host Entries','Ovipanel Config','false'),(25,'latestzpversion','Cached version of latest Ovipanel version','3.3 Beta',NULL,'This is used for caching the latest version of Ovipanel.','Ovipanel Config','false'),(26,'logmode','Debug logging mode','file','db|file|email','The default mode to log all errors in.','Ovipanel Config','true'),(27,'logfile','Ovipanel Log file','/var/sentora/logs/sentora.log',NULL,'If logging is set to \'file\' mode this is the path to the log file that is to be used by Ovipanel.','Ovipanel Config','true'),(28,'apikey','XMWS API Key','aff9491b95e1f5fa870e89fa06d5852c',NULL,'The secret API key for the server.','Ovipanel Config','false'),(29,'email_from_address','From Address','Ovipanel@localhost',NULL,'The email address to appear in the From field of emails sent by Ovipanel.','Ovipanel Config','true'),(30,'email_from_name','From Name','OVIPanel Server',NULL,'The name to appear in the From field of emails sent by Ovipanel.','Ovipanel Config','true'),(31,'email_smtp','Use SMTP','false','true|false','Use SMTP server to send emails from. (true/false)','Ovipanel Config','true'),(32,'smtp_auth','Use AUTH','false','true|false','SMTP requires authentication. (true/false)','Ovipanel Config','true'),(33,'smtp_server','SMTP Server','',NULL,'The address of the SMTP server.','Ovipanel Config','true'),(34,'smtp_port','SMTP Port','465',NULL,'The port address of the SMTP server (usually 25)','Ovipanel Config','true'),(35,'smtp_username','SMTP User','',NULL,'Username for authentication on the SMTP server.','Ovipanel Config','true'),(36,'smtp_password','SMTP Pass','',NULL,'Password for authentication on the SMTP server.','Ovipanel Config','true'),(37,'smtp_secure','SMTP Auth method','false','false|ssl|tls','If specified will attempt to use encryption to connect to the server, if \'false\' this is disabled. Available options: false, ssl, tls','Ovipanel Config','true'),(38,'daemon_lastrun','Daemon timeing cache','1551259802',NULL,'Timestamp of when the daemon last ran.',NULL,'false'),(39,'daemon_dayrun','Daemon timeing cache','1551259615',NULL,NULL,NULL,'false'),(40,'daemon_weekrun','Daemon timeing cache','1551259615',NULL,NULL,NULL,'false'),(41,'daemon_monthrun','Daemon timeing cache','1551259615',NULL,NULL,NULL,'false'),(42,'purge_bu','Purge Backups','true','true|false','Delete client backups after allotted time has elapsed to help save diskspace (true/false)','Backup Config','true'),(43,'purge_date','Purge Date','30',NULL,'Time in days backups are safe from being deleted. After days have elapsed, older backups will be deleted on Daemon Day Run','Backup Config','true'),(44,'disk_bu','Disk Backups','true','true|false','Allow users to create and save backups of their home directories to disk. (true/false)','Backup Config','true'),(45,'schedule_bu','Daily Backups','false','true|false','Make a daily backup of each clients data, including MySQL databases to their backup folder. Backups will still be created if Disk Backups are set to false. (true/false)','Backup Config','true'),(46,'ftp_db','FTP Database','sentora_proftpd',NULL,'The name of the ftp server database','FTP Config','true'),(47,'ftp_php','FTP PHP','proftpd.php',NULL,'Name of PHP to include when adding FTP data.','FTP Config','true'),(48,'ftp_service','FTP Service Name','proftpd',NULL,'The name of the FTP service','FTP Config','true'),(49,'ftp_service_root','FTP Service Root','/etc/init.d/',NULL,'The path to the service executable if applicable.','FTP Config','true'),(50,'ftp_config_file','FTP Config File','',NULL,'The path to the configuration file if applicable.','FTP Config','true'),(51,'mailserver_db','Mailserver Database','sentora_postfix',NULL,'What is Mailserver Database ?OVIPANELBREAKS The Mailserver Database is for use Postfix Mail service we are providing the Individual database service. For maintaining the mail service and configuration.','Mail Config','true'),(52,'hmailserver_et','Hmail Encryption Type','2',NULL,'Type of encryption uses for hMailServer passwords','Mail Config','false'),(53,'max_mail_size','Max Mailbox Size','2000',NULL,'What is Max Mailbox Size ?OVIPANELBREAKS The Max Mailbox Size is size of the container size of your mails. Default = 200','Mail Config','true'),(54,'mailserver_php','Mailserver PHP','postfix.php',NULL,'What is Mailserver PHP ?OVIPANELBREAKS The Mailserver PHP is user Postfix service communicate with ACP thoughts selected PHP version.','Mail Config','true'),(55,'remove_orphan','Remove Orphans','true','true|false','What is Remove Orphans ?OVIPANELBREAKS The Remove Orphans is When domains are deleted, also delete all mailboxes for that domain when the daemon runs. (true/false)','Mail Config','true'),(56,'named_dir','Named Directory','/etc/sentora/configs/bind/etc/',NULL,'Path to the directory where named.conf is stored','DNS Config','true'),(57,'named_conf','Named Config','named.conf',NULL,'Named configuration file','DNS Config','true'),(58,'zone_dir','Zone Directory','/etc/sentora/configs/bind/zones/',NULL,'Path to where DNS zone files are stored','DNS Config','true'),(59,'refresh_ttl','SOA Refesh TTL','21600',NULL,'Global refresh TTL.  Default = 21600 (6 hours)','DNS Config','true'),(60,'retry_ttl','SOA Retry TTL','3600',NULL,'Global retry TTL. Default = 3600 (1 hour)','DNS Config','true'),(61,'expire_ttl','SOA Expire TTL','86400',NULL,'Global expire TTL. Default = 86400 (1 day)','DNS Config','true'),(62,'minimum_ttl','SOA Minimum TTL','86400',NULL,'Global minimum TTL. Default = 86400 (1 day)','DNS Config','true'),(63,'custom_ip','Allow Custom IP','true','true|false','Allow users to change IP settings in A records. If set to false, IP is locked to server IP setting in Ovipanel Config','DNS Config','true'),(64,'bind_dir','Path to BIND Root','/etc/named/',NULL,'Path to the root directory where BIND is installed.','DNS Config','true'),(65,'bind_service','BIND Service Name','named',NULL,'Name of the BIND service','DNS Config','true'),(66,'allow_xfer','Allow Zone Transfers','trusted-servers',NULL,'Setting to restrict zone transfers in setting: allow-transfer {}; Default = all','DNS Config','true'),(67,'allowed_types','Allowed Record Types','A AAAA CNAME MX TXT SRV SPF NS',NULL,'Types of records allowed seperated by a space. Default = A AAAA CNAME MX TXT SRV SPF NS','DNS Config','true'),(68,'bind_log','Bind Log','/var/sentora/logs/bind/bind.log',NULL,'Path and name of the Bind Log','DNS Config','true'),(69,'hosted_dir','Vhosts Directory','/home/',NULL,'Virtual host directory','Apache Config','true'),(70,'disable_hostsen','Disable HOSTS file entries','false','true|false','Disable host entries','Apache Config','true'),(71,'apache_vhost','Apache VHOST Conf','/etc/sentora/configs/apache/httpd-vhosts.conf_dont_use',NULL,'The full system path and filename of the Apache VHOST configuration name.','Apache Config','true'),(72,'php_handler','PHP Handler','AddType application/x-httpd-php .php3 .php',NULL,'The PHP Handler.','Apache Config','false'),(73,'cgi_handler','CGI Handler','ScriptAlias /cgi-bin/ \"/_cgi-bin/\"\r\n<location /cgi-bin>\r\nAddHandler cgi-script .cgi .pl\r\nOptions +ExecCGI -Indexes\r\n</location>',NULL,'The CGI Handler.','Apache Config','false'),(74,'global_vhcustom','Global VHost Entry',NULL,NULL,'Extra directives for all apache vhost\'s.','Apache Config','true'),(75,'static_dir','Static Pages Directory','/etc/sentora/panel/etc/static/',NULL,'The Ovipanel static directory, used for storing welcome pages etc. etc.','Apache Config','true'),(76,'parking_path','Vhost Parking Path','/etc/sentora/panel/etc/static/parking/',NULL,'The path to the parking website, this will be used by all clients.','Apache Config','true'),(78,'shared_domains','Shared Domains','no-ip,dyndns,autono,zphub',NULL,'Domains entered here can be shared across multiple accounts. Seperate domains with , example: no-ip,dyndns','Apache Config','true'),(79,'upload_temp_dir','Upload Temp Directory','/var/sentora/temp/',NULL,'The path to the Apache Upload directory (with trailing slash)','Apache Config','true'),(80,'apache_port','Apache Port','80',NULL,'Apache service port','Apache Config','true'),(81,'dir_index','Directory Indexes','DirectoryIndex index.html index.htm index.php index.asp index.aspx index.jsp index.jspa index.shtml index.shtm',NULL,'Directory Index','Apache Config','true'),(82,'suhosin_value','Suhosin Value','php_admin_value suhosin.executor.func.blacklist \"passthru, show_source, shell_exec, system, pcntl_exec, popen, pclose, proc_open, proc_nice, proc_terminate, proc_get_status, proc_close, leak, apache_child_terminate, posix_kill, posix_mkfifo, posix_setpgid, posix_setsid, posix_setuid, escapeshellcmd, escapeshellarg, exec\"',NULL,'Suhosin configuration for virtual host  blacklisting commands','Apache Config','true'),(83,'openbase_seperator','Open Base Seperator',':',NULL,'Seperator flag used in open_base_directory setting','Apache Config','false'),(84,'openbase_temp','Open Base Temp Directory','/var/sentora/temp/:/tmp/:/var/lib/php/session/',NULL,'Temp directory used in open_base_directory setting','Apache Config','true'),(85,'access_log_format','Access Log Format','combined','combined|common','Log format for the Apache access log','Apache Config','false'),(86,'bandwidth_log_format','Bandwidth Log Format','common','combined|common','Log format for the Apache bandwidth log','Apache Config','false'),(87,'global_zpcustom','Global Ovipanel Entry',NULL,NULL,'Extra directives for Ovipanel default vhost.','Apache Config','false'),(88,'use_openbase','Use Open Base Dir','true','true|false','Enable openbase directory for all vhosts','Apache Config','true'),(89,'use_suhosin','Use Suhosin','false','true|false','Enable Suhosin for all vhosts','Apache Config','true'),(90,'sentora_domain','Ovipanel Domain','saravanatemp.com',NULL,'Domain that the control panel is installed under.','Ovipanel Config','false'),(91,'log_dir','Log Directory','/var/sentora/logs/',NULL,'Root path to directory log folders','Ovipanel Config','true'),(92,'apache_changed','Apache Changed','1551259618','true|false','If set, Apache Config daemon hook will write the vhost config file changes.','Apache Config','false'),(94,'apache_allow_disabled','Allow Disabled','false','true|false','Allow webhosts to remain active even if a user has been disabled.','Apache Config','false'),(95,'apache_budir','VHost Backup Dir','/var/sentora/backups/',NULL,'Directory that vhost.conf backups are stored.','Apache Config','true'),(96,'apache_purgebu','Purge Backups','true','true|false','Old backups are deleted after the date set in Puge Date','Apache Config','true'),(97,'apache_purge_date','Purge Date','7',NULL,'Time in days that vhost backups are safe from deletion','Apache Config','true'),(98,'apache_backup','VHost Backup','true','true|false','Backup vhost file before a new one is written','Apache Config','true'),(99,'zsudo','zsudo path','/etc/sentora/panel/bin/zsudo',NULL,'Path to the zsudo binary used by Apache to run system commands.','Ovipanel Config','true'),(100,'apache_restart','Apache Restart Cmd','reload',NULL,'Command line arguments used after the restart service request when reloading Apache.','Apache Config','false'),(101,'httpd_exe','Apache Binary','httpd',NULL,'Path to the Apache binary','Apache Config','true'),(102,'apache_sn','Apache Service Name','httpd',NULL,'Service name used to handle Apache service control','Apache Config','true'),(103,'daemon_exer',NULL,'/etc/sentora/panel/bin/daemon.php',NULL,'Path to the Ovipanel daemon','Ovipanel Config','false'),(104,'daemon_timing',NULL,'0 * * * *',NULL,'Cron time for when to run the Ovipanel daemon','Ovipanel Config','false'),(105,'cron_file','Cron File','/var/spool/cron',NULL,'Path to the user cron file','Cron Config','true'),(107,'mysqldump_exe','MySQL Dump','mysqldump',NULL,'Path to MySQL dump','Ovipanel Config','false'),(108,'dns_hasupdates','DNS Updated',NULL,NULL,NULL,NULL,'false'),(109,'named_checkconf','Named CheckConfig','named-checkconf',NULL,'Path to named-checkconf bind utility.','DNS Config','true'),(110,'named_checkzone','Named CheckZone','named-checkzone',NULL,'Path to named-checkzone bind utility.','DNS Config','true'),(111,'named_compilezone','Named CompileZone','named-compilezone',NULL,'	Path to named-compilezone bind utility.','DNS Config','true'),(112,'mailer_type','Mail method','mail','mail|smtp|sendmail','Method to use when sending emails out. (mail = PHP Mail())','Ovipanel Config','true'),(113,'daemon_run_interval','Number of seconds between each daemon execution','300',NULL,'The total number of seconds between each daemon run (default 300 = 5 mins)','Ovipanel Config','false'),(114,'debug_mode','Ovipanel Debug Mode','prod','dev|prod','Whether or not to show PHP debug errors,warnings and notices','Ovipanel Config','true'),(115,'password_minlength','Min Password Length','6',NULL,'Minimum length required for new passwords','Ovipanel Config','true'),(116,'cron_reload_command','Cron Reload Command','crontab',NULL,'Crontab binary in Linux Only','Cron Config','true'),(117,'cron_reload_path','Cron Reload Path','/var/spool/cron/apache',NULL,'Cron reload path in Linux Only','Cron Config','true'),(118,'cron_reload_flag','Cron Reload Flags','-u',NULL,'Cron reload command flags in Linux Only','Cron Config','true'),(119,'cron_reload_user','Cron Reload User','apache',NULL,'Cron reload apache user in Linux','Cron Config','true'),(120,'login_csfr','Remote Login Forms','false','false|true','Disables CSFR protection on the login form to enable remote login forms.','Ovipanel Config','true'),(121,'sentora_port','Ovipanel Apache Port','80',NULL,'Ovipanel Apache panel port (change will be pending until next daemon run)','Ovipanel Config','true'),(122,'apache_version','Apache Version','2.4',NULL,'Apche Version for maintenance','Apache Config','true'),(123,'ipdomain_dir','IP Domain Directory','/etc/sentora/panel/etc/static/pages/','NULL','IP Domain Directory','IP Domain Directory Config','true'),(124,'Domain_directory_change','Domain directory change',NULL,NULL,NULL,NULL,'false'),(125,'Domain_disable_exceed_directory','Domain disable directory change',NULL,NULL,NULL,NULL,'false'),(126,'Domain_enable_exceed_directory','Domain enable directory change',NULL,NULL,NULL,NULL,'false'),(127,'is_exceed_changed','Need to change for domain exceed directory change','0',NULL,NULL,NULL,'false'),(128,'core_php_version','Server PHP Version','php70',NULL,'Server PHP Version','Ovipanel Config','true'),(129,'email_pass_encryption_key',NULL,NULL,'e21eed2e9bec37e277c33aef57fc120db8731a1c41755a9a08dd8fb943694ec0','email_pass_encryption_key',NULL,'false'),(130,'whmcs_reported',NULL,'false',NULL,NULL,NULL,'false'),(131,'whmcs_sendemail_bo',NULL,'true',NULL,NULL,NULL,'false'),(132,'whmcs_link',NULL,'http://localhost:8888/whmcs/',NULL,NULL,NULL,'false'),(133,'whmcs_admin',NULL,'admin',NULL,NULL,NULL,'false'),(134,'whmcs_reseller_view_api',NULL,'false',NULL,NULL,NULL,'false'),(135,'ssl_changed','SSL Changed',1576145856,'true|false','If set, SSL Config daemon hook will write the vhost config file changes.','SSL Config','false'),(136,'cron_changed','CRON Changed',false,'true|false','If set, CRON Config daemon hook will write the CRON config file changes.','CRON Config','false');
/*!40000 ALTER TABLE `x_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_splitlog`
--

DROP TABLE IF EXISTS `x_splitlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_splitlog` (
  `x_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_flag` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`x_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_splitlog`
--

LOCK TABLES `x_splitlog` WRITE;
/*!40000 ALTER TABLE `x_splitlog` DISABLE KEYS */;
INSERT INTO `x_splitlog` VALUES (1,0);
/*!40000 ALTER TABLE `x_splitlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_ssl`
--

DROP TABLE IF EXISTS `x_ssl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_ssl` (
  `ssl_no` int(20) NOT NULL AUTO_INCREMENT,
  `userid` int(20) NOT NULL,
  `ssl_email` varchar(250) NOT NULL,
  `ssl_doamin` varchar(250) NOT NULL,
  `ssl_created` int(30) DEFAULT NULL,
  `ssl_delete` int(30) DEFAULT NULL,
  `ssl_status` varchar(50) DEFAULT NULL,
  `ssl_www` varchar(20) DEFAULT NULL,
  `ip_deleted` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ssl_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_ssl`
--

LOCK TABLES `x_ssl` WRITE;
/*!40000 ALTER TABLE `x_ssl` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_ssl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_ssl_crt`
--

DROP TABLE IF EXISTS `x_ssl_crt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_ssl_crt` (
  `ssl_crt_no` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(20) NOT NULL,
  `ssl_crt_doamin` varchar(130) NOT NULL,
  `ssl_crt` text,
  `ssl_crt_desc` text,
  `ssl_crt_type` varchar(30) DEFAULT NULL,
  `ssl_crt_issuer` varchar(150) DEFAULT NULL,
  `ssl_crt_status` int(20) DEFAULT NULL,
  `ssl_crt_valid_from` varchar(50) DEFAULT NULL,
  `ssl_crt_valid_to` varchar(50) DEFAULT NULL,
  `ssl_crt_create` int(30) DEFAULT NULL,
  `ssl_crt_delete` int(30) DEFAULT NULL,
  PRIMARY KEY (`ssl_crt_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_ssl_crt`
--

LOCK TABLES `x_ssl_crt` WRITE;
/*!40000 ALTER TABLE `x_ssl_crt` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_ssl_crt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_translations`
--

DROP TABLE IF EXISTS `x_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_translations` (
  `tr_id_pk` int(11) NOT NULL AUTO_INCREMENT,
  `tr_en_tx` text,
  `tr_de_tx` text,
  PRIMARY KEY (`tr_id_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_translations`
--

LOCK TABLES `x_translations` WRITE;
/*!40000 ALTER TABLE `x_translations` DISABLE KEYS */;
INSERT INTO `x_translations` VALUES (44,'Webmail is a convenient way for you to check your email accounts online without the need to configure an email client.','Webmail ist ein bequemer Weg fÃ¼r Sie, Ihre E-Mail-Konten online zu Ã¼berprÃ¼fen, ohne dass eine E-Mail-Client zu konfigurieren.'),(45,'Launch Webmail','Starten Sie WebMail'),(56,'PHPInfo provides you with information regarding the version of PHP running on this system as well as installed PHP extentsions and configuration details.','PHPInfo bietet Ihnen Informationen über die PHP-Version auf dem System, sowie PHP installiert extentsions und Konfigurationsmöglichkeiten.'),(67,'From here you can shadow any of your client\'s accounts, this enables you to automatically login as the user which enables you to offer remote help by seeing what they see!','Von hier aus können alle Ihre Kunden-Accounts können Schatten, ermöglicht Ihnen dies automatisch, wenn der Benutzer mit dem Sie remote helfen zu sehen, was sie sehen, anbieten zu können login!'),(68,'My Account','Meine Konto'),(69,'Change Password','Kennwort ändern'),(70,'Shadowing','Schatten'),(71,'Ovipanel Config','Config Ovipanel'),(72,'Ovipanel News','Ovipanel Aktuelles'),(73,'Updates','Aktualisierung'),(74,'Report Bug','Fehler melden'),(75,'Account','Konto'),(76,'Module Admin','Modul Admin'),(77,'Backup','Sicherungskopie'),(78,'Network Tools','Netzwerk-Tools'),(79,'Service Status','Service Status'),(80,'PHPInfo','PHPInfo'),(81,'phpMyAdmin','phpMyAdmin'),(82,'Domains','Domains'),(83,'Sub Domains','Sub Domains'),(84,'Parked Domains','geparkte Domains'),(85,'Manage Clients','Verwalten Kunden'),(86,'Package Manager','Paket Manager'),(87,'Server','Server'),(88,'Database','Datenbank'),(89,'Advanced','Fortgeschritten'),(90,'Mail','Post'),(91,'Reseller','Wiederverkäufer'),(92,'Account Information','Account Informationen'),(93,'Server Admin','Server Admin'),(94,'Database Management','Datenbank Verwalten'),(95,'Domain Management','Verwalten von Domains'),(96,'Find out all the latest news and information from the Ovipanel project.','Finden Sie heraus, alle Neuigkeiten und Informationen aus dem Ovipanel Projekt.'),(97,'Check to see if there are any available updates to your version of the Ovipanel software.','Prüfen Sie, ob es irgendwelche verfügbaren Aktualisierungen für Ihre Version des Ovipanel Software.'),(98,'If you have found a bug with Ovipanel you can report it here.','Did you mean: If you have found a bug with Ovi Panel you can report it here.\r\nWenn Sie einen Fehler mit Ovipanel gefunden haben, können Sie ihn hier melden.'),(99,'phpMyAdmin is a web based tool that enables you to manage your Ovipanel MySQL databases via. the web.','phpMyAdmin ist ein webbasiertes Tool, das Sie zu Ihrem Ovipanel MySQL-Datenbanken via verwalten können. im Internet.'),(100,'Current personal details that you have provided us with, We ask that you keep these upto date in case we require to contact you regarding your hosting package.','Aktuelle persönlichen Daten, die Sie uns mit vorgesehen ist, bitten wir Sie, diese zu halten bis zu Datum, falls wir mit Ihnen Kontakt aufnehmen über Ihre Hosting-Paket erfordern.'),(101,'Webmail is a convenient way for you to check your email accounts online without the need to configure an email client.','Webmail ist ein bequemer Weg für Sie, Ihre E-Mail-Konten online zu überprüfen, ohne dass eine E-Mail-Client zu konfigurieren.'),(102,'Change your current control panel password.','Ändern Sie Ihre aktuelle Bedienfeld oder MySQL-Kennwort.'),(103,'The backup manager module enables you to backup your entire hosting account including all your MySQL&reg; databases.','Der Backup-Manager-Modul ermöglicht es Ihnen, Ihre gesamte Hosting-Account inklusive aller Ihrer MySQL &reg; Datenbank-Backup.'),(104,'You can use the tools below to diagnose issues or to simply test connectivity to other servers or sites around the globe.','Sie können die folgenden Tools verwenden, um Probleme zu diagnostizieren oder einfach testen Verbindung mit anderen Servern oder Websites rund um den Globus.'),(105,'Here you can check the current status of our services and see what services are up and running and which are down and not.','Hier können Sie den aktuellen Status unserer Dienstleistungen und sehen, welche Dienste vorhanden sind und laufen, und die nach unten und es nicht sind.'),(106,'This module enables you to add or configure domain web hosting on your account.','Dieses Modul ermöglicht es Ihnen, hinzuzufügen oder zu konfigurieren Domain Hosting auf Ihrem Konto.'),(107,'Domain parking refers to the registration of an Internet domain name without that domain being used to provide services such as e-mail or a website. If you have any domains that you are not using, then simply park them!','Domain-Parking bezieht sich auf die Registrierung von Internet Domain-Namen ohne diese Domäne verwendet, um Dienste wie E-Mail oder eine Webseite bereitzustellen. Wenn Sie alle Domains, die Sie nicht haben, dann einfach parken sie!'),(108,'This module enables you to add or configure domain web hosting on your account.','Dieses Modul ermöglicht es Ihnen, hinzuzufügen oder zu konfigurieren Domain Hosting auf Ihrem Konto.'),(109,'Administer or configure modules registered with module admin','Verwalten oder zu konfigurieren Module mit Modul admin registriert'),(110,'The account manager enables you to view, update and create client accounts.','Die Account-Manager ermöglicht es Ihnen, anzuzeigen, zu aktualisieren und erstellen Kundenkonten.'),(111,'Welcome to the Package Manager, using this module enables you to create and manage existing reseller packages on your Ovipanel hosting account.','Willkommen auf der Paket-Manager, mit diesem Modul ermöglicht Ihnen die Erstellung und Verwaltung von bestehenden Reseller-Pakete auf Ihrem Ovipanel Hosting-Account.'),(112,'Gives you access to your files with drag-and-drop, multiple file uploading, text editing, zip support.','Ermöglicht den Zugriff auf Ihre Dateien mit Drag-and-drop, multiple Datei-Upload, Textbearbeitung, zip unterstützen.'),(113,'Secure FTP Applet is a JAVA based FTP client component that runs within your web browser. It is designed to let non-technical users exchange data securely with an FTP server.','Secure FTP Applet ist eine Java-basierte FTP-Client-Komponente, die in Ihrem Web-Browser läuft. Es wurde entwickelt, um nicht-technische Anwender den Datenaustausch secureiy lassen mit einem FTP-Server.'),(114,'Full name','Vollständiger Name'),(115,'Email Address','E-Mail Adresse'),(116,'Phone Number','Telefonnummer'),(117,'Choose Language','Sprache wählen'),(118,'Postal Address','Postanschrift'),(119,'Postal Code','Postleitzahl'),(120,'Current personal details that you have provided us with, We ask that you keep these upto date in case we require to contact you regarding your hosting package.','Aktuelle persönlichen Daten, die Sie uns mit vorgesehen ist, bitten wir Sie, diese zu halten bis zu Datum, falls wir mit Ihnen Kontakt aufnehmen über Ihre Hosting-Paket erfordern.'),(121,'Changes to your account settings have been saved successfully!','Änderungen an Ihrem Konto-Einstellungen wurden erfolgreich gespeichert!'),(122,'Update Account','Aktualisierung Konto'),(123,'Enter your account details','Geben Sie Ihre Kontodaten');
/*!40000 ALTER TABLE `x_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_user_info`
--

DROP TABLE IF EXISTS `x_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_user_info` (
  `web_id` int(11) NOT NULL AUTO_INCREMENT,
  `web_username` varchar(50) NOT NULL,
  `web_password` blob NOT NULL,
  PRIMARY KEY (`web_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_user_info`
--

LOCK TABLES `x_user_info` WRITE;
/*!40000 ALTER TABLE `x_user_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_user_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_varnish`
--

DROP TABLE IF EXISTS `x_varnish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_varnish` (
  `x_id` int(11) NOT NULL AUTO_INCREMENT,
  `x_user_id` int(11) NOT NULL,
  `x_varnish` varchar(5) NOT NULL,
  `x_nginx` varchar(5) NOT NULL DEFAULT 'Off',
  `x_interval` int(11) NOT NULL,
  `x_timeout` int(11) NOT NULL,
  `x_window` int(11) NOT NULL,
  `x_threshold` int(11) NOT NULL,
  `x_isactive` int(11) NOT NULL DEFAULT '0',
  `x_lastupdate` int(30) NOT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_varnish`
--

LOCK TABLES `x_varnish` WRITE;
/*!40000 ALTER TABLE `x_varnish` DISABLE KEYS */;
INSERT INTO `x_varnish` VALUES (1,1,'Off','Off',5,1,5,3,1,1470142255);
/*!40000 ALTER TABLE `x_varnish` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_vhosts`
--

DROP TABLE IF EXISTS `x_vhosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_vhosts` (
  `vh_id_pk` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `vh_acc_fk` int(6) DEFAULT NULL,
  `vh_name_vc` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `vh_directory_vc` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `vh_type_in` int(1) DEFAULT '1',
  `vh_active_in` int(1) DEFAULT '0',
  `vh_suhosin_in` int(1) DEFAULT '1',
  `vh_obasedir_in` int(1) DEFAULT '1',
  `vh_custom_tx` text,
  `vh_custom_port_in` int(6) DEFAULT NULL,
  `vh_custom_ip_vc` varchar(45) DEFAULT NULL,
  `vh_portforward_in` int(1) DEFAULT NULL,
  `vh_soaserial_vc` char(10) DEFAULT 'AAAAMMDDSS',
  `vh_enabled_in` int(1) DEFAULT '1',
  `vh_created_ts` int(30) DEFAULT NULL,
  `vh_deleted_ts` int(30) DEFAULT NULL,
  `vh_modhttp` int(1) DEFAULT '1',
  `vh_modhttp_status` int(1) DEFAULT '1',
  `ip_deleted` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`vh_id_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_vhosts`
--

LOCK TABLES `x_vhosts` WRITE;
/*!40000 ALTER TABLE `x_vhosts` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_vhosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_web_server`
--

DROP TABLE IF EXISTS `x_web_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_web_server` (
  `x_id` int(15) NOT NULL AUTO_INCREMENT,
  `x_service` varchar(500) NOT NULL,
  PRIMARY KEY (`x_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_web_server`
--

LOCK TABLES `x_web_server` WRITE;
/*!40000 ALTER TABLE `x_web_server` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_web_server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_weebly`
--

DROP TABLE IF EXISTS `x_weebly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_weebly` (
  `we_id` int(20) NOT NULL AUTO_INCREMENT,
  `we_user_id` varchar(50) NOT NULL,
  `we_email` varchar(200) NOT NULL,
  `we_created_ts` int(30) DEFAULT NULL,
  `we_deleted_ts` int(30) DEFAULT NULL,
  `we_ip_deleted` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`we_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_weebly`
--

LOCK TABLES `x_weebly` WRITE;
/*!40000 ALTER TABLE `x_weebly` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_weebly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_weebly_user`
--

DROP TABLE IF EXISTS `x_weebly_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_weebly_user` (
  `w_id` int(20) NOT NULL AUTO_INCREMENT,
  `vh_acc_fk` int(6) NOT NULL,
  `w_user_id` varchar(50) NOT NULL,
  `w_site_id` varchar(50) NOT NULL,
  `w_domain` varchar(100) NOT NULL,
  `w_link` varchar(5000) NOT NULL,
  `w_ftp_user` varchar(50) NOT NULL,
  `w_ftp_pass` varchar(50) NOT NULL,
  `w_ftp_dir` varchar(100) NOT NULL,
  `w_created_ts` int(30) DEFAULT NULL,
  `w_deleted_ts` int(30) DEFAULT NULL,
  `w_ip_deleted` int(30) DEFAULT NULL,
  PRIMARY KEY (`w_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_weebly_user`
--

LOCK TABLES `x_weebly_user` WRITE;
/*!40000 ALTER TABLE `x_weebly_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_weebly_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
UPDATE  datacont SET data="<!DOCTYPE html><html><head><meta charset=\"utf-8\"><meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\"><metaname=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Your OVIPanel account is active!</title><link rel=\"icon\" type=\"image/png\" href=\"./favicon.ico\" ><style>html{height:80%;}body{text-align:left;height:100%;background:#F3F3F3;font-size:62.5%;font-family:'LucidaGrande',Verdana,Arial,Sans-Serif;margin-top:10px;margin-bottom:10px;margin-right:10px;margin-left:10px;padding:0px;}body,td,th{font-family:Verdana,Arial,Helvetica,sans-serif;font-size:9pt;color:#333333;}h1,h2,h3,h4,h5,h6{font-family:Geneva,Arial,Helvetica,sans-serif;}h1{font-size:28px;font-weight:bold;color:#336;text-shadow:3px 3px 5px #BBBBBB;}a:link,a:visited,a:hover,a:active{color:#336;text-decoration:none;}ol{color:#336;font-size:24px;font-weight:bold;text-shadow:3px 3px 5px #BBBBBB;}ol p{color:#CCCCCC;font:normal 12pt Verdana,Arial,Helvetica,sans-serif;color:#333333;}.content{background:#F1F4F6;background:#F1F4F6 url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAA6CAYAAAB4Q5OdAAAACXBIWXMAAAsTAAALEwEAmpwYAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAABKklEQVR42mL8DwQMaAAggJgYsACAAMIqCBBAWAUBAgirIEAAYRUECCAWLJYzAAQQy38sKgECCKt2gADCKggQQFgFAQIIq0UAAYRVJUAAYRUECCCsggABhFUQIIBYsNjDABBAWFUCBBALAwOmUoAAwqoSIICwCgIEEFaLAAIIq0qAAMIqCBBAWAMEIICwqgQIIKyCAAGEVRAggLAKAgQQVkGAAMIqCBBAWJ0EEEBYVQIEEFZBgADCmmwAAgirSoAAwioIEEBYbQcIIKwqAQIIqyBAAGEVBAggrIIAAYQ14gACCKtKgADC6iSAAMKqEiCAsAoCBBBWQYAAwioIEEBYkyJAAGFVCRBAWAUBAgirjwACCGt0AAQQVu0AAYRVECCAsAoCBBDWAAEIMAAoCSZuy+v+UQAAAABJRU5ErkJggg==')repeat-x top;border:solid 1px #DFDFDF;margin:10px 0;padding:0 20px 10px;-moz-border-radius:10px;border-radius:10px;min-height:90%;}.header_logo{display:block;max-width:263px;max-height:70px;}.header_logo img{max-width:345px;max-height:77px;}.poweredbox{font-family:Geneva,Arial,Helvetica,sans-serif;color:#333333;padding-left:15px;}</style></head><body><a class=\"header_logo\" href=\"https://ovipanel.com/\" target=\"_blank\"><img src=\"./ovi-logo.png\"alt=\"OVIPanel-The open-source webhosting control panel\" border=\"0\" ></a><div class=\"content\"><h1>Your hosting space is ready...</h1><p>Your webhosting space is now active and ready to be used.</p><p><b>To get started:</b><ol><li><p>Login to your OVIPanel</p></li><li><p>Create an FTP account</p></li><li><p>Replace or delete this file (index.html)</p></li></ol></p><p>Thank you for using OVIPanel to manage your hosting!</p><p>Kind regards,<br>Your hosting company.</p></div></body></html>" WHERE id=2;
DROP TABLE IF EXISTS `x_md5_file`;
CREATE TABLE `x_md5_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `path` varchar(2550) NOT NULL,
  `checksum` varchar(550) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `securesocket`;
CREATE TABLE `securesocket` (
`id` INT(30) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
`unique_id` VARCHAR(100) NOT NULL,
`temp_name` VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- Dump completed on 2019-02-27 15:03:41
