if [ "$#" == 6 ]
then
domain_name=$1
python_version=$2
python_version_sanitize=$(echo "$python_version" | sed 's/\//\\\//g')
domainpath=$3
path=$(echo "$domainpath" | sed 's/\//\\\//g')
implode=$4
final_implode=$(echo "$implode" | sed 's/\//\\\//g')
last_one=$5 
username=$6
filename=$(echo $domain_name | sed 's/\*./wildcard_/g')
cd $domainpath
file_name='__init__.py'
file_name1='init.wsgi'
file_name2='venv'
file_name3='index.html'
file_name4='index.php'
file_name5='db.sqlite3'
file_name6='myproject'
file_name7='static'
file_name8='manage.py'
current_time=$(date "+%Y.%m.%d-%H.%M.%S")
new_fileName=$file_name.$current_time
new_fileName1=$file_name1.$current_time
new_fileName2=$file_name2.$current_time
new_fileName3=$file_name3.$current_time
new_fileName4=$file_name4.$current_time
new_fileName5=$file_name5.$current_time
new_fileName6=$file_name6.$current_time
new_fileName7=$file_name7.$current_time
new_fileName8=$file_name8.$current_time
mv $file_name $new_fileName
mv $file_name1 $new_fileName1
mv $file_name2 $new_fileName2
mv $file_name3 $new_fileName3
mv $file_name4 $new_fileName4
mv $file_name5 $new_fileName5
mv $file_name6 $new_fileName6
mv $file_name7 $new_fileName7
mv $file_name8 $new_fileName8
cp /etc/sentora/panel/modules/python_management/assets/flask__init__.py __init__.py
cp /etc/sentora/panel/modules/python_management/assets/flask_init.wsgi init.wsgi
#virtualenv venv
virtualenv -p /usr/bin/python2 venv
source venv/bin/activate
pip install django
django-admin startproject myproject .
echo 'STATIC_ROOT = os.path.join(BASE_DIR, "static/")' >> myproject/settings.py
echo 'ALLOWED_HOSTS = ["*"]'  >> myproject/settings.py
./manage.py makemigrations
./manage.py migrate
python manage.py syncdb --noinput
echo "from django.contrib.auth.models import User; User.objects.create_superuser('admin', 'admin@example.com', 'pass')" | python manage.py shell
./manage.py collectstatic
#./manage.py runserver 0.0.0.0:8000
chown $username. -R $domainpath
#WSGIDaemonProcess jam.babayaga.gq python-path=/home/babayaga/jam_babayaga_gq:/home/babayaga/jam_babayaga_gq/venv/lib/python2.7/site-packages processes=6 threads=25 user=babayaga group=babayaga
#WSGIProcessGroup jam.babayaga.gq
#WSGIScriptAlias / /home/babayaga/jam_babayaga_gq/myproject/wsgi.py
#Alias /static /home/babayaga/jam_babayaga_gq/static
#<Directory "/home/babayaga/jam_babayaga_gq/static">
#  AllowOverride All
#    Require all granted
#</Directory>
conf=".conf"
ssl="ssl_"
python_file_conf="/etc/sentora/configs/apache/python/$filename$conf"
ssl_python_file_conf="/etc/sentora/configs/apache/python/ssl_$filename$conf"
DAEMON_PROCESS="WSGIDaemonProcess $domain_name python-path=$domainpath:$domainpath""venv/lib/python2.7/site-packages user=$username group=$username threads=25 processes=6 python-home=$domainpath""venv"
SSL_DAEMON_PROCESS="WSGIDaemonProcess ssl.$domain_name python-path=$domainpath:$domainpath""venv/lib/python2.7/site-packages  user=$username group=$username threads=25 processes=6 python-home=$domainpath""venv"
echo "$DAEMON_PROCESS"  > $python_file_conf
echo "$SSL_DAEMON_PROCESS"  > $ssl_python_file_conf
echo "WSGIProcessGroup $domain_name" >> $python_file_conf
echo "WSGIProcessGroup $domain_name" >> $ssl_python_file_conf
echo "WSGIScriptAlias / "$domainpath"myproject/wsgi.py" >> $python_file_conf
echo "WSGIScriptAlias / "$domainpath"myproject/wsgi.py" >> $ssl_python_file_conf
echo "Alias /static $domainpath""static" >> $python_file_conf
echo "Alias /static $domainpath""static" >> $ssl_python_file_conf
echo "<Directory \"$domainpath""static\">"  >> $python_file_conf
echo "<Directory \"$domainpath""static\">" >> $ssl_python_file_conf
echo "AllowOverride All" >> $python_file_conf
echo "AllowOverride All" >> $ssl_python_file_conf
echo "Require all granted"  >> $python_file_conf
echo "Require all granted" >> $ssl_python_file_conf
echo "</Directory>" >> $python_file_conf
echo "</Directory>" >> $ssl_python_file_conf
include_opt_str=$( echo "IncludeOptional $python_file_conf" | sed 's/\//\\\//g')
include_opt_str_ssl=$( echo "IncludeOptional $ssl_python_file_conf" | sed 's/\//\\\//g')
sed -i "/IncludeOptional/c\\$include_opt_str" /etc/sentora/configs/apache/domains/$filename$conf
sed -i "/IncludeOptional/c\\$include_opt_str_ssl" /etc/sentora/configs/apache/domains/$ssl$filename$conf
#service httpd reload
service httpd restart
SERVICE_PATH=`whereis service | awk '{print $2}'`
`$SERVICE_PATH httpd restart`
fi
