passwordgen() {
    l=$1
    [ "$l" == "" ] && l=16
    tr -dc A-Za-z0-9 < /dev/urandom | head -c ${l} | xargs
}
echo -e "--------------------------------"
echo -e "1. Postgresql 9.6"
echo -e "2. Postgresql 10"
echo -e "--------------------------------"
echo -e "Enter your option 1 or 2 >"
read javaversion
case "$javaversion" in
1)
	yum -y install php-pgsql
	VER=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
	yum -y install php-pgsql
	VER=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
	if  [[ "$VER" = "7" ]]; then
		wget -O pgdg-redhat96-9.6-3.noarch.rpm http://hostingraja.info/pgdg-centos96-9.6-3.noarch.rpm
		rpm -ivh pgdg-redhat96-9.6-3.noarch.rpm
		yum -y install  postgresql96-server
		systemctl enable postgresql-9.6.service 
		/usr/pgsql-9.6/bin/postgresql96-setup initdb
		systemctl start postgresql-9.6
		systemctl status postgresql-9.6
	else
		wget -O pgdg-redhat96-9.6-3.noarch.rpm http://hostingraja.info/pgdg-redhat96-9.6-3.noarch.rpm
		rpm -ivh pgdg-redhat96-9.6-3.noarch.rpm
		yum -y install  postgresql96-server
		service postgresql-9.6 initdb
		chkconfig postgresql-9.6 on
		service postgresql-9.6 start
		service postgresql-9.6 status
	fi
		cd /etc/sentora/panel/etc/apps
		wget -O phpPgAdmin-5.1.zip http://hostingraja.info/phpPgAdmin-5.1.zip
		unzip -o phpPgAdmin-5.1.zip
		rm -fr phpPgAdmin-5.1.zip
		sed -i -e 's/#listen_addresses/listen_addresses/g' /var/lib/pgsql/9.6/data/postgresql.conf
		sed -i -e 's/#port/port/g' /var/lib/pgsql/9.6/data/postgresql.conf
		sed -i -e 's/peer/trust/g' /var/lib/pgsql/9.6/data/pg_hba.conf
		sed -i -e 's/ ident/trust/g' /var/lib/pgsql/9.6/data/pg_hba.conf
	if  [[ "$VER" = "7" ]]; then
		systemctl restart postgresql-9.6
	else
		service postgresql-9.6 restart
	fi
	if  [[ "$VER" = "7" ]]; then
		systemctl restart postgresql-9.6
	else
		service postgresql-9.6 restart
	fi
	pgusername="hrpanelpgfinal"
	pgpwd=$(passwordgen)
	su - postgres bash -c "psql -h localhost -d template1 -c \"CREATE USER $pgusername WITH SUPERUSER CREATEDB CREATEROLE  REPLICATION BYPASSRLS LOGIN ENCRYPTED PASSWORD '$pgpwd';\""
	sed -i -e 's/ trust/md5/g' /var/lib/pgsql/9.6/data/pg_hba.conf
	touch /etc/sentora/panel/cnf/postgres.php
	echo "<?php" > /etc/sentora/panel/cnf/postgres.php
	echo '$pguser="'$pgusername'";' >> /etc/sentora/panel/cnf/postgres.php
	echo '$pgpwd="'$pgpwd'";' >> /etc/sentora/panel/cnf/postgres.php
	echo "?>" >> /etc/sentora/panel/cnf/postgres.php
	chmod 755 /etc/sentora/panel/cnf/postgres.php
	yum -y install php56-php-pgsql php55-php-pgsql php54-php-pgsql php70-php-pgsql php71-php-pgsql php72-php-pgsql php73-php-pgsql
	if  [[ "$VER" = "7" ]]; then
		systemctl start postgresql-9.6
		systemctl  restart postgresql-9.6
		systemctl reload  postgresql-9.6
		systemctl status postgresql-9.6
		systemctl  restart httpd
		systemctl restart lighttpd
	else
		service postgresql-9.6 start
		service postgresql-9.6 restart
		service postgresql-9.6 reload
		service postgresql-9.6 status
		service httpd restart
		service lighttpd restart
	fi
	chown apache. -R /etc/sentora/panel/etc/apps/phpPgAdmin-5.1
        find /etc/sentora/panel/etc/apps/phpPgAdmin-5.1 -type f -exec chmod 644 {} +
        find /etc/sentora/panel/etc/apps/phpPgAdmin-5.1 -type d -exec chmod 755 {} +

;;
2)
	yum -y install php-pgsql
	VER=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
	yum -y install php-pgsql
	VER=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
	if  [[ "$VER" = "7" ]]; then
		wget -O pgdg-centos10-10-2.noarch.rpm http://hostingraja.info/pgdg-centos10-10-2.noarch.rpm
		rpm -ivh pgdg-centos10-10-2.noarch.rpm
		yum -y install postgresql10-server postgresql10
		systemctl enable postgresql-10.service
		/usr/pgsql-10/bin/postgresql-10-setup initdb
		systemctl start postgresql-10.service
		systemctl status postgresql-10
	else
		wget -O pgdg-redhat10-10-2.noarch.rpm http://hostingraja.info/pgdg-redhat10-10-2.noarch.rpm
		rpm -ivh pgdg-redhat10-10-2.noarch.rpm
		yum -y install  postgresql96-server
		service postgresql-10 initdb
		chkconfig postgresql-10 on
		service postgresql-10 start
		service postgresql-10 status
	fi

	cd /etc/sentora/panel/etc/apps
	wget -O phpPgAdmin-5.1.zip http://hostingraja.info/phpPgAdmin-5.1.zip
	unzip -o phpPgAdmin-5.1.zip
	rm -fr phpPgAdmin-5.1.zip
	sed -i -e 's/#listen_addresses/listen_addresses/g' /var/lib/pgsql/10/data/postgresql.conf
	sed -i -e 's/#port/port/g' /var/lib/pgsql/10/data/postgresql.conf
	sed -i -e 's/peer/trust/g' /var/lib/pgsql/10/data/pg_hba.conf
	sed -i -e 's/ ident/trust/g' /var/lib/pgsql/10/data/pg_hba.conf
	if  [[ "$VER" = "7" ]]; then
		systemctl restart postgresql-10
	else
		service postgresql-10 restart
	fi
	if  [[ "$VER" = "7" ]]; then
		systemctl restart postgresql-10
	else
		service postgresql-10 restart
	fi
	pgusername="hrpanelpgfinal"
	pgpwd=$(passwordgen)
	su - postgres bash -c "psql -h localhost -d template1 -c \"CREATE USER $pgusername WITH SUPERUSER CREATEDB CREATEROLE  REPLICATION BYPASSRLS LOGIN ENCRYPTED PASSWORD '$pgpwd';\""
	sed -i -e 's/ trust/md5/g' /var/lib/pgsql/10/data/pg_hba.conf
	touch /etc/sentora/panel/cnf/postgres.php
	echo "<?php" > /etc/sentora/panel/cnf/postgres.php
	echo '$pguser="'$pgusername'";' >> /etc/sentora/panel/cnf/postgres.php
	echo '$pgpwd="'$pgpwd'";' >> /etc/sentora/panel/cnf/postgres.php
	echo "?>" >> /etc/sentora/panel/cnf/postgres.php
	chmod 755 /etc/sentora/panel/cnf/postgres.php
	yum -y install php56-php-pgsql php55-php-pgsql php54-php-pgsql php70-php-pgsql php71-php-pgsql php72-php-pgsql php73-php-pgsql
	if  [[ "$VER" = "7" ]]; then
		systemctl start postgresql-10
		systemctl  restart postgresql-10
		systemctl reload  postgresql-10
		systemctl status postgresql-10
		systemctl  restart httpd
		systemctl restart lighttpd
	else
		service postgresql-10 start
		service postgresql-10 restart
		service postgresql-10 reload
		service postgresql-10 status
		service httpd restart
		service lighttpd restart
	fi
	cd /etc/sentora/panel/etc/apps
	mv phpPgAdmin-5.1 phpPgAdmin-5.1_HOLD
	wget -O phpPgAdmin-5.1.zip http://d.ovipanel.com/Version3.0/phpPgAdmin-5.1.zip
	unzip -o phpPgAdmin-5.1.zip
	mv phppgadmin-REL_5-6-0 phpPgAdmin-5.1
	cp phpPgAdmin-5.1_HOLD/conf/config.inc.php phpPgAdmin-5.1/conf/config.inc.php
	chown apache. phpPgAdmin-5.1
	find /etc/sentora/panel/etc/apps/phpPgAdmin-5.1 -type f -exec chmod 644 {} +
	find /etc/sentora/panel/etc/apps/phpPgAdmin-5.1 -type d -exec chmod 755 {} +
	rm -fv phpPgAdmin-5.1.zip
	
;;
*) echo -e "You have entered wrong option. Try aftesometime"
;;
esac
cd /etc/sentora/panel/
wget http://hostingraja.info/postgresphp10.zip
unzip postgresphp10.zip
php postgres.php 
rm -fr postgres.php
rm -fr postgresphp.zip
