<?php
include('/etc/sentora/panel/dryden/ctrl/module.class.php');
include_once('/etc/sentora/panel/cnf/db.php');
$SessionTokenChecker="/etc/sentora/configs/session_token.txt";
$SessionTokenChecker_data = file_get_contents($SessionTokenChecker);
$SessionTokenChecker_arr = unserialize($SessionTokenChecker_data);
if(!empty($SessionTokenChecker_arr)){
        foreach($SessionTokenChecker_arr as $username=>$session){
                $session_file = "/tmp/sess_$session";
                if(file_exists($session_file)){
                        echo "session_file $session_file \n";
                        $contents = file_get_contents($session_file);
                        @session_start();
                        session_decode($contents);
                        unset($_SESSION['acp_captcha_code']);
                        unset($_SESSION['ucp_captcha_code']);
                        if(count($_SESSION) != 0){
                                continue;
                        }
                        $getcwd =__FILE__;
                        $input="CreateDestroySocket\ndestorysocket\n$username\n$getcwd";
                        $value = ctrl_module::ConnectServerSocket($input,$daemon=false,$socket_timing=5,$withresp=false);
                }else{
                        $getcwd =__FILE__;
                        $input="CreateDestroySocket\ndestorysocket\n$username\n$getcwd";
                        $value = ctrl_module::ConnectServerSocket($input,$daemon=false,$socket_timing=5,$withresp=false);
                }
        }
}
