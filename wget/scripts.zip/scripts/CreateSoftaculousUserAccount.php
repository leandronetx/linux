#!/usr/bin/php
<?php
if( $argc<=4) {
	echo "Please pass the proper arguments";exit;
} else {
	$api_key  	= $argv[1];
	$api_pass 	= $argv[2];
	$user_name 	= $argv[3];
	$user_email	= $argv[4];
}
$url = 'http://103.129.99.74:2006/index.php?'.
		'api_key='.$api_key.
		'&api_pass='.$api_pass.
		'&api=serialize'.
		'&act=adduser';


$post = array('saveuser' => 1,
		'username' => $user_name,
		'user_email' => $user_email,
		'num_users' => '0');
$time = time();
// Set the curl parameters.
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// Turn off the server and peer verification (TrustManager Concept).
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

if(!empty($post)){
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
}
				 
// Get response from the server.
$resp = curl_exec($ch);
		  
// The response will hold a string as per the API response method. In this case its PHP Serialize
$res = unserialize($resp);
print_r(json_encode($res));
// Done ?
/*if(!empty($res['done'])){
	print_r($res);
	// Error
}else{
	echo 'Some error occured';
	print_r($res['error']);
}*/
return $res;
?>
