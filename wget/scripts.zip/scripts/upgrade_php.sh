echo -e "--------------------------------"
echo -e "1. PHP 7.0"
echo -e "2. PHP 7.1"
echo -e "3. PHP 7.2"
echo -e "--------------------------------"
echo -e "Enter your option >"
read javaversion
cd ~
yum -y install epel-release
wget -O ioncube_loaders_lin_x86-64.tar.gz http://hostingraja.info/ioncube_loaders_lin_x86-64.tar.gz
tar xfz ioncube_loaders_lin_x86-64.tar.gz
yum -y remove php php-common php-* *php-*
yum-config-manager --disable remi-php54
yum-config-manager --disable remi-php55 
yum-config-manager --disable remi-php56 
yum-config-manager --disable remi-php70
yum-config-manager --disable remi-php71
yum-config-manager --disable remi-php72
case "$javaversion" in
1)
yum-config-manager --enable remi-php70
yum update
yum -y install php 
yum -y install php-bcmath php-devel php-fedora-autoloader php-fpm php-gd php-imap php-intl php-mbstring php-mcrypt php-mysqlnd php-curl php-pdo php-pear  php-xsl php-pecl-jsonc php-pecl-jsonc-devel php-pecl-zip php-process php-soap php-suhosin php-xml php-xmlrpc php-zip 
yum -y install php70-php-bcmath php70-php-devel php-fedora-autoloader php70-php-fpm php70-php-gd php70-php-imap php70-php-intl php70-php-mbstring php70-php-mcrypt php70-php-mysqlnd php70-php-curl php70-php-pdo php70-php-pear  php70-php-xsl php70-php-pecl-jsonc php70-php-pecl-jsonc-devel php70-php-pecl-zip php70-php-process php70-php-soap php70-php-suhosin php70-php-xml php70-php-xmlrpc php70-php-zip 
IONCBEPATH=`php -i | grep extension_dir | awk 'NR == 1' | cut -d' ' -f3`
cp  /root/ioncube/ioncube_loader_lin_7.0.so $IONCBEPATH
chmod 755  $IONCBEPATH/ioncube_loader_lin_7.0.so
echo "zend_extension = $IONCBEPATH/ioncube_loader_lin_7.0.so"  >> /etc/php.ini
chmod +x /etc/sentora/panel/bin/setso
setso --set core_php_version php70
;;
2) 
yum-config-manager --enable remi-php71
yum update
yum -y install php
yum -y install php-bcmath php-devel php-fedora-autoloader php-fpm php-gd php-imap php-intl php-mbstring php-mcrypt php-mysqlnd php-curl php-pdo php-pear  php-xsl php-pecl-jsonc php-pecl-jsonc-devel php-pecl-zip php-process php-soap  php-xml php-xmlrpc php-zip 
yum -y install php71-php-bcmath php71-php-devel php-fedora-autoloader php71-php-fpm php71-php-gd php71-php-imap php71-php-intl php71-php-mbstring php71-php-mcrypt php71-php-mysqlnd php71-php-curl php71-php-pdo php71-php-pear  php71-php-xsl php71-php-pecl-jsonc php71-php-pecl-jsonc-devel php71-php-pecl-zip php71-php-process php71-php-soap php71-php-suhosin php71-php-xml php71-php-xmlrpc php71-php-zip 
IONCBEPATH=`php -i | grep extension_dir | awk 'NR == 1' | cut -d' ' -f3`
cp  /root/ioncube/ioncube_loader_lin_7.1.so $IONCBEPATH
chmod 755  $IONCBEPATH/ioncube_loader_lin_7.1.so
echo "zend_extension = $IONCBEPATH/ioncube_loader_lin_7.1.so"  >> /etc/php.ini
chmod +x /etc/sentora/panel/bin/setso
setso --set core_php_version php71
;;
3) 
yum-config-manager --enable remi-php72
yum update
yum -y install php
yum -y install php-bcmath php-devel php-fedora-autoloader php-fpm php-gd php-imap php-intl php-mbstring php-mcrypt php-mysqlnd php-curl php-pdo php-pear  php-xsl php-pecl-jsonc php-pecl-jsonc-devel php-pecl-zip php-process php-soap php-xml php-xmlrpc php-zip
yum -y install php72-php-bcmath php72-php-devel php-fedora-autoloader php72-php-fpm php72-php-gd php72-php-imap php72-php-intl php72-php-mbstring php72-php-mcrypt php72-php-mysqlnd php72-php-curl php72-php-pdo php72-php-pear  php72-php-xsl php72-php-pecl-jsonc php72-php-pecl-jsonc-devel php72-php-pecl-zip php72-php-process php72-php-soap php72-php-suhosin php72-php-xml php72-php-xmlrpc php72-php-zip 
IONCBEPATH=`php -i | grep extension_dir | awk 'NR == 1' | cut -d' ' -f3`
cp  /root/ioncube/ioncube_loader_lin_7.2.so $IONCBEPATH
chmod 755  $IONCBEPATH/ioncube_loader_lin_7.2.so
echo "zend_extension = $IONCBEPATH/ioncube_loader_lin_7.2.so"  >> /etc/php.ini
chmod +x /etc/sentora/panel/bin/setso
setso --set core_php_version php72
;;
*) echo -e "You have entered wrong option. Try aftesometime"
;;
esac
# //////////////////////////////////// Update php.ini file configuration start Here //////////////////////////////////////////////////////
echo 'session.save_path = "/tmp"' >> /etc/php.ini
echo "suhosin.session.encrypt = Off" >> /etc/php.ini
sed -i "s/^\(short_open_tag\).*/\1 = On /" /etc/php.ini
sed -i "s/^\(auto_prepend_file\).*/\1 = \"\/var\/sentora\/temp\/spamavoid\/php_execution_block.php\" /" /etc/php.ini
sed -i "s/^\(upload_max_filesize\).*/\1 = 512M /" /etc/php.ini
sed -i "s/^\(post_max_size\).*/\1 = 512M /" /etc/php.ini
sed -i "s/^\(memory_limit\).*/\1 = 128M /" /etc/php.ini
sed -i "s/^\(max_execution_time\).*/\1 = 300 /" /etc/php.ini
sed -i "s/^\(max_input_time\).*/\1 = 600 /" /etc/php.ini
sed -i "s/^\(sendmail_path\).*/\1 = \/usr\/local\/bin\/phpsendmail.php /" /etc/php.ini
# //////////////////////////////////// Update php.ini file configuration End  Here //////////////////////////////////////////////////////
yum -y install ImageMagick-devel
pecl install imagick
echo "extension=imagick.so"  >> /etc/php.ini
if [ -f "/usr/local/php56/bin/php" ]; 
then
echo "Already PHP Multiple Version Installed"
else
yum -y install mod_fcgid install gcc libxml2-devel libXpm-devel gmp-devel libicu-devel t1lib-devel aspell-devel openssl-devel bzip2-devel libcurl-devel libjpeg-devel libvpx-devel libpng-devel freetype-devel readline-devel libtidy-devel libxslt-devel libmcrypt-devel pcre-devel curl-devel mysql-devel ncurses-devel gettext-devel net-snmp-devel libevent-devel libtool-ltdl-devel libc-client-devel postgresql-devel bison gcc make;
mkdir -p /opt/;
cd /opt;
mkdir -p source;
cd source;
wget -O php5-6.tar.gz http://hostingraja.info/php5-6.tar.gz;
tar -xvzf php5-6.tar.gz;
cd php-5.6.28/;
sudo ./buildconf --force;
make clean;
make distclean;
./configure --prefix=/usr/local/php56 --with-config-file-path=/etc/php56 --with-config-file-scan-dir=/etc/php56/php.d --with-libdir=lib64 --with-mysql --with-mysqli --enable-mbstring --disable-debug --enable-fpm --disable-rpath --with-bz2 --with-curl --with-gettext --with-iconv --with-openssl --with-gd --with-jpeg-dir=/usr/lib64 --with-mcrypt --with-pspell --with-pcre-regex --with-zlib --enable-soap --enable-sockets --enable-sysvsem --enable-sysvshm --enable-pdo --enable-json --enable-cgi --enable-libxml --with-xsl --with-pdo-mysql --with-mysql-sock=/var/lib/mysql/mysql.sock  --enable-intl --with-icu-dir=DEFAULT --enable-zip --with-freetype-dir  --with-fpm-user=apache --with-fpm-group=apache --enable-fpm;
sleep 10;
make -j4 > /dev/null;
sleep 10;
make install;
ln -s  /usr/local/php56/sbin/php-fpm /usr/bin/php-fpm-56
yes | cp php.ini-production /etc/php56/php.ini;
cd ..;
rm -frv php-5.6.28;
rm -frv php5-6.tar.gz;
mkdir /etc/php56;
#cp php.ini-production /etc/php56/php.ini;
#/usr/local/php56/bin/pecl install zip;
#/usr/local/php56/bin/pecl install intl;
#echo "cgi.fix_pathinfo = 1" >> /etc/php56/php.ini;
mkdir -p /var/www/php-fcgi-scripts/php56;
touch /var/www/php-fcgi-scripts/php56/php-fcgi-starter;
echo '#!/bin/sh' > /var/www/php-fcgi-scripts/php56/php-fcgi-starter;
echo "PHPRC=/etc/" >> /var/www/php-fcgi-scripts/php56/php-fcgi-starter;
echo "export PHPRC= /etc/php56/php.ini" >> /var/www/php-fcgi-scripts/php56/php-fcgi-starter;
echo "export PHP_FCGI_MAX_REQUESTS=50000" >> /var/www/php-fcgi-scripts/php56/php-fcgi-starter;
echo "export PHP_FCGI_CHILDREN=1" >> /var/www/php-fcgi-scripts/php56/php-fcgi-starter;
echo "exec /usr/local/php56/bin/php-cgi" >> /var/www/php-fcgi-scripts/php56/php-fcgi-starter;
chmod 755 /var/www/php-fcgi-scripts/php56/php-fcgi-starter;
sed -i "s/^\(short_open_tag\).*/\1 = On /" /etc/php56/php.ini;
sed -i "s/^\(auto_prepend_file\).*/\1 = \"\/var\/sentora\/temp\/spamavoid\/php_execution_block.php\" /" /etc/php56/php.ini;
sed -i "s/^\(upload_max_filesize\).*/\1 = 512M /" /etc/php56/php.ini;
sed -i "s/^\(post_max_size\).*/\1 = 512M /" /etc/php56/php.ini;
sed -i "s/^\(memory_limit\).*/\1 = 128M /" /etc/php56/php.ini;
sed -i "s/^\(max_execution_time\).*/\1 = 300 /" /etc/php56/php.ini;
sed -i "s/^\(max_input_time\).*/\1 = 600 /" /etc/php56/php.ini;
sed -i "s/^\(sendmail_path\).*/\1 = \/usr\/local\/bin\/phpsendmail.php /" /etc/php56/php.ini;
sed -i "s|;date.timezone =|date.timezone = Asia\/Kolkata |" /etc/php56/php.ini
echo 'session.save_path = "/tmp"' >> /etc/php56/php.ini
IONCBEPATH=`/usr/local/php56/bin/php  -i | grep extension_dir | awk 'NR == 1' | cut -d' ' -f3`
cp  /root/ioncube/ioncube_loader_lin_5.6.so $IONCBEPATH
chmod 755  $IONCBEPATH/ioncube_loader_lin_5.6.so
echo "zend_extension = $IONCBEPATH/ioncube_loader_lin_5.6.so"  >> /etc/php56/php.ini
echo "---------------------------"
echo "PHP 5.6 Installation Completed"
cd /etc/
wget  -O lighttpd.zip "http://hostingraja.info/Version2.3/phpversionupdate/lighttpd.zip"
unzip -o lighttpd.zip
rm -f /etc/lighttpd.zip
service lighttpd restart
fi