#Postfix
currentdate="$(date +'%d%m%y')"
#echo $currentdate;
[ ! -d "/etc/config_backup/postfix" ] && mkdir -p /etc/config_backup/postfix
cp -p /etc/postfix/main.cf /etc/config_backup/postfix/etc_postfix_main.cf_$currentdate
cp -p /etc/postfix/master.cf /etc/config_backup/postfix/etc_postfix_master.cf_$currentdate
deletedate="$(date +'%d%m%y' --date="2 days ago")"
#echo $deletedate
[ -f /etc/config_backup/postfix/etc_postfix_main.cf_$deletedate ] && rm /etc/config_backup/postfix/etc_postfix_main.cf_$deletedate || echo "Not found"
[ -f /etc/config_backup/postfix/etc_postfix_master.cf_$deletedate ] && rm /etc/config_backup/postfix/etc_postfix_master.cf_$deletedate || echo "Not found"

#Dovecot
currentdate="$(date +'%d%m%y')"
#echo $currentdate;
[ ! -d "/etc/config_backup/dovecot" ] && mkdir -p /etc/config_backup/dovecot
cp -p /etc/dovecot/dovecot.conf /etc/config_backup/dovecot/etc_dovecot_dovecot.conf_$currentdate
deletedate="$(date +'%d%m%y' --date="2 days ago")"
#echo $deletedate
[ -f /etc/config_backup/dovecot/etc_dovecot_dovecot.conf_$deletedate ] && rm /etc/config_backup/dovecot/etc_dovecot_dovecot.conf_$deletedate || echo "Not found"

#Mysql
currentdate="$(date +'%d%m%y')"
#echo $currentdate;
[ ! -d "/etc/config_backup/mysql" ] && mkdir -p /etc/config_backup/mysql
cp -p /etc/my.cnf /etc/config_backup/mysql/etc_my.cnf_$currentdate
deletedate="$(date +'%d%m%y' --date="2 days ago")"
#echo $deletedate
[ -f /etc/config_backup/mysql/etc_my.cnf_$deletedate ] && rm /etc/config_backup/mysql/etc_my.cnf_$deletedate || echo "Not found"

#CSF
currentdate="$(date +'%d%m%y')"
#echo $currentdate;
[ ! -d "/etc/config_backup/csf" ] && mkdir -p /etc/config_backup/csf
cp -p /etc/csf/csf.conf /etc/config_backup/csf/etc_csf_csf.conf_$currentdate
deletedate="$(date +'%d%m%y' --date="2 days ago")"
#echo $deletedate
[ -f /etc/config_backup/csf/etc_csf_csf.conf_$deletedate ] && rm /etc/config_backup/csf/etc_csf_csf.conf_$deletedate || echo "Not found"

#Apache
currentdate="$(date +'%d%m%y')"
#echo $currentdate;
[ ! -d "/etc/config_backup/apache" ] && mkdir -p /etc/config_backup/apache
cp -p /etc/httpd/conf/httpd.conf /etc/config_backup/apache/etc_httpd_conf_httpd.conf_$currentdate
cp -p /etc/httpd/conf.d/ssl.conf /etc/config_backup/apache/etc_httpd_confd_ssl.conf_$currentdate
cp -p /etc/sentora/configs/apache/httpd.conf /etc/config_backup/apache/etc_sentora_configs_apache_httpd.conf_$currentdate
cp -r /etc/sentora/configs/apache/domains /etc/config_backup/apache/etc_sentora_configs_apache_domains_$currentdate
deletedate="$(date +'%d%m%y' --date="2 days ago")"
#echo $deletedate
[ -f /etc/config_backup/apache/etc_httpd_conf_httpd.conf_$deletedate ] && rm /etc/config_backup/apache/etc_httpd_conf_httpd.conf_$deletedate || echo "Not found"
[ -f /etc/config_backup/apache/etc_httpd_confd_ssl.conf__$deletedate ] && rm /etc/config_backup/apache/etc_httpd_confd_ssl.conf_$deletedate || echo "Not found"
[ -f /etc/config_backup/apache/etc_sentora_configs_apache_httpd.conf_$deletedate ] && rm /etc/config_backup/apache/etc_sentora_configs_apache_httpd.conf_$deletedate || echo "Not found"
[ -d /etc/config_backup/apache/etc_sentora_configs_apache_domains_$deletedate ] && rm -frv /etc/config_backup/apache/etc_sentora_configs_apache_domains_$deletedate || echo "Not found"

#Java
#!/bin/bash
PHP_PATH=`whereis php | awk '{print $2}'`
java_path=`$PHP_PATH -f /scripts/GetJavaPath.php`
#java_path=$1
#echo $java_path;
file_name=${java_path#"/"}
file_name="${file_name////_}"
#echo $file_name 
currentdate="$(date +'%d%m%y')"
#echo $file_name"conf_server.xml_"$currentdate;
[ ! -d "/etc/config_backup/java" ] && mkdir -p /etc/config_backup/java
cp -p "$java_path"conf/server.xml /etc/config_backup/java/$file_name"conf_server.xml_"$currentdate
deletedate="$(date +'%d%m%y' --date="2 days ago")"
#echo $deletedate
[ -f /etc/config_backup/java/$file_name"conf_server.xml_"$deletedate ] && rm /etc/config_backup/java/$file_name"conf_server.xml_"$deletedate || echo "Not found"
find /etc/config_backup/  -type f -exec chmod 700 {} \;
