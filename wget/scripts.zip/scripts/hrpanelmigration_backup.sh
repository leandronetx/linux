mkdir -p /backups
cd /backups
cd /var/sentora/
zip -r /backups/hrmigration hostdata 2>&1
mkdir -p /backups/mysql
mysqldump --all-databases > /backups/mysql/mysql.sql
zip -ur /backups/hrmigration /backups/mysql 2>&1
cd /var/sentora/ && zip -ur /backups/hrmigration vmail 2>&1
