#!/usr/bin/env bash
if [ "$#" -lt 1 ]
then
	echo " " 
else
	ver_d=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
	pos_status=0;
	path_status=1;
	if  yum list installed |grep -F 'postfix' > /dev/null  
	then
		echo "">/dev/null;
	else
		pos_status=1;
	fi
	main_file_path=/etc/postfix/main.cf;
	if [ -f "$main_file_path" ]
	then
		path_status=0
	fi
	if [ "$path_status" == 0 ]  
	then
		case  $1 in 
		getip)
			IP="";
			OS=`uname`
			CIP=''
			case $OS in
			Linux)
			if [ -f /etc/redhat-release ];
			then 
				if [ "$ver_d" == 7 ]
				then
					IP=`ip addr | grep 'scope global' | awk '{print $2}' | cut -f1  -d'/'`
				else
					IP=`ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $1}'`
				fi
				CIP=`grep "smtp_bind_address"  $main_file_path  | cut -d"=" -f2`
			fi
			;;
			Darwin|FreeBSD|OpenBSD) IP=`ifconfig  | grep -E 'inet.[0-9]' | grep -v '127.0.0.1' | awk '{ print $2}'` ;;
			SunOS) IP=`ifconfig -a | grep inet | grep -v '127.0.0.1' | awk '{ print $2} '` ;;
			*) IP="";;
			esac
			ipdata=""
			if [ -z "$CIP" ]
			then
				echo "">/dev/null; 
			else
				ipdata+="$CIP@" 
			fi
			if [ -z "$IP" ]
			then
				echo 
			else
				for a in $IP
				do 
					ipdata+="$a ";
				done
			fi
			echo $ipdata
		;;
		resetip)
			NEWIP=$2
			r=$(( $RANDOM  ));
			n_file_detail=$main_file_path$r;
			back_main_file_detail="/etc/postfix/main.cf_back_g";
			if [ -f "$back_main_file_detail" ];
			then 
				yes | cp -avr  $main_file_path  $back_main_file_detail; 
			else
				cp -avr $main_file_path  $back_main_file_detail;
			fi
			yes | cp -avr  $main_file_path   $n_file_detail 
			sed -i "/smtp_bind_address/d"  $main_file_path
			echo -e "smtp_bind_address = $NEWIP" >> $main_file_path;
			if [ "$ver_d" == 7 ]
			then
				systemctl restart postfix ;
			else
				service postfix restart ;
			fi
			echo
		;;
		removeip)
                        r=$(( $RANDOM  ));
                        n_file_detail=$main_file_path$r;
                        back_main_file_detail="/etc/postfix/main.cf_back_g";
                        if [ -f "$back_main_file_detail" ];
                        then
                                yes | cp -avr  $main_file_path  $back_main_file_detail;
                        else
                                cp -avr $main_file_path  $back_main_file_detail;
                        fi
                        yes | cp -avr  $main_file_path   $n_file_detail
                        sed -i "/smtp_bind_address/d"  $main_file_path
                        if [ "$ver_d" == 7 ]
                        then
                                systemctl restart postfix ;
                        else
                                service postfix restart ;
                        fi
                        echo
                ;;
		getmailip)
			CIP=`grep "smtp_bind_address"  $main_file_path ` 
			echo $CIP
			;;
		*)
			echo " ";
		;;
		esac
	else
		echo " "
	fi
fi






