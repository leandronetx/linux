<?php
if($argc<2) {
	echo "Please pass the proper filename to migrate";exit;
} else { 
	$file_name = $argv[1]; 
}
require_once("/scripts/MysqlTableModifyToNewerVersion.php"); 
$migration_restore = new HrPanelToHrPanelMigrationRestore;
$migration_restore->calculateFreeSpace($file_name);
class HrPanelToHrPanelMigrationRestore
{
	private $zdbh;
        private $mail_db;
        private $time_stamp;
        private $vhost_path;
        private $backup_filename;
        public function __construct()
        {
                require('/etc/sentora/panel/cnf/db.php');
                require_once('/etc/sentora/panel/dryden/db/driver.class.php');
                include_once('/etc/sentora/panel/dryden/debug/logger.class.php');
                include_once('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
                include_once('/etc/sentora/panel/dryden/runtime/controller.class.php');
                include_once('/etc/sentora/panel/dryden/runtime/hook.class.php');
                include_once('/etc/sentora/panel/dryden/sys/versions.class.php');
                include_once('/etc/sentora/panel/dryden/ctrl/options.class.php');
                include_once('/etc/sentora/panel/dryden/fs/director.class.php');
                include_once('/etc/sentora/panel/dryden/fs/filehandler.class.php');
                include_once('/etc/sentora/panel/inc/dbc.inc.php');
                $mailserver_db = ctrl_options::GetSystemOption('mailserver_db');
                try
                {
                        $this->zdbh = new db_driver("mysql:host=" . $host . ";dbname=" . $dbname . "", $user, $pass);
                        $this->mail_db = new db_driver("mysql:host=" . $host . ";dbname=" . $mailserver_db . "", $user, $pass);
                }
                catch (PDOException $e)
                {
                        exit();
                }
                date_default_timezone_set('Asia/Calcutta');
                $this->time_stamp = date("M-d-Y_hms", time());
                $this->vhost_path = ctrl_options::GetSystemOption('hosted_dir');
		$this->backup_path = "/backup/migration/";
		//$this->filename = $argv[1];//'full_backup_for_migration_Jul-02-2018_040733.zip';
                //$this->backup_filename= $this->backup_path."full_backup_for_migration_$this->time_stamp";
                //$this->backup_filename= "full_backup_for_migration_$this->time_stamp";
        }
	public function calculateFreeSpace($file_name)
	{
		$path = $this->backup_path.$file_name;
		echo "\nPath: ".$path;
		echo "\nunzip -l $path | tail -1 | awk '{print $1/1024}'";
		$total_bk_size_in_kb  = trim(shell_exec("unzip -l $path | tail -1 | awk '{print $1/1024}'"));
		$available_size_in_kb = trim(shell_exec("df | awk '{print $4}' | head -2 | tail -1"));
		$overall_size_in_kb   = trim(shell_exec("df | awk '{print $2}' | head -2 | tail -1"));
		echo "\nTotalSizeNeeded: ".$total_bk_size_in_kb;
		echo "\nAvailableSize  : ".$available_size_in_kb;
		echo "\nOverallSize    : ".$overall_size_in_kb;

		$remaining_size_in_kb = $available_size_in_kb - $total_bk_size_in_kb;
                echo "\nRemainingSize : ".$remaining_size_in_kb;
                $remaining_percentage = ($remaining_size_in_kb / $overall_size_in_kb) * 100 ;
                echo "\nRemainingePerc: ".$remaining_size_in_kb;
		
		if($available_size_in_kb < $total_bk_size_in_kb )
		{
			echo "Due to disk space exceed, your restore does not working. kindly contact your administrator.";
			exit;
		}
		else if($remaining_percentage < 5 )
		{
			echo "Due to disk space exceed, your restore not working. kindly contact your administrator.";
			exit;
		}
		else
		{
			self::restoreHostData($file_name);
		}
	}
	public function restoreHostData($file_name)
	{
		echo "\nRestoring HostData...";
		$dest_path= $this->vhost_path;
                $src_path = $this->backup_path;
                $cmd="cd $src_path && unzip -n $file_name -d $dest_path 2>&1 ";
                $output=array();
                $return_val= "";
                $output= passthru($cmd,$return_val);
                exec("chown -R apache:apache $dest_path");
                exec("chmod -R 0755 $dest_path");
		$mail_path=$dest_path."Mail.zip";
                if(file_exists($mail_path))
                {
			self::restoreVmail();
		}	
		//$dbname=md5(sha1($username."SQL")).".sql";
		$dbname = "all_database.sql";
		if(file_exists("/var/sentora/hostdata/mysql_migrate/".$dbname))
		{
			self::restoreDatabase($dbname);
		}
		$modify_table=new MysqlTableModifyToNewerVersion();
		$modify_table->addColumnIfDoesNotExists('x_accounts','ip_deleted','varchar(20) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_apachespam_settings','x_spam_enable','varchar(20) NOT NULL');
		$modify_table->addColumnIfDoesNotExists('x_ftpaccounts','ip_deleted','varchar(20) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_header_checks','x_rule_1','varchar(255) NOT NULL');
		$modify_table->addColumnIfDoesNotExists('x_header_checks','x_rule_2','varchar(255) NOT NULL');
		$modify_table->addColumnIfDoesNotExists('x_header_checks','x_rule_3','varchar(255) NOT NULL');
		$modify_table->addColumnIfDoesNotExists('x_header_checks','x_actions_1','varchar(100) NOT NULL');
		$modify_table->addColumnIfDoesNotExists('x_mailboxes','mb_quota','bigint(10) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_mailboxes','ip_deleted','varchar(20) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_mysql_databases','ip_deleted','varchar(20) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_mysql_users','ip_deleted','varchar(20) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_quotas','qt_domain_forwarders_in',"int(6) NOT NULL DEFAULT '0'");
		$modify_table->addColumnIfDoesNotExists('x_vhosts','vh_modhttp',"int(1) DEFAULT '1'");
		$modify_table->addColumnIfDoesNotExists('x_vhosts','vh_modhttp_status',"int(1) DEFAULT '1'");
		$modify_table->addColumnIfDoesNotExists('x_vhosts','ip_deleted','varchar(20) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_ssl','ssl_created','int(30) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_ssl','ssl_delete','int(30) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_ssl','ssl_status','varchar(50) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_ssl','ssl_www','varchar(20) DEFAULT NULL');
		$modify_table->addColumnIfDoesNotExists('x_ssl','ip_deleted','varchar(20) DEFAULT NULL');
		$modify_table->renameTable("x_phpversion_upgrade","x_phpversion_upgrade_old");
	}
	public function restoreVmail()
	{
		echo "Restoring Vmail...";
                $mail_path=$this->vhost_path."Mail_migrate.zip";
                if(file_exists($mail_path))
                {
                        $mail_dest_path="/var/sentora/vmail/";
                        //$src_path="/backup/".$username."/";
                        $src_path="/backup/";
                        $cmd="cd $this->vhost_path && unzip -n Mail_migrate.zip -d $mail_dest_path 2>&1 ";
                        $output=array();
                        $return_val="";
                        $output=passthru($cmd,$return_val);
                        passthru("chown -R vmail:mail $mail_dest_path");
                        passthru("chmod -R 0755 $mail_dest_path");
                        if(file_exists($mail_path) && ($mail_path!="" || $mail_path!="/")) exec("rm -fr $mail_path ");
                }
                else
                {
                        echo "Mailbackup not available";
                }
	}
	public function restoreDatabase($dbname)
	{
		echo "Restoring Database...";
		//$cmd="mysql -u $user -p$pass < /var/sentora/hostdata/$username/mysql/$dbname";
		$cmd="mysql -u root < /var/sentora/hostdata/mysql_migrate/$dbname";
		$output=passthru($cmd,$return_val);
		$output=array();
		$return_val="";
		$output=passthru($cmd,$return_val);
		$cmd="rm -fr /var/sentora/hostdata/mysql_migrate";
		exec($cmd);
		return TRUE;
	}
}
?>
