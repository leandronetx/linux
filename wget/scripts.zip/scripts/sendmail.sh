#!/bin/bash
CURRENT=$(df / | grep / | awk '{ print $5}' | sed 's/%//g')
THRESHOLD=85
if [ "$CURRENT" -gt "$THRESHOLD" ] ; then
echo "Above mail" 
#/usr/bin/php -f /scripts/mailscript.php $CURRENT
PHP_PATH=`whereis php | awk '{print $2}'`
`$PHP_PATH -f /scripts/mailscript.php $CURRENT`
fi
