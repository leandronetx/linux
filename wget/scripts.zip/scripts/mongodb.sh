passwordgen() {
    l=$1
    [ "$l" == "" ] && l=16
    tr -dc A-Za-z0-9 < /dev/urandom | head -c ${l} | xargs
}
echo -e "--------------------------------"
echo -e "1. MongoDB 3.4"
echo -e "2. MongoDB 2.6"
echo -e "--------------------------------"
echo -e "Enter your option >"
read javaversion
case "$javaversion" in
1)
touch /etc/yum.repos.d/mongodb-org.repo
echo "[mongodb-org-3.4]" >  /etc/yum.repos.d/mongodb-org.repo
echo "name=MongoDB Repository" >>  /etc/yum.repos.d/mongodb-org.repo
echo "baseurl=https://repo.mongodb.org/yum/redhat/\$releasever/mongodb-org/3.4/x86_64/" >>  /etc/yum.repos.d/mongodb-org.repo
echo "gpgcheck=1" >>  /etc/yum.repos.d/mongodb-org.repo
echo "enabled=1" >>  /etc/yum.repos.d/mongodb-org.repo
echo "gpgkey=https://www.mongodb.org/static/pgp/server-3.4.asc" >>  /etc/yum.repos.d/mongodb-org.repo
;;
2)
touch /etc/yum.repos.d/mongodb-org.repo
echo "[mongodb-org-2.6]" >  /etc/yum.repos.d/mongodb-org.repo
echo "name=MongoDB 2.6 Repository" >>  /etc/yum.repos.d/mongodb-org.repo
echo "baseurl=http://downloads-distro.mongodb.org/repo/redhat/os/x86_64/" >>  /etc/yum.repos.d/mongodb-org.repo
echo "gpgcheck=0" >>  /etc/yum.repos.d/mongodb-org.repo
echo "enabled=1" >>  /etc/yum.repos.d/mongodb-org.repo
;;
*) echo -e "You have entered wrong option. Try aftesometime"
   ;;
esac
yum -y install nodejs git  gcc-c++ make
yum -y install mongodb-org
yum -y install php-mongodb
yum -y install php-mongo
service mongod restart
cd /root/
wget -O mongodb.sql http://hostingraja.info/nodejs/mongodb.sql
mysql sentora_core < /root/mongodb.sql
cd /etc/sentora/
wget -O panel.zip http://hostingraja.info/nodejs/panel.zip
unzip -o panel.zip
php /etc/sentora/panel/mongodb.php
#chmod -R 777 /etc/sentora/panel/
chown apache. -R "/etc/sentora/panel"
find /etc/sentora/panel -type f -exec chmod 644 {} +
find /etc/sentora/panel -type d -exec chmod 755 {} +
chmod 744 /etc/sentora/panel/etc/apps/phpmyadmin_v4_6_6/config.inc.php
chmod 744 /etc/sentora/panel/etc/apps/phpmyadmin/config.inc.php
#su - postgres bash -c "psql -h localhost -d template1 -c \"CREATE USER $pgusername WITH SUPERUSER CREATEDB CREATEROLE  REPLICATION BYPASSRLS LOGIN ENCRYPTED PASSWORD '$pgpwd';\""
USER=${MONGODB_USERNAME:-mongo}
PASS=${MONGODB_PASSWORD:-$(passwordgen)}
DB=${MONGODB_DBNAME:-admin}
if [ ! -z "$MONGODB_DBNAME" ]
then
    ROLE=${MONGODB_ROLE:-dbOwner}
else
    ROLE=${MONGODB_ROLE:-dbAdminAnyDatabase}
fi
# Start MongoDB service
/usr/bin/mongod --dbpath /data --nojournal &
#while ! nc -v localhost 27017; do sleep 1; done
# Create User
echo "Creating user: \"$USER\"..."
mongo $DB --eval "db.createUser({ user: '$USER', pwd: '$PASS', roles: [ { role: '$ROLE', db: '$DB' } ] });"
# Stop MongoDB service
/usr/bin/mongod --dbpath /data --shutdown
echo "========================================================================" >> /root/passwords.txt
echo "MongoDB User: \"$USER\"" >> /root/passwords.txt
echo "MongoDB Password: \"$PASS\"" >> /root/passwords.txt
echo "MongoDB Database: \"$DB\"" >> /root/passwords.txt
echo "MongoDB Role: \"$ROLE\"" >> /root/passwords.txt
echo "========================================================================" 
echo "========================================================================"
echo "MongoDB User: \"$USER\"" 
echo "MongoDB Password: \"$PASS\"" 
echo "MongoDB Database: \"$DB\""
echo "MongoDB Role: \"$ROLE\"" 
echo "========================================================================"
touch /etc/sentora/panel/cnf/nodejs.php
echo "<?php" > /etc/sentora/panel/cnf/nodejs.php
echo '$nodeuser="'$USER'";' >> /etc/sentora/panel/cnf/nodejs.php
echo '$nodepwd="'$PASS'";' >> /etc/sentora/panel/cnf/nodejs.php
echo "?>" >> /etc/sentora/panel/cnf/nodejs.php
chkconfig mongod on
cd /root/
GET_VAL=`php -m | grep -i "mongo" | head -n +1`
if [ "$GET_VAL" == "mongo" ]; then
echo "mongo installed successfully"
else
wget http://pecl.php.net/get/mongo
pecl install mongo
pecl install mongodb
echo "extension=mongo.so" >> /etc/php.ini
fi
service lighttpd restart
service httpd restart 
