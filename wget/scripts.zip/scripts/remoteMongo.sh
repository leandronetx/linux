filechk="/var/log/mongodb/mongo_remote.log"
if [ -f "$filechk" ]
then
    echo "Remote Mongo Already Updated" >> $filechk
    echo "Remote Mongo Already Updated"
    exit
fi
touch $filechk
echo "Remote Mongo started here"
echo "Remote Mongo started here" >> $filechk
port_check=`lsof -i:27017 -S | tail -1 |  cut -d " " -f1`
if [ ! -z "$port_check" ]; then
        re_check=`grep "bindIp: 127.0.0.1" /etc/mongod.conf`
        if [ ! -z "$re_check" ]; then
		PASSWORD=`grep "MongoDB Password:" /root/passwords.txt | awk {'print $3'}`
		PASSWD=`sed -e 's/^"//' -e 's/"$//' <<<"$PASSWORD"`
		USER=${MONGODB_USERNAME:-mongo}
		PASS=${MONGODB_PASSWORD:-$PASSWD}
		DB=${MONGODB_DBNAME:-admin}
		ROLE=${MONGODB_ROLE:-root}
		# Start MongoDB service
		/usr/bin/mongod --dbpath /data --nojournal &
		#while ! nc -v localhost 27017; do sleep 1; done
		# Create User
		echo "Creating user: \"$USER\"..."
		mongo $DB --eval "db.dropUser('mongo');"
		mongo $DB --eval "db.createUser({ user: '$USER', pwd: '$PASS', roles: [ { role: '$ROLE', db: '$DB' } ] });"
                line_no=`grep -no "#security" /etc/mongod.conf | awk '{print $1}' FS=":"`
                line=$line_no"s"
                line1=`expr "$line_no" + "1"`
                line2=$line1"i"
		`sed -i 's/bindIp: 127.0.0.1/bindIp: 0.0.0.0/g' /etc/mongod.conf`
                `sed -i "$line/#security/security/" /etc/mongod.conf`
                `ex -s -c "$line2|  authorization: \"enabled\"" -c x /etc/mongod.conf`
		`rm -f /tmp/mongodb-27017.sock`
                service mongod restart
        else
                echo "Not able to find local IP.." >> $filechk
                echo "Not able to find local IP.."
        fi
else
        echo "Mongo DB not Running..."
        echo "Mongo DB not Running..." >> $filechk
fi
echo "Remote Mongo DB security patch end" >> $filechk
echo "Remote Mongo DB security patch end"
