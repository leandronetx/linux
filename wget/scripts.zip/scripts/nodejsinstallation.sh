echo -e "--------------------------------"
echo -e "1.Node.js 6"
echo -e "2.Node.js 8"
echo -e "3.Node.js 9"
echo -e "4.Node.js 10"
echo -e "5.Node.js 12"
echo -e "--------------------------------"
echo -e "Enter your option >"
read javaversion
case "$javaversion" in
1) 
#curl --silent --location http://hostingraja.info/nodejs/setup_6.x | sudo bash -
curl --silent --location https://rpm.nodesource.com/setup_6.x | sudo bash -
;;
2) 
#curl --silent --location http://hostingraja.info/nodejs/setup_8.x | sudo bash -
curl --silent --location https://rpm.nodesource.com/setup_8.x | sudo bash -
;;
3)
curl --silent --location https://rpm.nodesource.com/setup_9.x | sudo bash -
;;
4)
curl --silent --location https://rpm.nodesource.com/setup_10.x | sudo bash -
;;
5)
curl --silent --location https://rpm.nodesource.com/setup_12.x | sudo bash -
;;
*) echo -e "You have entered wrong option. Try aftesometime"
	exit
   ;;
esac
mkdir /var/lib/rpm/backup
cp -a /var/lib/rpm/__db* /var/lib/rpm/backup/
rm -f /var/lib/rpm/__db.[0-9][0-9]*
rpm --quiet -qa
rpm --rebuilddb
yum clean all
yum -y install nodejs git  gcc-c++ make
npm install -g pm2
npm install -g grunt-cli
npm install -g gulp
npm install webpack -g
chown ovipanel. -R "/etc/sentora/panel"
mkdir -p /etc/sentora/configs/apache/nodejs
find /etc/sentora/panel -type f -exec chmod 644 {} +
find /etc/sentora/panel -type d -exec chmod 755 {} +
chmod +x /etc/sentora/panel/bin/setso
chmod +x /etc/sentora/panel/bin/zsudo
chmod +x /etc/sentora/panel/bin/setzadmin
wget  -O nodejsmoduleenable.zip "http://d.ovipanel.in/Version3.7/nodejsmoduleenable.zip"
unzip -o nodejsmoduleenable.zip
php nodejsmoduleenable.php
mkdir -p /var/sentora/logs/nodejs
rm -frv  nodejsmoduleenable.zip
kill -9 $(lsof -t -i:80)
kill -9 $(lsof -t -i:8080)
setso --set apache_port 80
setso --set sentora_port 80
php /etc/sentora/panel/bin/daemon.php
service lighttpd restart
service varnish stop
service httpd restart
chkconfig varnish off
echo "clink /usr/bin/node /usr/bin/node" >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "clink /usr/bin/npm /usr/bin/npm" >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "clink /usr/bin/pm2 /usr/bin/pm2" >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "clink /usr/bin/gulp /usr/bin/gulp" >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "clink /usr/bin/grunt /usr/bin/grunt" >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "clink /usr/bin/webpack /usr/bin/webpack" >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "clink /usr/bin/env /usr/bin/env" >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "clink /usr/bin/curl /usr/bin/curl"  >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "clink /usr/bin/wget /usr/bin/wget"  >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "clink /usr/bin/ping /usr/bin/ping"  >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "clink /etc/resolv.conf /etc/resolv.conf"  >> /etc/jail-shell/jail-config/sample-jail.cfg
echo "bind /usr/lib/node_modules /usr/lib/node_modules ro,nodev,exec,nosuid"  >> /etc/jail-shell/jail-config/sample-jail.cfg
service jail-shell restart
