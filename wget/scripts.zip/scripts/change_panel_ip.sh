echo "0" > /scripts/readfile_results

echo "change_panel_ip_started" >> /root/panel_change.log

sh /scripts/switchip.sh

echo "change_panel_ip_ended" >> /root/panel_change.log

echo "1" > /scripts/readfile_results

