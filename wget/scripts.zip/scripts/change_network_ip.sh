ips=`cat /scripts/ip.txt`
privateip=`echo $ips | cut -d' ' -f2`
publicip=`echo $ips | cut -d' ' -f1`
gatewayip=`echo $ips | cut -d' ' -f3`
hostname=`echo $ips | cut -d' ' -f4`
email=`echo $ips | cut -d' ' -f5`

#change network ip

sed -i "s/192.168.0.130/$privateip/g" /etc/sysconfig/network-scripts/ifcfg-ens192
sed -i "s/192.168.0.1/$gatewayip/g" /etc/sysconfig/network-scripts/ifcfg-ens192

sed -i "s/NEW_PUBLIC_IP/$publicip/g" /scripts/switchip.sh
sed -i "s/NEW_PRIVATE_IP/$privateip/g" /scripts/switchip.sh
sed -i "s/NEW_HOSTNAME/$hostname/g" /scripts/switchip.sh
sed -i "s/CLIENT_EMAIL/$email/g" /scripts/switchip.sh

sed -i "s/IPADDR/$publicip/g" /etc/sysconfig/shellinaboxd
service shellinaboxd restart


