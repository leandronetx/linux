#!/usr/bin/env bash
php_path="/etc/php.d";
reloadhttpd()
{
    if [ "$1" == 7 ]
    then  
	    if  yum list installed  |  grep -Fi 'httpd' >>/dev/null;
            then
		    sudo systemctl restart httpd
        fi
    else
        if  yum list installed  |  grep -Fi 'httpd' >>/dev/null;
            then
		    sudo service httpd restart
        fi
    fi
}

removesofile()
{
	echo  $*;
	temp_store_path=$1;
	so_ext_detail=$2;
	n_php_path=$3
	g=$(( $RANDOM  ));
	random_temp_file=$temp_store_path"so"$g
	echo $random_temp_file;
	grep -rni $so_ext_detail $n_php_path >$random_temp_file
	while read module_data_detail;
	do
		trim_module_detail=`echo $module_data_detail | sed -e 's/ / /g' `
		module_file_path=`echo $trim_module_detail | awk '{print $1}' FS=":" `
		load_module_detail=`echo $trim_module_detail | awk '{print $3}' FS=":"`
		module_str_first_letter="${load_module_detail:0:1}"
		module_line_no=`echo $trim_module_detail | awk '{print $2}' FS=":"`
		if [[ $module_line_no = *[[:digit:]]* ]]; then
			sed -i "${module_line_no}d"   $module_file_path;
		fi
	done < $random_temp_file
}

if [ "$#" -lt 2 ]
then
	echo ""; 

else

	ver_d=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
	serv=$1
	pack=$2
	ext_dir=$(php-config --extension-dir)"/";
	perm_d="0755";
	php_ini_path="/etc/php.ini";
	status=0
	if  yum list installed  |  grep -Fi 'php-pear' >>/dev/null;	
	then
		status=1;
	else
		yum install gcc php-devel php-pear  -y
		status=1;
	fi

	case $serv in
   		install)
			case $pack in 
			
				memcache)
					yum install zlib-devel -y	
					#yes | pecl install memcache;
					yum -y install php-pecl-memcache
					yum -y install php54-php-pecl-memcache php55-php-pecl-memcache php56-php-pecl-memcache php70-php-pecl-memcache php71-php-pecl-memcache php72-php-pecl-memcache php73-php-pecl-memcache
					extd="memcache.so";
					m_path=$ext_dir$extd;
					if [ -f  "$m_path" ]
					then
						chmod  -R   $perm_d $m_path; 
						line1=$(grep -n "extension=$extd*"  $php_ini_path  | awk '{print $1}' FS=":")
                        			if [ -z "$line1" ]
    	                			then
         				    		echo -e "extension=$extd"  >> $php_ini_path;
						fi
						php54_ini_path="/etc/opt/remi/php54/php.ini";
						if [ -f "$php54_ini_path" ] ; then
							line2=$(grep -n "extension=$extd*"  $php54_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line2" ]
							then
								echo -e "extension=$extd"  >> $php54_ini_path;
							fi
						fi
						php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
						if [ -f "$php54_ini_path1" ] ; then
							line3=$(grep -n "extension=$extd*"  $php54_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line3" ]
							then
								echo -e "extension=$extd"  >> $php54_ini_path1;
							fi
						fi
						php55_ini_path="/etc/opt/remi/php55/php.ini"
						if [ -f "$php55_ini_path" ] ; then
							line4=$(grep -n "extension=$extd*"  $php55_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line4" ]
							then
								echo -e "extension=$extd"  >> $php55_ini_path;
							fi
						fi
						php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
						if [ -f "$php55_ini_path1" ] ; then
							line5=$(grep -n "extension=$extd*"  $php55_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line5" ]
							then
								echo -e "extension=$extd"  >> $php55_ini_path1;
							fi
						fi
						php56_ini_path="/etc/opt/remi/php56/php.ini"
						if [ -f "$php56_ini_path" ] ; then
							line6=$(grep -n "extension=$extd*"  $php56_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line6" ]
							then
								echo -e "extension=$extd"  >> $php56_ini_path;
							fi
						fi
						php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
						if [ -f "$php56_ini_path1" ] ; then
							line7=$(grep -n "extension=$extd*"  $php56_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line7" ]
							then
								echo -e "extension=$extd"  >> $php56_ini_path1;
							fi
						fi
						php71_ini_path="/etc/opt/remi/php71/php.ini"
						if [ -f "$php71_ini_path" ] ; then
							line8=$(grep -n "extension=$extd*"  $php71_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line8" ]
							then
								echo -e "extension=$extd"  >> $php71_ini_path;
							fi
						fi
						php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
						if [ -f "$php71_ini_path1" ] ; then
							line9=$(grep -n "extension=$extd*"  $php71_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line9" ]
							then
								echo -e "extension=$extd"  >> $php71_ini_path1;
							fi
						fi
						php72_ini_path="/etc/opt/remi/php72/php.ini"
						if [ -f "$php72_ini_path" ] ; then
							line10=$(grep -n "extension=$extd*"  $php72_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line10" ]
							then
								echo -e "extension=$extd"  >> $php72_ini_path;
							fi
						fi
						php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
						if [ -f "$php72_ini_path1" ] ; then
							line11=$(grep -n "extension=$extd*"  $php72_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line11" ]
							then
								echo -e "extension=$extd"  >> $php72_ini_path1;
							fi
						fi
						php73_ini_path="/etc/opt/remi/php73/php.ini"
						if [ -f "$php73_ini_path" ] ; then
							line12=$(grep -n "extension=$extd*"  $php73_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line12" ]
							then
								echo -e "extension=$extd"  >> $php73_ini_path;
							fi
						fi
						php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
						if [ -f "$php73_ini_path1" ] ; then
							line13=$(grep -n "extension=$extd*"  $php73_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line13" ]
							then
								echo -e "extension=$extd"  >> $php73_ini_path1;
							fi
						fi
					fi
					reloadhttpd   $ver_d;				
						
				;;
				gender)
					yum -y install php-pecl-gender
					#yes | pecl install gender ;
					yum -y install https://d.ovipanel.com/Version3.1/gender/php54-php-pecl-gender-1.1.0-7.fc25.remi.x86_64.rpm
					yum -y install https://d.ovipanel.com/Version3.1/gender/x86_64/php55-php-pecl-gender-1.1.0-7.fc25.remi.x86_64.rpm
					yum -y install https://d.ovipanel.com/Version3.1/gender/php56-php-pecl-gender-1.1.0-1.el7.remi.x86_64.rpm
					yum -y install https://d.ovipanel.com/Version3.1/gender/x86_64/php71-php-pecl-gender-1.1.0-8.el7.remi.x86_64.rpm
					yum -y install https://d.ovipanel.com/Version3.1/gender/x86_64/php72-php-pecl-gender-1.1.0-13.fc30.remi.x86_64.rpm
					yum -y install https://d.ovipanel.com/Version3.1/gender/php73-php-pecl-gender-1.1.0-13.fc30.remi.x86_64.rpm
					extd="gender.so"; 
					m_path=$ext_dir$extd;
					if [ -f  "$m_path" ]
					then
						chmod  -R $perm_d $m_path;
						line1=$(grep -n "extension=$extd*"  $php_ini_path  | awk '{print $1}' FS=":")
						if [ -z "$line1" ]
						then
							echo -e "extension=$extd"  >> $php_ini_path;
						fi
						php54_ini_path="/etc/opt/remi/php54/php.ini";
						if [ -f "$php54_ini_path" ] ; then
							line2=$(grep -n "extension=$extd*"  $php54_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line2" ]
							then
								echo -e "extension=$extd"  >> $php54_ini_path;
							fi
						fi
						php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
						if [ -f "$php54_ini_path1" ] ; then
							line3=$(grep -n "extension=$extd*"  $php54_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line3" ]
							then
								echo -e "extension=$extd"  >> $php54_ini_path1;
							fi
						fi
						php55_ini_path="/etc/opt/remi/php55/php.ini"
						if [ -f "$php55_ini_path" ] ; then
							line4=$(grep -n "extension=$extd*"  $php55_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line4" ]
							then
								echo -e "extension=$extd"  >> $php55_ini_path;
							fi
						fi
						php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
						if [ -f "$php55_ini_path1" ] ; then
							line5=$(grep -n "extension=$extd*"  $php55_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line5" ]
							then
								echo -e "extension=$extd"  >> $php55_ini_path1;
							fi
						fi
						php56_ini_path="/etc/opt/remi/php56/php.ini"
						if [ -f "$php56_ini_path" ] ; then
							line6=$(grep -n "extension=$extd*"  $php56_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line6" ]
							then
								echo -e "extension=$extd"  >> $php56_ini_path;
							fi
						fi
						php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
						if [ -f "$php56_ini_path1" ] ; then
							line7=$(grep -n "extension=$extd*"  $php56_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line7" ]
							then
								echo -e "extension=$extd"  >> $php56_ini_path1;
							fi
						fi
						php71_ini_path="/etc/opt/remi/php71/php.ini"
						if [ -f "$php71_ini_path" ] ; then
							line8=$(grep -n "extension=$extd*"  $php71_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line8" ]
							then
								echo -e "extension=$extd"  >> $php71_ini_path;
							fi
						fi
						php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
						if [ -f "$php71_ini_path1" ] ; then
							line9=$(grep -n "extension=$extd*"  $php71_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line9" ]
							then
								echo -e "extension=$extd"  >> $php71_ini_path1;
							fi
						fi
						php72_ini_path="/etc/opt/remi/php72/php.ini"
						if [ -f "$php72_ini_path" ] ; then
							line10=$(grep -n "extension=$extd*"  $php72_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line10" ]
							then
								echo -e "extension=$extd"  >> $php72_ini_path;
							fi
						fi
						php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
						if [ -f "$php72_ini_path1" ] ; then
							line11=$(grep -n "extension=$extd*"  $php72_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line11" ]
							then
								echo -e "extension=$extd"  >> $php72_ini_path1;
							fi
						fi
						php73_ini_path="/etc/opt/remi/php73/php.ini"
						if [ -f "$php73_ini_path" ] ; then
							line12=$(grep -n "extension=$extd*"  $php73_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line12" ]
							then
								echo -e "extension=$extd"  >> $php73_ini_path;
							fi
						fi
						php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
						if [ -f "$php73_ini_path1" ] ; then
							line13=$(grep -n "extension=$extd*"  $php73_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line13" ]
							then
								echo -e "extension=$extd"  >> $php73_ini_path1;
							fi
						fi
					fi
					reloadhttpd   $ver_d;
				;;
				dbx)
					yes | pecl install dbx ;
					yes | /opt/remi/php54/root/bin/pecl install dbx ;
					yes | /opt/remi/php55/root/bin/pecl install dbx ;
					yes | /opt/remi/php56/root/bin/pecl install dbx ;
					extd="dbx.so";
                    m_path=$ext_dir$extd;
                    if [ -f  "$m_path" ]
                    then
						chmod  -f -R $perm_d  $m_path;
						line1=$(grep -n "extension=$extd*"  $php_ini_path  | awk '{print $1}' FS=":")
						if [ -z "$line1" ]
						then
							echo -e "extension=$extd"  >> $php_ini_path;
						fi
						php54_ini_path="/etc/opt/remi/php54/php.ini"
						line2=$(grep -n "extension=$extd*"  $php54_ini_path  | awk '{print $1}' FS=":")
						if [ -z "$line2" ]
						then
							echo -e "extension=$extd"  >> $php54_ini_path;
						fi
						php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
						line3=$(grep -n "extension=$extd*"  $php54_ini_path1  | awk '{print $1}' FS=":")
						if [ -z "$line3" ]
						then
							echo -e "extension=$extd"  >> $php54_ini_path1;
						fi
						php55_ini_path="/etc/opt/remi/php55/php.ini"
						line4=$(grep -n "extension=$extd*"  $php55_ini_path  | awk '{print $1}' FS=":")
						if [ -z "$line4" ]
						then
							echo -e "extension=$extd"  >> $php55_ini_path;
						fi
						php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
						line5=$(grep -n "extension=$extd*"  $php55_ini_path1  | awk '{print $1}' FS=":")
						if [ -z "$line5" ]
						then
							echo -e "extension=$extd"  >> $php55_ini_path1;
						fi
						php56_ini_path="/etc/opt/remi/php56/php.ini"
						line6=$(grep -n "extension=$extd*"  $php56_ini_path  | awk '{print $1}' FS=":")
						if [ -z "$line6" ]
						then
							echo -e "extension=$extd"  >> $php56_ini_path;
						fi
						php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
						line7=$(grep -n "extension=$extd*"  $php56_ini_path1  | awk '{print $1}' FS=":")
						if [ -z "$line7" ]
						then
							echo -e "extension=$extd"  >> $php56_ini_path1;
						fi
                    fi
					reloadhttpd   $ver_d;
				;;
				radius)
					#yes | pecl install radius ;
					yum -y install php-pecl-radius
					yum -y install php54-php-pecl-radius php55-php-pecl-radius php56-php-pecl-radius php70-php-pecl-radius php71-php-pecl-radius php72-php-pecl-radius php73-php-pecl-radius
					extd="radius.so";
                    m_path=$ext_dir$extd;
                    if [ -f  "$m_path" ]
                    then
						chmod  -R $perm_d $m_path;
						line1=$(grep -n "extension=$extd*"  $php_ini_path  | awk '{print $1}' FS=":")
						if [ -z "$line1" ]
						then
							echo -e "extension=$extd"  >> $php_ini_path;
						fi
						php54_ini_path="/etc/opt/remi/php54/php.ini";
						if [ -f "$php54_ini_path" ] ; then
							line2=$(grep -n "extension=$extd*"  $php54_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line2" ]
							then
								echo -e "extension=$extd"  >> $php54_ini_path;
							fi
						fi
						php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
						if [ -f "$php54_ini_path1" ] ; then
							line3=$(grep -n "extension=$extd*"  $php54_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line3" ]
							then
								echo -e "extension=$extd"  >> $php54_ini_path1;
							fi
						fi
						php55_ini_path="/etc/opt/remi/php55/php.ini"
						if [ -f "$php55_ini_path" ] ; then
							line4=$(grep -n "extension=$extd*"  $php55_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line4" ]
							then
								echo -e "extension=$extd"  >> $php55_ini_path;
							fi
						fi
						php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
						if [ -f "$php55_ini_path1" ] ; then
							line5=$(grep -n "extension=$extd*"  $php55_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line5" ]
							then
								echo -e "extension=$extd"  >> $php55_ini_path1;
							fi
						fi
						php56_ini_path="/etc/opt/remi/php56/php.ini"
						if [ -f "$php56_ini_path" ] ; then
							line6=$(grep -n "extension=$extd*"  $php56_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line6" ]
							then
								echo -e "extension=$extd"  >> $php56_ini_path;
							fi
						fi
						php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
						if [ -f "$php56_ini_path1" ] ; then
							line7=$(grep -n "extension=$extd*"  $php56_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line7" ]
							then
								echo -e "extension=$extd"  >> $php56_ini_path1;
							fi
						fi
						php71_ini_path="/etc/opt/remi/php71/php.ini"
						if [ -f "$php71_ini_path" ] ; then
							line8=$(grep -n "extension=$extd*"  $php71_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line8" ]
							then
								echo -e "extension=$extd"  >> $php71_ini_path;
							fi
						fi
						php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
						if [ -f "$php71_ini_path1" ] ; then
							line9=$(grep -n "extension=$extd*"  $php71_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line9" ]
							then
								echo -e "extension=$extd"  >> $php71_ini_path1;
							fi
						fi
						php72_ini_path="/etc/opt/remi/php72/php.ini"
						if [ -f "$php72_ini_path" ] ; then
							line10=$(grep -n "extension=$extd*"  $php72_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line10" ]
							then
								echo -e "extension=$extd"  >> $php72_ini_path;
							fi
						fi
						php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
						if [ -f "$php72_ini_path1" ] ; then
							line11=$(grep -n "extension=$extd*"  $php72_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line11" ]
							then
								echo -e "extension=$extd"  >> $php72_ini_path1;
							fi
						fi
						php73_ini_path="/etc/opt/remi/php73/php.ini"
						if [ -f "$php73_ini_path" ] ; then
							line12=$(grep -n "extension=$extd*"  $php73_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line12" ]
							then
								echo -e "extension=$extd"  >> $php73_ini_path;
							fi
						fi
						php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
						if [ -f "$php73_ini_path1" ] ; then
							line13=$(grep -n "extension=$extd*"  $php73_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line13" ]
							then
								echo -e "extension=$extd"  >> $php73_ini_path1;
							fi
						fi
                    fi
					reloadhttpd   $ver_d;
				;;
				rar)
					yum install gcc-c++  -y
					#yes | pecl install Rar ;
					yum -y install php-pecl-rar
					yum -y install php54-php-pecl-rar php55-php-pecl-rar php56-php-pecl-rar php70-php-pecl-rar php71-php-pecl-rar php72-php-pecl-rar php73-php-pecl-rar
					extd="rar.so";
                    m_path=$ext_dir$extd;
                    if [ -f  "$m_path" ]
                    then
						chmod  -R $perm_d $m_path;
						line1=$(grep -n "extension=$extd*"  $php_ini_path  | awk '{print $1}' FS=":")
						if [ -z "$line1" ]
						then
							echo -e "extension=$extd"  >> $php_ini_path;
						fi
						php54_ini_path="/etc/opt/remi/php54/php.ini";
						if [ -f "$php54_ini_path" ] ; then
							line2=$(grep -n "extension=$extd*"  $php54_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line2" ]
							then
								echo -e "extension=$extd"  >> $php54_ini_path;
							fi
						fi
						php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
						if [ -f "$php54_ini_path1" ] ; then
							line3=$(grep -n "extension=$extd*"  $php54_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line3" ]
							then
								echo -e "extension=$extd"  >> $php54_ini_path1;
							fi
						fi
						php55_ini_path="/etc/opt/remi/php55/php.ini"
						if [ -f "$php55_ini_path" ] ; then
							line4=$(grep -n "extension=$extd*"  $php55_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line4" ]
							then
								echo -e "extension=$extd"  >> $php55_ini_path;
							fi
						fi
						php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
						if [ -f "$php55_ini_path1" ] ; then
							line5=$(grep -n "extension=$extd*"  $php55_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line5" ]
							then
								echo -e "extension=$extd"  >> $php55_ini_path1;
							fi
						fi
						php56_ini_path="/etc/opt/remi/php56/php.ini"
						if [ -f "$php56_ini_path" ] ; then
							line6=$(grep -n "extension=$extd*"  $php56_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line6" ]
							then
								echo -e "extension=$extd"  >> $php56_ini_path;
							fi
						fi
						php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
						if [ -f "$php56_ini_path1" ] ; then
							line7=$(grep -n "extension=$extd*"  $php56_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line7" ]
							then
								echo -e "extension=$extd"  >> $php56_ini_path1;
							fi
						fi
						php71_ini_path="/etc/opt/remi/php71/php.ini"
						if [ -f "$php71_ini_path" ] ; then
							line8=$(grep -n "extension=$extd*"  $php71_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line8" ]
							then
								echo -e "extension=$extd"  >> $php71_ini_path;
							fi
						fi
						php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
						if [ -f "$php71_ini_path1" ] ; then
							line9=$(grep -n "extension=$extd*"  $php71_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line9" ]
							then
								echo -e "extension=$extd"  >> $php71_ini_path1;
							fi
						fi
						php72_ini_path="/etc/opt/remi/php72/php.ini"
						if [ -f "$php72_ini_path" ] ; then
							line10=$(grep -n "extension=$extd*"  $php72_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line10" ]
							then
								echo -e "extension=$extd"  >> $php72_ini_path;
							fi
						fi
						php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
						if [ -f "$php72_ini_path1" ] ; then
							line11=$(grep -n "extension=$extd*"  $php72_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line11" ]
							then
								echo -e "extension=$extd"  >> $php72_ini_path1;
							fi
						fi
						php73_ini_path="/etc/opt/remi/php73/php.ini"
						if [ -f "$php73_ini_path" ] ; then
							line12=$(grep -n "extension=$extd*"  $php73_ini_path | awk '{print $1}' FS=":")
							if [ -z "$line12" ]
							then
								echo -e "extension=$extd"  >> $php73_ini_path;
							fi
						fi
						php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
						if [ -f "$php73_ini_path1" ] ; then
							line13=$(grep -n "extension=$extd*"  $php73_ini_path1 | awk '{print $1}' FS=":")
							if [ -z "$line13" ]
							then
								echo -e "extension=$extd"  >> $php73_ini_path1;
							fi
						fi
                    fi
                    reloadhttpd   $ver_d;
				;;
				runkit)

					    #yes | pecl install runkit ;
					    yum -y install php-pecl-runkit
					    yum -y install php54-php-pecl-runkit php55-php-pecl-runkit php56-php-pecl-runkit php71-php-pecl-runkit7 php72-php-pecl-runkit7 php73-php-pecl-runkit7
					    extd="runkit.so";
                        m_path=$ext_dir$extd;
                        if [ -f  "$m_path" ]
                        then
							chmod  -R $perm_d $m_path;
							line1=$(grep -n "extension=$extd*"  $php_ini_path  | awk '{print $1}' FS=":")
							if [ -z "$line1" ]
							then
								echo -e "extension=$extd"  >> $php_ini_path;
							fi
							php54_ini_path="/etc/opt/remi/php54/php.ini";
							if [ -f "$php54_ini_path" ] ; then
								line2=$(grep -n "extension=$extd*"  $php54_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line2" ]
								then
									echo -e "extension=$extd"  >> $php54_ini_path;
								fi
							fi
							php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
							if [ -f "$php54_ini_path1" ] ; then
								line3=$(grep -n "extension=$extd*"  $php54_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line3" ]
								then
									echo -e "extension=$extd"  >> $php54_ini_path1;
								fi
							fi
							php55_ini_path="/etc/opt/remi/php55/php.ini"
							if [ -f "$php55_ini_path" ] ; then
								line4=$(grep -n "extension=$extd*"  $php55_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line4" ]
								then
									echo -e "extension=$extd"  >> $php55_ini_path;
								fi
							fi
							php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
							if [ -f "$php55_ini_path1" ] ; then
								line5=$(grep -n "extension=$extd*"  $php55_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line5" ]
								then
									echo -e "extension=$extd"  >> $php55_ini_path1;
								fi
							fi
							php56_ini_path="/etc/opt/remi/php56/php.ini"
							if [ -f "$php56_ini_path" ] ; then
								line6=$(grep -n "extension=$extd*"  $php56_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line6" ]
								then
									echo -e "extension=$extd"  >> $php56_ini_path;
								fi
							fi
							php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
							if [ -f "$php56_ini_path1" ] ; then
								line7=$(grep -n "extension=$extd*"  $php56_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line7" ]
								then
									echo -e "extension=$extd"  >> $php56_ini_path1;
								fi
							fi
							php71_ini_path="/etc/opt/remi/php71/php.ini"
							if [ -f "$php71_ini_path" ] ; then
								line8=$(grep -n "extension=$extd*"  $php71_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line8" ]
								then
									echo -e "extension=$extd"  >> $php71_ini_path;
								fi
							fi
							php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
							if [ -f "$php71_ini_path1" ] ; then
								line9=$(grep -n "extension=$extd*"  $php71_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line9" ]
								then
									echo -e "extension=$extd"  >> $php71_ini_path1;
								fi
							fi
							php72_ini_path="/etc/opt/remi/php72/php.ini"
							if [ -f "$php72_ini_path" ] ; then
								line10=$(grep -n "extension=$extd*"  $php72_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line10" ]
								then
									echo -e "extension=$extd"  >> $php72_ini_path;
								fi
							fi
							php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
							if [ -f "$php72_ini_path1" ] ; then
								line11=$(grep -n "extension=$extd*"  $php72_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line11" ]
								then
									echo -e "extension=$extd"  >> $php72_ini_path1;
								fi
							fi
							php73_ini_path="/etc/opt/remi/php73/php.ini"
							if [ -f "$php73_ini_path" ] ; then
								line12=$(grep -n "extension=$extd*"  $php73_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line12" ]
								then
									echo -e "extension=$extd"  >> $php73_ini_path;
								fi
							fi
							php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
							if [ -f "$php73_ini_path1" ] ; then
								line13=$(grep -n "extension=$extd*"  $php73_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line13" ]
								then
									echo -e "extension=$extd"  >> $php73_ini_path1;
								fi
							fi
                        fi
                        reloadhttpd   $ver_d;
				;;
				geoip)
					#sudo rpm -Uvh http://dl.fedoraproject.org/pub/epel/7/x86_64/Packages/r/re2c-0.14.3-2.el7.x86_64.rpm
					sudo rpm -Uvh http://hostingraja.info/Version2.0/re2c-0.14.3-2.el7.x86_64.rpm
                    			yum  -y install re2c
					yum  -y install geoip-devel
					#yes | pecl install geoip ;
					yum -y install php-pecl-geoip
					extd="geoip.so";
                    m_path=$ext_dir$extd;
                    if [ -f  "$m_path" ]
                    then
	                chmod  -R $perm_d $m_path;
	                line1=$(grep -n "extension=$extd*"  $php_ini_path  | awk '{print $1}' FS=":")
						if [ -z "$line1" ]
						then
							echo -e "extension=$extd"  >> $php_ini_path;
						fi
						php54_ini_path="/etc/opt/remi/php54/php.ini";
							if [ -f "$php54_ini_path" ] ; then
								line2=$(grep -n "extension=$extd*"  $php54_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line2" ]
								then
									echo -e "extension=$extd"  >> $php54_ini_path;
								fi
							fi
							php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
							if [ -f "$php54_ini_path1" ] ; then
								line3=$(grep -n "extension=$extd*"  $php54_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line3" ]
								then
									echo -e "extension=$extd"  >> $php54_ini_path1;
								fi
							fi
							php55_ini_path="/etc/opt/remi/php55/php.ini"
							if [ -f "$php55_ini_path" ] ; then
								line4=$(grep -n "extension=$extd*"  $php55_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line4" ]
								then
									echo -e "extension=$extd"  >> $php55_ini_path;
								fi
							fi
							php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
							if [ -f "$php55_ini_path1" ] ; then
								line5=$(grep -n "extension=$extd*"  $php55_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line5" ]
								then
									echo -e "extension=$extd"  >> $php55_ini_path1;
								fi
							fi
							php56_ini_path="/etc/opt/remi/php56/php.ini"
							if [ -f "$php56_ini_path" ] ; then
								line6=$(grep -n "extension=$extd*"  $php56_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line6" ]
								then
									echo -e "extension=$extd"  >> $php56_ini_path;
								fi
							fi
							php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
							if [ -f "$php56_ini_path1" ] ; then
								line7=$(grep -n "extension=$extd*"  $php56_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line7" ]
								then
									echo -e "extension=$extd"  >> $php56_ini_path1;
								fi
							fi
							php71_ini_path="/etc/opt/remi/php71/php.ini"
							if [ -f "$php71_ini_path" ] ; then
								line8=$(grep -n "extension=$extd*"  $php71_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line8" ]
								then
									echo -e "extension=$extd"  >> $php71_ini_path;
								fi
							fi
							php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
							if [ -f "$php71_ini_path1" ] ; then
								line9=$(grep -n "extension=$extd*"  $php71_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line9" ]
								then
									echo -e "extension=$extd"  >> $php71_ini_path1;
								fi
							fi
							php72_ini_path="/etc/opt/remi/php72/php.ini"
							if [ -f "$php72_ini_path" ] ; then
								line10=$(grep -n "extension=$extd*"  $php72_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line10" ]
								then
									echo -e "extension=$extd"  >> $php72_ini_path;
								fi
							fi
							php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
							if [ -f "$php72_ini_path1" ] ; then
								line11=$(grep -n "extension=$extd*"  $php72_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line11" ]
								then
									echo -e "extension=$extd"  >> $php72_ini_path1;
								fi
							fi
							php73_ini_path="/etc/opt/remi/php73/php.ini"
							if [ -f "$php73_ini_path" ] ; then
								line12=$(grep -n "extension=$extd*"  $php73_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line12" ]
								then
									echo -e "extension=$extd"  >> $php73_ini_path;
								fi
							fi
							php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
							if [ -f "$php73_ini_path1" ] ; then
								line13=$(grep -n "extension=$extd*"  $php73_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line13" ]
								then
									echo -e "extension=$extd"  >> $php73_ini_path1;
								fi
							fi
                    fi
					reloadhttpd $ver_d;	 			
				;;
				gnupg)
					sudo rpm -Uvh http://hostingraja.info/Version2.0/re2c-0.14.3-2.el7.x86_64.rpm
					yum  -y install re2c
					yum  -y install gpgme-devel	
					#yes | pecl install gnupg ;
					yum -y install php-pecl-gnupg
					yum -y install php54-php-pecl-gnupg php55-php-pecl-gnupg php56-php-pecl-gnupg php70-php-pecl-gnupg php71-php-pecl-gnupg php72-php-pecl-gnupg php73-php-pecl-gnupg
                    extd="gnupg.so";
                    m_path=$ext_dir$extd;
                    if [ -f  "$m_path" ]
                    then
                    chmod  -R $perm_d $m_path;
                            line1=$(grep -n "extension=$extd*"  $php_ini_path  | awk '{print $1}' FS=":")
                            if [ -z "$line1" ]
                            then
                                    echo -e "extension=$extd"  >> $php_ini_path;
                            fi
							php54_ini_path="/etc/opt/remi/php54/php.ini";
							if [ -f "$php54_ini_path" ] ; then
								line2=$(grep -n "extension=$extd*"  $php54_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line2" ]
								then
									echo -e "extension=$extd"  >> $php54_ini_path;
								fi
							fi
							php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
							if [ -f "$php54_ini_path1" ] ; then
								line3=$(grep -n "extension=$extd*"  $php54_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line3" ]
								then
									echo -e "extension=$extd"  >> $php54_ini_path1;
								fi
							fi
							php55_ini_path="/etc/opt/remi/php55/php.ini"
							if [ -f "$php55_ini_path" ] ; then
								line4=$(grep -n "extension=$extd*"  $php55_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line4" ]
								then
									echo -e "extension=$extd"  >> $php55_ini_path;
								fi
							fi
							php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
							if [ -f "$php55_ini_path1" ] ; then
								line5=$(grep -n "extension=$extd*"  $php55_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line5" ]
								then
									echo -e "extension=$extd"  >> $php55_ini_path1;
								fi
							fi
							php56_ini_path="/etc/opt/remi/php56/php.ini"
							if [ -f "$php56_ini_path" ] ; then
								line6=$(grep -n "extension=$extd*"  $php56_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line6" ]
								then
									echo -e "extension=$extd"  >> $php56_ini_path;
								fi
							fi
							php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
							if [ -f "$php56_ini_path1" ] ; then
								line7=$(grep -n "extension=$extd*"  $php56_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line7" ]
								then
									echo -e "extension=$extd"  >> $php56_ini_path1;
								fi
							fi
							php71_ini_path="/etc/opt/remi/php71/php.ini"
							if [ -f "$php71_ini_path" ] ; then
								line8=$(grep -n "extension=$extd*"  $php71_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line8" ]
								then
									echo -e "extension=$extd"  >> $php71_ini_path;
								fi
							fi
							php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
							if [ -f "$php71_ini_path1" ] ; then
								line9=$(grep -n "extension=$extd*"  $php71_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line9" ]
								then
									echo -e "extension=$extd"  >> $php71_ini_path1;
								fi
							fi
							php72_ini_path="/etc/opt/remi/php72/php.ini"
							if [ -f "$php72_ini_path" ] ; then
								line10=$(grep -n "extension=$extd*"  $php72_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line10" ]
								then
									echo -e "extension=$extd"  >> $php72_ini_path;
								fi
							fi
							php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
							if [ -f "$php72_ini_path1" ] ; then
								line11=$(grep -n "extension=$extd*"  $php72_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line11" ]
								then
									echo -e "extension=$extd"  >> $php72_ini_path1;
								fi
							fi
							php73_ini_path="/etc/opt/remi/php73/php.ini"
							if [ -f "$php73_ini_path" ] ; then
								line12=$(grep -n "extension=$extd*"  $php73_ini_path | awk '{print $1}' FS=":")
								if [ -z "$line12" ]
								then
									echo -e "extension=$extd"  >> $php73_ini_path;
								fi
							fi
							php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
							if [ -f "$php73_ini_path1" ] ; then
								line13=$(grep -n "extension=$extd*"  $php73_ini_path1 | awk '{print $1}' FS=":")
								if [ -z "$line13" ]
								then
									echo -e "extension=$extd"  >> $php73_ini_path1;
								fi
							fi
                    fi
                    reloadhttpd  $ver_d;
				;;
				
				imagick)
					yum install gcc php-devel php-pear  -y
					yum install ImageMagick ImageMagick-devel -y
					#yes  | pecl install imagick;
					yum -y install php-pecl-imagick
					yum -y install php54-php-pecl-imagick php54-php-pecl-imagick-devel php55-php-pecl-imagick php55-php-pecl-imagick-devel php56-php-pecl-imagick php56-php-pecl-imagick-devel php70-php-pecl-imagick php70-php-pecl-imagick-devel php71-php-pecl-imagick php71-php-pecl-imagick-devel php72-php-pecl-imagick php72-php-pecl-imagick-devel php73-php-pecl-imagick php73-php-pecl-imagick-devel
					extd="imagick.so"
					m_path=$ext_dir$extd;
					img_path="/etc/php.d/imagick.ini";					
                    if [ -f  "$m_path" ]
                    then
						chmod  -R $perm_d $m_path;
						line1=$(grep -n "extension=$extd*"  $img_path  | awk '{print $1}' FS=":")
						if [ -z "$line1" ]
						then
							echo -e "extension=$extd"  >> $img_path;
						fi
                    else        
						echo -e "extension=$extd"  >> $img_path;       
						chmod  -R $perm_d $m_path;   
                    fi
					php54_ini_path="/etc/opt/remi/php54/php.ini";
					if [ -f "$php54_ini_path" ] ; then
						line2=$(grep -n "extension=$extd*"  $php54_ini_path | awk '{print $1}' FS=":")
						if [ -z "$line2" ]
						then
							echo -e "extension=$extd"  >> $php54_ini_path;
						fi
					fi
					php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
					if [ -f "$php54_ini_path1" ] ; then
						line3=$(grep -n "extension=$extd*"  $php54_ini_path1 | awk '{print $1}' FS=":")
						if [ -z "$line3" ]
						then
							echo -e "extension=$extd"  >> $php54_ini_path1;
						fi
					fi
					php55_ini_path="/etc/opt/remi/php55/php.ini"
					if [ -f "$php55_ini_path" ] ; then
						line4=$(grep -n "extension=$extd*"  $php55_ini_path | awk '{print $1}' FS=":")
						if [ -z "$line4" ]
						then
							echo -e "extension=$extd"  >> $php55_ini_path;
						fi
					fi
					php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
					if [ -f "$php55_ini_path1" ] ; then
						line5=$(grep -n "extension=$extd*"  $php55_ini_path1 | awk '{print $1}' FS=":")
						if [ -z "$line5" ]
						then
							echo -e "extension=$extd"  >> $php55_ini_path1;
						fi
					fi
					php56_ini_path="/etc/opt/remi/php56/php.ini"
					if [ -f "$php56_ini_path" ] ; then
						line6=$(grep -n "extension=$extd*"  $php56_ini_path | awk '{print $1}' FS=":")
						if [ -z "$line6" ]
						then
							echo -e "extension=$extd"  >> $php56_ini_path;
						fi
					fi
					php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
					if [ -f "$php56_ini_path1" ] ; then
						line7=$(grep -n "extension=$extd*"  $php56_ini_path1 | awk '{print $1}' FS=":")
						if [ -z "$line7" ]
						then
							echo -e "extension=$extd"  >> $php56_ini_path1;
						fi
					fi
					php71_ini_path="/etc/opt/remi/php71/php.ini"
					if [ -f "$php71_ini_path" ] ; then
						line8=$(grep -n "extension=$extd*"  $php71_ini_path | awk '{print $1}' FS=":")
						if [ -z "$line8" ]
						then
							echo -e "extension=$extd"  >> $php71_ini_path;
						fi
					fi
					php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
					if [ -f "$php71_ini_path1" ] ; then
						line9=$(grep -n "extension=$extd*"  $php71_ini_path1 | awk '{print $1}' FS=":")
						if [ -z "$line9" ]
						then
							echo -e "extension=$extd"  >> $php71_ini_path1;
						fi
					fi
					php72_ini_path="/etc/opt/remi/php72/php.ini"
					if [ -f "$php72_ini_path" ] ; then
						line10=$(grep -n "extension=$extd*"  $php72_ini_path | awk '{print $1}' FS=":")
						if [ -z "$line10" ]
						then
							echo -e "extension=$extd"  >> $php72_ini_path;
						fi
					fi
					php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
					if [ -f "$php72_ini_path1" ] ; then
						line11=$(grep -n "extension=$extd*"  $php72_ini_path1 | awk '{print $1}' FS=":")
						if [ -z "$line11" ]
						then
							echo -e "extension=$extd"  >> $php72_ini_path1;
						fi
					fi
					php73_ini_path="/etc/opt/remi/php73/php.ini"
					if [ -f "$php73_ini_path" ] ; then
						line12=$(grep -n "extension=$extd*"  $php73_ini_path | awk '{print $1}' FS=":")
						if [ -z "$line12" ]
						then
							echo -e "extension=$extd"  >> $php73_ini_path;
						fi
					fi
					php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
					if [ -f "$php73_ini_path1" ] ; then
						line13=$(grep -n "extension=$extd*"  $php73_ini_path1 | awk '{print $1}' FS=":")
						if [ -z "$line13" ]
						then
							echo -e "extension=$extd"  >> $php73_ini_path1;
						fi
					fi
					reloadhttpd  $ver_d;					
				;;
				
				ffmpeg)

					sudo yum install epel-release -y
					sudo yum update -y
					if [ $ver_d == 7 ]
					then 				
						sudo rpm --import http://hostingraja.info/Version2.0/RPM-GPG-KEY-nux.ro
						sudo rpm -Uvh http://hostingraja.info/Version2.0/nux-dextop-release-0-5.el7.nux.noarch.rpm
					else
						sudo rpm --import http://hostingraja.info/Version2.0/RPM-GPG-KEY-nux.ro
						sudo rpm -Uvh http://hostingraja.info/Version2.0/nux-dextop-release-0-2.el6.nux.noarch.rpm
					fi
					sudo yum install ffmpeg ffmpeg-devel -y				
					yum -y install git
					r=$(( $RANDOM  ));
					n_file_detail="/root/scripts$r/";
					mkdir -p $n_file_detail
					removesofile $n_file_detail "ffmpeg.so" $php_path;
					cd $n_file_detail	
					#git clone https://github.com/tony2001/ffmpeg-php.git
					wget http://hostingraja.info/Version2.0/ffmpeg-php.zip
					unzip ffmpeg-php.zip
					cd ffmpeg-php
					phpize
					./configure
					make
					make install
					ext_d="ffmpeg.so"
                    			m_path=$ext_dir$ext_d;
					img_path="/etc/php.d/ffmpeg.ini"	
					echo -e "extension=$ext_d"  >> $img_path;
					chmod  -R $perm_d $m_path;
					rm -rf $n_file_detail			
					reloadhttpd  $ver_d;
				;;
			esac
		;;
		
  		uninstall)
			case $pack in
                        memcache)
				#pecl uninstall memcache >/dev/null;
				yum -y remove php-pecl-memcache
				line1=$(grep -n "extension=memcache.so*"  $php_ini_path  | awk '{print $1}' FS=":")
				if [ -z "$line1" ]
				then
					echo " " >/dev/null;
			        else
				       sed -i "${line1}d"  $php_ini_path
		                fi
				php54_ini_path="/etc/opt/remi/php54/php.ini"
				line11=$(grep -n "extension=gender.so*"  $php54_ini_path  | awk '{print $1}' FS=":")
				if [ -z "$line11" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line11}d"  $php54_ini_path
				fi
				php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
				line12=$(grep -n "extension=gender.so*"  $php54_ini_path1  | awk '{print $1}' FS=":")
				if [ -z "$line12" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line12}d"  $php54_ini_path1
				fi
				php55_ini_path="/etc/opt/remi/php55/php.ini"
				line1=$(grep -n "extension=gender.so*"  $php55_ini_path  | awk '{print $1}' FS=":")
				if [ -z "$line1" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line1}d"  $php55_ini_path
				fi
				php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
				line2=$(grep -n "extension=gender.so*"  $php55_ini_path1  | awk '{print $1}' FS=":")
				if [ -z "$line2" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line2}d"  $php55_ini_path1
				fi
				php56_ini_path="/etc/opt/remi/php56/php.ini"
				line3=$(grep -n "extension=gender.so*"  $php56_ini_path  | awk '{print $1}' FS=":")
				if [ -z "$line3" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line3}d"  $php56_ini_path
				fi
				php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
				line4=$(grep -n "extension=gender.so*"  $php56_ini_path1  | awk '{print $1}' FS=":")
				if [ -z "$line4" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line4}d"  $php56_ini_path1
				fi
				php71_ini_path="/etc/opt/remi/php71/php.ini"
				line5=$(grep -n "extension=gender.so*"  $php71_ini_path  | awk '{print $1}' FS=":")
				if [ -z "$line5" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line5}d"  $php71_ini_path
				fi
				php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
				line6=$(grep -n "extension=gender.so*"  $php71_ini_path1  | awk '{print $1}' FS=":")
				if [ -z "$line6" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line6}d"  $php71_ini_path1
				fi
				php72_ini_path="/etc/opt/remi/php72/php.ini"
				line7=$(grep -n "extension=gender.so*"  $php72_ini_path  | awk '{print $1}' FS=":")
				if [ -z "$line7" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line7}d"  $php72_ini_path
				fi
					php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
				line8=$(grep -n "extension=gender.so*"  $php72_ini_path1  | awk '{print $1}' FS=":")
				if [ -z "$line8" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line8}d"  $php72_ini_path1
				fi
					php73_ini_path="/etc/opt/remi/php73/php.ini"
					line9=$(grep -n "extension=gender.so*"  $php73_ini_path  | awk '{print $1}' FS=":")
				if [ -z "$line9" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line9}d"  $php73_ini_path
				fi
					php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
					line10=$(grep -n "extension=gender.so*"  $php73_ini_path1  | awk '{print $1}' FS=":")
				if [ -z "$line10" ]
				then
					echo " " >/dev/null;
				else
					sed -i "${line10}d"  $php73_ini_path1
				fi
		                reloadhttpd  $ver_d;
                        ;;
                        gender)
				                pecl uninstall  gender >/dev/null;
                                line1=$(grep -n "extension=gender.so*"  $php_ini_path  | awk '{print $1}' FS=":")
                                if [ -z "$line1" ]
                                then
                                    echo " " >/dev/null;
                                else
                                    sed -i "${line1}d"  $php_ini_path
                                fi
								php54_ini_path="/etc/opt/remi/php54/php.ini"
								line11=$(grep -n "extension=gender.so*"  $php54_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line11" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line11}d"  $php54_ini_path
								fi
								php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
								line12=$(grep -n "extension=gender.so*"  $php54_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line12" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line12}d"  $php54_ini_path1
								fi
								php55_ini_path="/etc/opt/remi/php55/php.ini"
								line1=$(grep -n "extension=gender.so*"  $php55_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line1" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line1}d"  $php55_ini_path
								fi
								php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
								line2=$(grep -n "extension=gender.so*"  $php55_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line2" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line2}d"  $php55_ini_path1
								fi
								php56_ini_path="/etc/opt/remi/php56/php.ini"
								line3=$(grep -n "extension=gender.so*"  $php56_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line3" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line3}d"  $php56_ini_path
								fi
								php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
								line4=$(grep -n "extension=gender.so*"  $php56_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line4" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line4}d"  $php56_ini_path1
								fi
								php71_ini_path="/etc/opt/remi/php71/php.ini"
								line5=$(grep -n "extension=gender.so*"  $php71_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line5" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line5}d"  $php71_ini_path
								fi
								php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
								line6=$(grep -n "extension=gender.so*"  $php71_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line6" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line6}d"  $php71_ini_path1
								fi
								php72_ini_path="/etc/opt/remi/php72/php.ini"
								line7=$(grep -n "extension=gender.so*"  $php72_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line7" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line7}d"  $php72_ini_path
								fi
								php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
								line8=$(grep -n "extension=gender.so*"  $php72_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line8" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line8}d"  $php72_ini_path1
								fi
								php73_ini_path="/etc/opt/remi/php73/php.ini"
								line9=$(grep -n "extension=gender.so*"  $php73_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line9" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line9}d"  $php73_ini_path
								fi
								php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
								line10=$(grep -n "extension=gender.so*"  $php73_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line10" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line10}d"  $php73_ini_path1
								fi
                                reloadhttpd  $ver_d;
                        ;;
                        dbx)
				                pecl uninstall dbx >/dev/null;
                                line1=$(grep -n "extension=dbx.so*"  $php_ini_path  | awk '{print $1}' FS=":")
                                if [ -z "$line1" ]
                                then
                                    echo " " >/dev/null;
                                else
                                    sed -i "${line1}d"  $php_ini_path
                                fi
								php54_ini_path="/etc/opt/remi/php54/php.ini"
								line11=$(grep -n "extension=dbx.so*"  $php54_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line11" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line11}d"  $php54_ini_path
								fi
								php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
								line12=$(grep -n "extension=dbx.so*"  $php54_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line12" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line12}d"  $php54_ini_path1
								fi
								php55_ini_path="/etc/opt/remi/php55/php.ini"
								line1=$(grep -n "extension=dbx.so*"  $php55_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line1" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line1}d"  $php55_ini_path
								fi
								php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
								line2=$(grep -n "extension=dbx.so*"  $php55_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line2" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line2}d"  $php55_ini_path1
								fi
								php56_ini_path="/etc/opt/remi/php56/php.ini"
								line3=$(grep -n "extension=dbx.so*"  $php56_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line3" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line3}d"  $php56_ini_path
								fi
								php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
								line4=$(grep -n "extension=dbx.so*"  $php56_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line4" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line4}d"  $php56_ini_path1
								fi
								php71_ini_path="/etc/opt/remi/php71/php.ini"
								line5=$(grep -n "extension=dbx.so*"  $php71_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line5" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line5}d"  $php71_ini_path
								fi
								php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
								line6=$(grep -n "extension=dbx.so*"  $php71_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line6" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line6}d"  $php71_ini_path1
								fi
								php72_ini_path="/etc/opt/remi/php72/php.ini"
								line7=$(grep -n "extension=dbx.so*"  $php72_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line7" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line7}d"  $php72_ini_path
								fi
								php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
								line8=$(grep -n "extension=dbx.so*"  $php72_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line8" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line8}d"  $php72_ini_path1
								fi
								php73_ini_path="/etc/opt/remi/php73/php.ini"
								line9=$(grep -n "extension=dbx.so*"  $php73_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line9" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line9}d"  $php73_ini_path
								fi
								php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
								line10=$(grep -n "extension=dbx.so*"  $php73_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line10" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line10}d"  $php73_ini_path1
								fi
                                reloadhttpd  $ver_d;
                        ;;
                        radius)
				                pecl uninstall  radius >/dev/null;
                                line1=$(grep -n "extension=radius.so*"  $php_ini_path  | awk '{print $1}' FS=":")
                                if [ -z "$line1" ]
                                then
                                    echo " " >/dev/null;
                                else
                                    sed -i "${line1}d"  $php_ini_path
                                fi
								php54_ini_path="/etc/opt/remi/php54/php.ini"
								line11=$(grep -n "extension=radius.so*"  $php54_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line11" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line11}d"  $php54_ini_path
								fi
								php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
								line12=$(grep -n "extension=radius.so*"  $php54_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line12" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line12}d"  $php54_ini_path1
								fi
								php55_ini_path="/etc/opt/remi/php55/php.ini"
								line1=$(grep -n "extension=radius.so*"  $php55_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line1" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line1}d"  $php55_ini_path
								fi
								php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
								line2=$(grep -n "extension=radius.so*"  $php55_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line2" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line2}d"  $php55_ini_path1
								fi
								php56_ini_path="/etc/opt/remi/php56/php.ini"
								line3=$(grep -n "extension=radius.so*"  $php56_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line3" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line3}d"  $php56_ini_path
								fi
								php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
								line4=$(grep -n "extension=radius.so*"  $php56_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line4" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line4}d"  $php56_ini_path1
								fi
								php71_ini_path="/etc/opt/remi/php71/php.ini"
								line5=$(grep -n "extension=radius.so*"  $php71_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line5" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line5}d"  $php71_ini_path
								fi
								php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
								line6=$(grep -n "extension=radius.so*"  $php71_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line6" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line6}d"  $php71_ini_path1
								fi
								php72_ini_path="/etc/opt/remi/php72/php.ini"
								line7=$(grep -n "extension=radius.so*"  $php72_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line7" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line7}d"  $php72_ini_path
								fi
								php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
								line8=$(grep -n "extension=radius.so*"  $php72_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line8" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line8}d"  $php72_ini_path1
								fi
								php73_ini_path="/etc/opt/remi/php73/php.ini"
								line9=$(grep -n "extension=radius.so*"  $php73_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line9" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line9}d"  $php73_ini_path
								fi
								php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
								line10=$(grep -n "extension=radius.so*"  $php73_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line10" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line10}d"  $php73_ini_path1
								fi
                                reloadhttpd  $ver_d;
                        ;;
                        rar)
				                pecl uninstall  rar >/dev/null;
                                line1=$(grep -n "extension=rar.so*"  $php_ini_path  | awk '{print $1}' FS=":")
                                if [ -z "$line1" ]
                                then
                                    echo " " >/dev/null;
                                else
                                    sed -i "${line1}d"  $php_ini_path
                                fi
								php54_ini_path="/etc/opt/remi/php54/php.ini"
								line11=$(grep -n "extension=rar.so*"  $php54_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line11" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line11}d"  $php54_ini_path
								fi
								php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
								line12=$(grep -n "extension=rar.so*"  $php54_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line12" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line12}d"  $php54_ini_path1
								fi
								php55_ini_path="/etc/opt/remi/php55/php.ini"
								line1=$(grep -n "extension=rar.so*"  $php55_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line1" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line1}d"  $php55_ini_path
								fi
								php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
								line2=$(grep -n "extension=rar.so*"  $php55_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line2" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line2}d"  $php55_ini_path1
								fi
								php56_ini_path="/etc/opt/remi/php56/php.ini"
								line3=$(grep -n "extension=rar.so*"  $php56_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line3" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line3}d"  $php56_ini_path
								fi
								php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
								line4=$(grep -n "extension=rar.so*"  $php56_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line4" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line4}d"  $php56_ini_path1
								fi
								php71_ini_path="/etc/opt/remi/php71/php.ini"
								line5=$(grep -n "extension=rar.so*"  $php71_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line5" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line5}d"  $php71_ini_path
								fi
								php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
								line6=$(grep -n "extension=rar.so*"  $php71_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line6" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line6}d"  $php71_ini_path1
								fi
								php72_ini_path="/etc/opt/remi/php72/php.ini"
								line7=$(grep -n "extension=rar.so*"  $php72_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line7" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line7}d"  $php72_ini_path
								fi
								php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
								line8=$(grep -n "extension=rar.so*"  $php72_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line8" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line8}d"  $php72_ini_path1
								fi
								php73_ini_path="/etc/opt/remi/php73/php.ini"
								line9=$(grep -n "extension=rar.so*"  $php73_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line9" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line9}d"  $php73_ini_path
								fi
								php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
								line10=$(grep -n "extension=rar.so*"  $php73_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line10" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line10}d"  $php73_ini_path1
								fi
                                reloadhttpd  $ver_d;
                        ;;
                        runkit)
				                pecl uninstall  runkit >/dev/null;
                                line1=$(grep -n "extension=runkit.so*"  $php_ini_path  | awk '{print $1}' FS=":")
                                if [ -z "$line1" ]
                                then
                                    echo " " >/dev/null;
                                else
                                    sed -i "${line1}d"  $php_ini_path
                                fi
								php54_ini_path="/etc/opt/remi/php54/php.ini"
								line11=$(grep -n "extension=runkit.so*"  $php54_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line11" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line11}d"  $php54_ini_path
								fi
								php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
								line12=$(grep -n "extension=runkit.so*"  $php54_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line12" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line12}d"  $php54_ini_path1
								fi
								php55_ini_path="/etc/opt/remi/php55/php.ini"
								line1=$(grep -n "extension=runkit.so*"  $php55_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line1" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line1}d"  $php55_ini_path
								fi
								php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
								line2=$(grep -n "extension=runkit.so*"  $php55_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line2" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line2}d"  $php55_ini_path1
								fi
								php56_ini_path="/etc/opt/remi/php56/php.ini"
								line3=$(grep -n "extension=runkit.so*"  $php56_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line3" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line3}d"  $php56_ini_path
								fi
								php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
								line4=$(grep -n "extension=runkit.so*"  $php56_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line4" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line4}d"  $php56_ini_path1
								fi
								php71_ini_path="/etc/opt/remi/php71/php.ini"
								line5=$(grep -n "extension=runkit.so*"  $php71_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line5" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line5}d"  $php71_ini_path
								fi
								php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
								line6=$(grep -n "extension=runkit.so*"  $php71_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line6" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line6}d"  $php71_ini_path1
								fi
								php72_ini_path="/etc/opt/remi/php72/php.ini"
								line7=$(grep -n "extension=runkit.so*"  $php72_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line7" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line7}d"  $php72_ini_path
								fi
								php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
								line8=$(grep -n "extension=runkit.so*"  $php72_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line8" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line8}d"  $php72_ini_path1
								fi
								php73_ini_path="/etc/opt/remi/php73/php.ini"
								line9=$(grep -n "extension=runkit.so*"  $php73_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line9" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line9}d"  $php73_ini_path
								fi
								php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
								line10=$(grep -n "extension=runkit.so*"  $php73_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line10" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line10}d"  $php73_ini_path1
								fi
                                reloadhttpd  $ver_d;
                        ;;
                        geoip)
				                pecl uninstall  geoip >/dev/null;
                                line1=$(grep -n "extension=geoip.so*"  $php_ini_path  | awk '{print $1}' FS=":")
                                if [ -z "$line1" ]
                                then
                                    echo " " >/dev/null;
                                else
                                    sed -i "${line1}d"  $php_ini_path
                                fi
								php54_ini_path="/etc/opt/remi/php54/php.ini"
								line11=$(grep -n "extension=geoip.so*"  $php54_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line11" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line11}d"  $php54_ini_path
								fi
								php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
								line12=$(grep -n "extension=geoip.so*"  $php54_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line12" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line12}d"  $php54_ini_path1
								fi
								php55_ini_path="/etc/opt/remi/php55/php.ini"
								line1=$(grep -n "extension=geoip.so*"  $php55_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line1" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line1}d"  $php55_ini_path
								fi
								php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
								line2=$(grep -n "extension=geoip.so*"  $php55_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line2" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line2}d"  $php55_ini_path1
								fi
								php56_ini_path="/etc/opt/remi/php56/php.ini"
								line3=$(grep -n "extension=geoip.so*"  $php56_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line3" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line3}d"  $php56_ini_path
								fi
								php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
								line4=$(grep -n "extension=geoip.so*"  $php56_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line4" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line4}d"  $php56_ini_path1
								fi
								php71_ini_path="/etc/opt/remi/php71/php.ini"
								line5=$(grep -n "extension=geoip.so*"  $php71_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line5" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line5}d"  $php71_ini_path
								fi
								php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
								line6=$(grep -n "extension=geoip.so*"  $php71_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line6" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line6}d"  $php71_ini_path1
								fi
								php72_ini_path="/etc/opt/remi/php72/php.ini"
								line7=$(grep -n "extension=geoip.so*"  $php72_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line7" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line7}d"  $php72_ini_path
								fi
								php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
								line8=$(grep -n "extension=geoip.so*"  $php72_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line8" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line8}d"  $php72_ini_path1
								fi
								php73_ini_path="/etc/opt/remi/php73/php.ini"
								line9=$(grep -n "extension=geoip.so*"  $php73_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line9" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line9}d"  $php73_ini_path
								fi
								php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
								line10=$(grep -n "extension=geoip.so*"  $php73_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line10" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line10}d"  $php73_ini_path1
								fi
                                reloadhttpd  $ver_d;
                        ;;
                        gnupg)
				                pecl uninstall  gnupg >/dev/null;
                                line1=$(grep -n "extension=gnupg.so*"  $php_ini_path  | awk '{print $1}' FS=":")
                                if [ -z "$line1" ]
                                then
                                    echo " " >/dev/null;
                                else
                                    sed -i "${line1}d"  $php_ini_path
                                fi
								php54_ini_path="/etc/opt/remi/php54/php.ini"
								line11=$(grep -n "extension=gnupg.so*"  $php54_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line11" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line11}d"  $php54_ini_path
								fi
								php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
								line12=$(grep -n "extension=gnupg.so*"  $php54_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line12" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line12}d"  $php54_ini_path1
								fi
								php55_ini_path="/etc/opt/remi/php55/php.ini"
								line1=$(grep -n "extension=gnupg.so*"  $php55_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line1" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line1}d"  $php55_ini_path
								fi
								php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
								line2=$(grep -n "extension=gnupg.so*"  $php55_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line2" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line2}d"  $php55_ini_path1
								fi
								php56_ini_path="/etc/opt/remi/php56/php.ini"
								line3=$(grep -n "extension=gnupg.so*"  $php56_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line3" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line3}d"  $php56_ini_path
								fi
								php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
								line4=$(grep -n "extension=gnupg.so*"  $php56_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line4" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line4}d"  $php56_ini_path1
								fi
								php71_ini_path="/etc/opt/remi/php71/php.ini"
								line5=$(grep -n "extension=gnupg.so*"  $php71_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line5" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line5}d"  $php71_ini_path
								fi
								php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
								line6=$(grep -n "extension=gnupg.so*"  $php71_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line6" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line6}d"  $php71_ini_path1
								fi
								php72_ini_path="/etc/opt/remi/php72/php.ini"
								line7=$(grep -n "extension=gnupg.so*"  $php72_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line7" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line7}d"  $php72_ini_path
								fi
								php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
								line8=$(grep -n "extension=gnupg.so*"  $php72_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line8" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line8}d"  $php72_ini_path1
								fi
								php73_ini_path="/etc/opt/remi/php73/php.ini"
								line9=$(grep -n "extension=gnupg.so*"  $php73_ini_path  | awk '{print $1}' FS=":")
								if [ -z "$line9" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line9}d"  $php73_ini_path
								fi
								php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
								line10=$(grep -n "extension=gnupg.so*"  $php73_ini_path1  | awk '{print $1}' FS=":")
								if [ -z "$line10" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line10}d"  $php73_ini_path1
								fi
                                reloadhttpd  $ver_d;
                        ;;
                        imagick)
				            yum remove ImageMagick ImageMagick-devel -y
                            pecl uninstall imagick > /dev/null;
				            imgick_path="/etc/php.d/imagick.ini";
				            if [ -f  "$imgick_path" ]
				            then 
								line1=$(grep -n "extension=imagick.so*"  $imgick_path  | awk '{print $1}' FS=":")
								if [ -z "$line1" ]
								then
									echo " " >/dev/null;
								else
									sed -i "${line1}d"  $imgick_path;
								fi
				            fi
							php54_ini_path="/etc/opt/remi/php54/php.ini"
							line11=$(grep -n "extension=imagick.so*"  $php54_ini_path  | awk '{print $1}' FS=":")
							if [ -z "$line11" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line11}d"  $php54_ini_path
							fi
							php54_ini_path1="/opt/remi/php54/root/etc/php.ini"
							line12=$(grep -n "extension=imagick.so*"  $php54_ini_path1  | awk '{print $1}' FS=":")
							if [ -z "$line12" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line12}d"  $php54_ini_path1
							fi
							php55_ini_path="/etc/opt/remi/php55/php.ini"
							line1=$(grep -n "extension=imagick.so*"  $php55_ini_path  | awk '{print $1}' FS=":")
							if [ -z "$line1" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line1}d"  $php55_ini_path
							fi
							php55_ini_path1="/opt/remi/php55/root/etc/php.ini"
							line2=$(grep -n "extension=imagick.so*"  $php55_ini_path1  | awk '{print $1}' FS=":")
							if [ -z "$line2" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line2}d"  $php55_ini_path1
							fi
							php56_ini_path="/etc/opt/remi/php56/php.ini"
							line3=$(grep -n "extension=imagick.so*"  $php56_ini_path  | awk '{print $1}' FS=":")
							if [ -z "$line3" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line3}d"  $php56_ini_path
							fi
							php56_ini_path1="/opt/remi/php56/root/etc/php.ini"
							line4=$(grep -n "extension=imagick.so*"  $php56_ini_path1  | awk '{print $1}' FS=":")
							if [ -z "$line4" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line4}d"  $php56_ini_path1
							fi
							php71_ini_path="/etc/opt/remi/php71/php.ini"
							line5=$(grep -n "extension=imagick.so*"  $php71_ini_path  | awk '{print $1}' FS=":")
							if [ -z "$line5" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line5}d"  $php71_ini_path
							fi
							php71_ini_path1="/opt/remi/php71/root/etc/php.ini"
							line6=$(grep -n "extension=imagick.so*"  $php71_ini_path1  | awk '{print $1}' FS=":")
							if [ -z "$line6" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line6}d"  $php71_ini_path1
							fi
							php72_ini_path="/etc/opt/remi/php72/php.ini"
							line7=$(grep -n "extension=imagick.so*"  $php72_ini_path  | awk '{print $1}' FS=":")
							if [ -z "$line7" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line7}d"  $php72_ini_path
							fi
							php72_ini_path1="/opt/remi/php72/root/etc/php.ini"
							line8=$(grep -n "extension=imagick.so*"  $php72_ini_path1  | awk '{print $1}' FS=":")
							if [ -z "$line8" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line8}d"  $php72_ini_path1
							fi
							php73_ini_path="/etc/opt/remi/php73/php.ini"
							line9=$(grep -n "extension=imagick.so*"  $php73_ini_path  | awk '{print $1}' FS=":")
							if [ -z "$line9" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line9}d"  $php73_ini_path
							fi
							php73_ini_path1="/opt/remi/php73/root/etc/php.ini"
							line10=$(grep -n "extension=imagick.so*"  $php73_ini_path1  | awk '{print $1}' FS=":")
							if [ -z "$line10" ]
							then
								echo " " >/dev/null;
							else
								sed -i "${line10}d"  $php73_ini_path1
							fi
				            reloadhttpd  $ver_d;
                        ;;
                        ffmpeg)
                            r=$(( $RANDOM  ));
                            n_file_detail="/root/scripts$r/";
                            mkdir -p $n_file_detail
                            removesofile $n_file_detail "ffmpeg.so" $php_path;
                            rm -rf $n_file_detail
                            #sudo yum remove  ffmpeg ffmpeg-devel -y
                            sudo  yum remove  ffmpeg* -y 
                            reloadhttpd  $ver_d;
                        ;;
                        esac
		;;

		*) 
			echo "";
		;;
	esac
fi
