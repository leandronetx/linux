<?php
//$version_arr=array_filter(explode("\n",shell_exec("ls -ll /usr/bin/python* | awk '{print $9}'  | grep -v \"config\"  | grep -v \"futurize\" | grep -v \"pasteurize\"")));
$version_arr=array_filter(explode("\n",shell_exec("find /usr/bin/python*  -type f | grep -v \"config\"  | grep -v \"futurize\" | grep -v \"pasteurize\"")));
//var_dump($version_arr);
foreach($version_arr as $key => $val)
{
if(is_dir($val))
{
echo $val;
unset($version_arr[$key]);
}
}
var_dump($version_arr); 
?>
