if [ "$#" == 2 ]
then
	username=$1 
	domain_name=$2
        filename=$(echo $domain_name | sed 's/\*./wildcard_/g')
	mkdir -p /var/sentora/logs/nodejs/$username
	pm2 restart $domain_name --user $username --uid $username --gid $username --error /var/sentora/logs/nodejs/$username/$filename-node-error.log --output /var/sentora/logs/nodejs/$username/$filename-node-out.log
	pm2 save
	chown $username:$username /var/sentora/logs/nodejs/$username
	chown $username:$username /var/sentora/logs/nodejs/$username/$filename-node-error.log
	chown $username:$username /var/sentora/logs/nodejs/$username/$filename-node-out.log
fi
