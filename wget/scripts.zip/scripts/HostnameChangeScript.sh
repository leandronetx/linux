new_hostname=$1
hostname_service=`whereis hostname | awk '{print $2}'`
old_hostname=`$hostname_service`
echo $new_hostname
echo $old_hostname
hostnamectl_service=`whereis hostnamectl | awk '{print $2}'`
static_hostname=`$hostnamectl_service  | grep "Static hostname" | awk '{print $3}'`
echo $static_hostname
$hostnamectl_service set-hostname $new_hostname
setso --set sentora_domain "$new_hostname"
sed_service=`whereis sed | awk '{print $2}'`
echo $sed_service
#$sed_service -i "s/$old_hostname/$new_hostname/g" /etc/hosts
#$sed_service -i "s/$old_hostname/$new_hostname/g" /etc/hosts
#$sed_service -i "s/$old_hostname/$new_hostname/g" /etc/hosts
#$sed_service -i "s/$old_hostname/$new_hostname/g" /etc/postfix/main.cf
$sed_service -i "s/mydomain = $old_hostname/mydomain = $new_hostname/g" /etc/postfix/main.cf
$sed_service -i "s/myhostname = $old_hostname/myhostname = $new_hostname/g" /etc/postfix/main.cf
old_hostname=`echo $old_hostname | tr '[:lower:]' '[:upper:]'`
new_hostname=`echo $new_hostname | tr '[:lower:]' '[:upper:]'`
$sed_service -i "s/mydomain = $old_hostname/mydomain = $new_hostname/g" /etc/postfix/main.cf
$sed_service -i "s/myhostname = $old_hostname/myhostname = $new_hostname/g" /etc/postfix/main.cf
service_service=`whereis service  | awk '{print $2}'`
`$service_service postfix restart`
php_service=`whereis php | awk '{print $2}'`
$php_service /etc/sentora/panel/bin/daemon.php
/usr/bin/ssltlsconfig
