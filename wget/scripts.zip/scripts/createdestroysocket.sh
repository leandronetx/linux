#!/bin/bash
param=$1
user=$2
whereis_sh=$(whereis sh | awk '{ print $2 }')

	case $param in
	createsocket)
		echo "createsocket"
                kill $(ps -u $user | grep "php56-cgi" | awk '{ print $1 }')
                rm -f /etc/sentora/panel/fastcgi/"$user".socket
                rm -f /etc/sentora/panel/fastcgi/"$user"-fm.socket		
		$whereis_sh /etc/sentora/panel/fastcgi/$user-startup.sh	
		;;
	destorysocket)
		echo "destorysocket"	
		kill $(ps -u $user | grep "php56-cgi" | awk '{ print $1 }')
		rm -f /etc/sentora/panel/fastcgi/"$user".socket
		rm -f /etc/sentora/panel/fastcgi/"$user"-fm.socket
		;;
	*)
		echo "param is wrong"
		;;
	esac 
