#!/bin/sh
echo $@"................."
ver_d=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
if [ "$#" -lt 2 ]
then
	echo "Please use this format to execute 'sh /scripts/modhttp.sh 1'";
else
	if [ "$1" == 2 ]
	then 
		source_code_deploy_path="/usr/src/modhttp/"
		httpd_folder_path="/etc/httpd/conf/";
		php_ini_path="/etc/php.ini";
		php_ini_path_bk="/etc/php.ini_bk";
		httpd_file_path=$httpd_folder_path"httpd.conf";
		httpd_file_path_bk=$source_code_deploy_path"httpd.conf_bk";
		
		mkdir -p $source_code_deploy_path
		yes | cp -avr $php_ini_path $php_ini_path_bk
		yes | cp -avr $httpd_file_path $httpd_file_path_bk
		#yum remove httpd -y
		yum-complete-transaction -y 
		yum-complete-transaction --cleanup-only 
		yum history redo last

		yum -y remove apr 
		yum -y remove mod_ssl 

		cd $source_code_deploy_path
		wget -O host_epel-release-latest-7.noarch.rpm  http://hostingraja.info/Version2.0/epel-release-latest-7.noarch.rpm && rpm -Uvh host_epel-release-latest-7.noarch.rpm
		wget -O host_remi-release-7.rpm http://hostingraja.info/Version2.0/remi-release-7.rpm && rpm -Uvh host_remi-release-7.rpm

		wget http://hostingraja.info/Version2.0/mailcap-2.1.41-2.el7.noarch.rpm
		rpm -ivh mailcap-2.1.41-2.el7.noarch.rpm

		wget http://hostingraja.info/Version2.0/httpd-filesystem-2.4.23-2.el7.codeit.noarch.rpm
		rpm -ivh httpd-filesystem-2.4.23-2.el7.codeit.noarch.rpm

		wget http://hostingraja.info/Version2.0/apr-1.5.2-1.el7.codeit.x86_64.rpm
		rpm -ivh apr-1.5.2-1.el7.codeit.x86_64.rpm

		yum -y install apr-util

		wget http://hostingraja.info/Version2.0/httpd-tools-2.4.23-2.el7.codeit.x86_64.rpm
		rpm -ivh httpd-tools-2.4.23-2.el7.codeit.x86_64.rpm

		yum -y install nghttp2 
		yum -y install libnghttp2 
		yum -y install libnghttp2-devel 

	    wget http://hostingraja.info/Version2.0/centos-logos-70.0.6-3.el7.centos.noarch.rpm
		rpm -ivh centos-logos-70.0.6-3.el7.centos.noarch.rpm 

		wget http://hostingraja.info/Version2.0/httpd-2.4.23-2.el7.codeit.x86_64.rpm
		rpm -ivh httpd-2.4.23-2.el7.codeit.x86_64.rpm

		echo "LoadModule watchdog_module modules/mod_watchdog.so" >> /etc/httpd/conf.modules.d/00-optional.conf

		wget http://hostingraja.info/Version2.0/mod_ssl-2.4.23-2.el7.codeit.x86_64.rpm
		rpm -ivh mod_ssl-2.4.23-2.el7.codeit.x86_64.rpm
		yum -y install mod_fcgid
		yum -y install mod_limitipconn 
		yum -y install mod_evasive
		yum -y install php
		mv $httpd_file_path_bk $httpd_file_path
		mv $php_ini_path_bk $php_ini_path
	fi
	if [ "$2" == 1 ]
	then 
		if [ $ver_d == "7" ]
                then
                        systemctl stop  nginx
                        systemctl restart httpd
                else
                        service nginx stop
                        service httpd restart
                fi
	else
		if [ $ver_d == "7" ]
                then    
                        systemctl stop  varnish
			systemctl stop  httpd
                        systemctl restart nginx
                else
                        service varnish stop
			service httpd stop
			service nginx restart
                fi
	fi
	/usr/bin/php /etc/sentora/panel/bin/daemon.php

fi
	
