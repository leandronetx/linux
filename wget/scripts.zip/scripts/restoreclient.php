<?php
if($argc!==3)
{
	echo "could you please pass the parameters correctly.";
	exit();
}
require('/etc/sentora/panel/cnf/database.php');
include('/etc/sentora/panel/dryden/db/driver.class.php');
include('/etc/sentora/panel/dryden/debug/logger.class.php');
include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
include('/etc/sentora/panel/dryden/runtime/hook.class.php');
include('/etc/sentora/panel/dryden/ctrl/users.class.php');
include('/etc/sentora/panel/dryden/sys/versions.class.php');
include('/etc/sentora/panel/dryden/ctrl/options.class.php');
include('/etc/sentora/panel/dryden/fs/director.class.php');
include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
include('/etc/sentora/panel/inc/dbc.inc.php');
try {
    $dsn = "mysql:dbname=$dbname;$ovi_socket_path";
    $zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
    $zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    exit();
}

$username=trim($argv[2]);
$download=1;

$SERVICE_EXEC=trim(shell_exec("whereis service | awk '{print $2}'"));
shell_exec("$SERVICE_EXEC crond stop");

				$rows = $zdbh->prepare("SELECT a.* FROM x_accounts a,x_profiles p,x_groups g,x_packages pa,x_quotas q  WHERE a.ac_id_pk=p.ud_user_fk AND a.ac_group_fk=g.ug_id_pk AND a.ac_package_fk=pa.pk_id_pk AND a.ac_package_fk=q.qt_package_fk AND a.ac_user_vc= :ac_user_vc");
				$rows->bindParam(':ac_user_vc', $username);
				$rows->execute();
				if ($rows->fetchColumn() != 0) {
					$rows = $zdbh->prepare("SELECT a.* FROM x_accounts a,x_profiles p,x_groups g,x_packages pa,x_quotas q  WHERE a.ac_id_pk=p.ud_user_fk AND a.ac_group_fk=g.ug_id_pk AND a.ac_package_fk=pa.pk_id_pk AND a.ac_package_fk=q.qt_package_fk AND a.ac_user_vc= :ac_user_vc");
					$rows->bindParam(':ac_user_vc', $username);
					$rows->execute();
					$dbvals = $rows->fetch();
					$userid=$dbvals['ac_id_pk'];
					$email=$dbvals['ac_email_vc'];
					$user=$dbvals['ac_user_vc'];
					$filename=$argv[1];
					if ($backup = ExecuteRestore($userid, $user, $download, $filename, $email)) {
					echo $filename." - successfully restore";	
					} else {
					echo "<h2>Unauthorized Access!</h2>";
					echo "You have no permission to view this module.";
					}		
				}
				else
				{
				echo "Username does not exists.";
				exit();	
				}
				
function ExecuteRestore($userid, $username, $download = 0, $getfilename, $email) 
{
	global $controller;
	include('/etc/sentora/panel/cnf/database.php');
	$vhost_path = ctrl_options::GetSystemOption('hosted_dir');
	// Database Connectivity
	$inserted_domain_name=array();
	try {
	    $dsn = "mysql:dbname=$dbname;$ovi_socket_path";
    	    $zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
	    $zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
	    $mysql_zdbh = new db_driver("mysql:host=$host;", $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
	    $mysql_zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
	} catch (PDOException $e) {
	exit();
	}
	$mailserver_db = ctrl_options::GetSystemOption('mailserver_db');
	$z_db_user = $user;
	$z_db_pass = $pass;
	try {
	$dsn = "mysql:dbname=$mailserver_db;$ovi_socket_path";
        $mail_db = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
        $mail_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	} catch (PDOException $e) {
	echo $e;
	}
	// Needed Directory Path 
	$filename=$getfilename;
	$homedir = ctrl_options::GetSystemOption('hosted_dir') . $username;
	$backupdir = $homedir . "/backups/";
	//$backupdir = getcwd()."/";
	$filepath=$backupdir . $filename;
	$foldername=substr($getfilename,0,-7);
	$jsonfilepath=$backupdir.$foldername."/userdata/cache.json";
	$jsonfilepath=$backupdir.$foldername."/userdata/";
	$mainfilepath=$backupdir.$foldername."/userdata/main";
	$mailforwarderpath=$backupdir.$foldername."/va/";
	
	if (file_exists($backupdir . $filename)){

			/* ///////////////////////////// untar file working code start //////////////////////////////// */
			
			$exec_cmd="chmod -R 0777 ".$vhost_path.$username."/backups/";			
			$reasult=exec($exec_cmd);
			$exec_cmd="cd ".$backupdir . " && tar -xvzf ".$filename;
			$reasult=exec($exec_cmd);
			$cpanelhomepath = trim(file_get_contents($backupdir.$foldername."/homedir_paths"));

			/* ///////////////////////////// untar file working code end //////////////////////////////// */					
                if(!is_dir($backupdir.$foldername)){
                        file_put_contents($whm_migration_log, "backup dir $username $backupdir.$foldername\n", FILE_APPEND);                                           return FALSE;
                }
	
			 /* ///////////////////////////// Cron tab Working Start ///////////////////////////////////// */

			 if(file_exists($backupdir.$foldername."/homedir_paths"))
			 {

				$c_file = fopen($backupdir.$foldername."/homedir_paths","r");
				$c_i=0;
				$c_filename="";
				$path=fgets($c_file);
				$c_array=explode("/",$path);
				$c_filename=trim($c_array[count($c_array)-1]);
				fclose($c_file);
				if(file_exists($backupdir.$foldername."/cron/".$c_filename))
				{
				 echo "cron restore starting .. \n ";	
				$c1_file = fopen($backupdir.$foldername."/cron/".$c_filename,"r");
				$iter=0;
				while(! feof($c1_file))
				{
				$get_value=fgets($c1_file);
					
					if(trim($get_value)!="")
	                {

                        $csplit_array=explode(" ",trim($get_value));
                         if(count($csplit_array)<7)
                         continue;
                         $ct_timing_vc=$csplit_array[0]." ".$csplit_array[1]." ".$csplit_array[2]." ".$csplit_array[3]." ".$csplit_array[4];
                         $ct_script_vc=trim(shell_exec("whereis ".$csplit_array[5]." | awk '{print $2}'"));
                         $cronfilepath=trim($csplit_array[6]);
                         unset($csplit_array[0]);
                         unset($csplit_array[1]);
                         unset($csplit_array[2]);
                         unset($csplit_array[3]);
                         unset($csplit_array[4]);
                         unset($csplit_array[5]);
                         unset($csplit_array[6]);
                         $desc="";
                         $array_count=count($csplit_array);

                         if($array_count!=0)
                         {
                                $desc=implode(" ",$csplit_array);
                                $desc=trim(str_replace(">>","", $desc));
                		$fsplit1=explode("/public_html/",$desc);
				$desc=$vhost_path.$username."/public_html/".$fsplit1[1]; 
                         }


                     	if (strpos($cronfilepath,"http://")!==false || strpos($cronfilepath,"https://")!==false)
			{
				$final_get_Path=$cronfilepath;
			}
			else
			{
				$fsplit=explode("/public_html/",$cronfilepath);
				$final_get_Path=$vhost_path.$username."/public_html/".$fsplit[1];
			}


                    $sql = $zdbh->prepare("INSERT INTO x_cronjobs (ct_acc_fk, ct_script_vc, ct_description_tx, ct_timing_vc, ct_fullpath_vc, ct_created_ts) VALUES (:userid, :script, :desc, :timing, :fullpath, " . time() . ")");
					$sql->bindParam(':userid',$userid);
					$sql->bindParam(':script', $ct_script_vc);
					$sql->bindParam(':desc', $desc);
					$sql->bindParam(':timing', $ct_timing_vc);
					$full_path = $final_get_Path;
					$sql->bindParam(':fullpath', $full_path);
					$sql->execute();
					if($array_count!=0)
  					$updateline = $ct_timing_vc . ' ' .$ct_script_vc.' '.$full_path.' >> '.$desc;
  					else 
					$updateline = $ct_timing_vc . ' ' .$ct_script_vc.' '.$full_path;
					$user_cron_file="/var/spool/cron/".$username;
					$new_file_creation='MAILTO=""'."\n"
					.'SHELL=/bin/bash'."\n"
					.'PATH=/sbin:/bin:/usr/sbin:/usr/bin'."\n"
					.'HOME=/'."\n"
					.'#################################################################################'."\n"
					.'# CRONTAB FOR SENTORA CRON MANAGER MODULE'."\n"
					.'# Module Developed by OVI Team,'."\n"
					.'#################################################################################'."\n"
					.'# NEVER MANUALLY REMOVE OR EDIT ANY OF THE CRON ENTRIES FROM THIS FILE,'."\n"
					.'#  -> USE SENTORA INSTEAD! (Menu -> Advanced -> Cron Manager)'."\n"
					.'#################################################################################'."\n";
					if(!file_exists($user_cron_file))
					$cmd='echo "'.$new_file_creation.'" >> '.$user_cron_file;
					shell_exec($cmd);
					$cmd='echo "'.$updateline.'" >> '.$user_cron_file;
					shell_exec($cmd);
					$cmd="chown $username:$username $user_cron_file";		
					shell_exec($cmd);
					$cmd="chmod 644 $user_cron_file";
                                        shell_exec($cmd);
    	            }
				}
				fclose($c1_file);
				 echo "cron restored successfully.. \n ";
				}
			 }
			 /* ///////////////////////////// Cron tab Working End ///////////////////////////////////// */
			 
			/* ///////////////////////////// mysql database working code start ////////////////////////////////  */
			if(file_exists($backupdir.$foldername."/mysql/"))
			{
				echo "MySQL DB restore starting .. \n ";
			$files1 = scandir($backupdir.$foldername."/mysql/");
			foreach($files1 as $key => $value)
			{
				if(substr($value,-7)==".create")
				{
				 $db_name=substr($value,0,-7);	
				 $dbsql=" CREATE DATABASE IF NOT EXISTS `".$db_name."`";
				 $sql = $mysql_zdbh->prepare($dbsql);
				 $sql->execute();
				 $bkcommand = "mysql -h " . $host . " -u " . $user . " -p" . $pass . " ".$db_name." < " . $backupdir.$foldername."/mysql/".$db_name.".sql";
				 $r=passthru($bkcommand); 
			
			// Bug Fixing code start //
						$sql_db = "SELECT COUNT(*) FROM x_mysql_databases WHERE my_name_vc='".$db_name."' And my_deleted_ts IS NULL And my_acc_fk='".$userid."'";
						if ($numrows_db = $zdbh->query($sql_db)) {
						if ($numrows_db ->fetchColumn() == 0) {
						$sql = $zdbh->prepare("INSERT INTO x_mysql_databases (
							my_acc_fk,
							my_name_vc,
							my_created_ts) VALUES (
							:userid,
							:name,
							:time)");
						$time = time();
						$name =$db_name;
						$sql->bindParam(':userid',$userid);
						$sql->bindParam(':time', $time);
						$sql->bindParam(':name', $name);
						$sql->execute();
						}
					}			
				}	
				
			}
			echo "MySQL DB restored successfully.. \n ";
			}
			/*  ///////////////////////////// mysql database working code end //////////////////////////////// */
		    /*  ///////////////////////////// mysql users working code start //////////////////////////////// */
		
			
			if( file_exists($backupdir.$foldername."/mysql.sql") )
			{
			/////////////////////////////////////////////// Update Mysql Table start ////////////////////////////////////////////////
			echo "mysql user restore starting .. \n ";
			 $bkcommand = "mysql -h " . $host . " -u " . $user . " -p" . $pass . " mysql < " . $backupdir.$foldername."/mysql.sql";
             $r=passthru($bkcommand);
			 
			 echo "mysql user restored successfully.. \n ";
			 
			 /////////////////////////////////////////////// Update Mysql Table start ////////////////////////////////////////////////
				$fp=fopen($backupdir.$foldername."/mysql.sql","r");
				$usernamelist=array();
				$dblist=array();
				static $DB_User_Name="";
				static $DB_DB_Name="";
				// static $DB_count=0;

				while(!feof($fp))
				{
				$line=fgets($fp);
					if(preg_match("/^GRANT USAGE ON/",$line))
					{
						$line1=str_replace("GRANT USAGE ON *.* TO","",$line);
						$split_line=explode("@",$line1);
						$DB_User_Name=trim(str_replace("'","",$split_line[0]));
						
					}
					if(preg_match("/^GRANT ALL PRIVILEGES ON/",$line))
					{
					$line2=explode(" ",trim(str_replace("GRANT ALL PRIVILEGES ON","",$line)));	
					if(stripslashes(str_replace("`","",str_replace("`.*","",$line2[0])))==$DB_DB_Name)
					continue;
					$DB_DB_Name=trim(stripslashes(str_replace("`","",str_replace("`.*","",$line2[0]))));
					
					
						$numrows = $zdbh->prepare("SELECT * FROM x_mysql_users WHERE mu_name_vc=:mu_name_vc AND mu_deleted_ts IS NULL");
						$numrows->bindParam(':mu_name_vc',$DB_User_Name );
						$numrows->execute();
						if ($numrows->fetchColumn() == 0) {

						$numrows_db = $zdbh->prepare("SELECT * FROM x_mysql_databases WHERE my_name_vc=:database AND my_acc_fk=:userid And my_deleted_ts IS NULL");
						$numrows_db->bindParam(':database', $DB_DB_Name );
						$numrows_db->bindParam(':userid', $userid);
						$numrows_db->execute();
						$result_db = $numrows_db->fetch();
						$database_db=$result_db['my_id_pk'];

						$sql1 = $zdbh->prepare("INSERT INTO x_mysql_users (
						mu_acc_fk,
						mu_name_vc,
						mu_database_fk,
						mu_pass_vc,
						mu_access_vc,
						mu_created_ts) VALUES (
						:userid,
						:username,
						:database,
						:password,
						:access,
						:time)");
						$sql1->bindParam(':userid', $userid);
						$sql1->bindParam(':username', $DB_User_Name);
						$sql1->bindParam(':database', $database_db);
						$user_password="******";
						$sql1->bindParam(':password', $user_password);
						$access="localhost";
						$sql1->bindParam(':access', $access);
						$time = time();
						$sql1->bindParam(':time', $time);
						$sql1->execute();

						$numrows_db = $zdbh->prepare("SELECT * FROM x_mysql_users WHERE mu_name_vc=:database AND mu_acc_fk=:userid And mu_deleted_ts IS NULL");
						$numrows_db->bindParam(':database', $DB_User_Name);
						$numrows_db->bindParam(':userid', $userid);
						$numrows_db->execute();
						$result_db = $numrows_db->fetch();
						$myuserid=$result_db['mu_id_pk'];


						$sql2 = $zdbh->prepare("
						INSERT INTO x_mysql_dbmap (
						mm_acc_fk,
						mm_user_fk,
						mm_database_fk) VALUES (
						:uid,
						:myuserid,
						:dbid
						)");
						$sql2->bindParam(':uid', $userid);
						$sql2->bindParam(':myuserid', $myuserid);
						$sql2->bindParam(':dbid', $database_db);
						$sql2->execute();

						}else
						{
							
						$numrows_db = $zdbh->prepare("SELECT * FROM x_mysql_databases WHERE my_name_vc=:database AND my_acc_fk=:userid And my_deleted_ts IS NULL");
						$numrows_db->bindParam(':database', $DB_DB_Name );
						$numrows_db->bindParam(':userid', $userid);
						$numrows_db->execute();
						$result_db = $numrows_db->fetch();
						$database_db=$result_db['my_id_pk'];
						
						$numrows_db = $zdbh->prepare("SELECT * FROM x_mysql_users WHERE mu_name_vc=:database AND mu_acc_fk=:userid And mu_deleted_ts IS NULL");
						$numrows_db->bindParam(':database', $DB_User_Name);
						$numrows_db->bindParam(':userid', $userid);
						$numrows_db->execute();
						$result_db = $numrows_db->fetch();
						$myuserid=$result_db['mu_id_pk'];

				

						$sql2 = $zdbh->prepare("
						INSERT INTO x_mysql_dbmap (
						mm_acc_fk,
						mm_user_fk,
						mm_database_fk) VALUES (
						:uid,
						:myuserid,
						:dbid
						)");
						$sql2->bindParam(':uid', $userid);
						$sql2->bindParam(':myuserid', $myuserid);
						$sql2->bindParam(':dbid', $database_db);
						$sql2->execute();	
							
					}

					
					}
				
				
				}
			
				
				
				
				fclose($fp);
				
                                $del= $zdbh->prepare("DELETE a
                                                                        FROM x_mysql_dbmap as a, x_mysql_dbmap as b
                                                                        WHERE (a.mm_acc_fk  = b.mm_acc_fk )
                                                                        AND (a.mm_user_fk  = b.mm_user_fk )
                                                                        AND (a.mm_database_fk  = b.mm_database_fk )
                                                                        AND a.mm_id_pk < b.mm_id_pk");
				$del->execute();
			}
 
			 /* ///////////////////////////// mysql users working code end //////////////////////////////// */

			/* ///////////////////////////// Upload all files into our domain start ///////////////////////////  */

			$deshomedir = ctrl_options::GetSystemOption('hosted_dir') . $username;
			
			echo "Backup Files restore starting .. \n ";
			
			$srchomedir=$backupdir.$foldername."/homedir/*";
		
			$execcopy="rsync -avrzh --include='.*' ".$srchomedir." ".$deshomedir."/";
			$r=passthru($execcopy); 
			
			//$cmd_own=" chown -R apache:apache ".$deshomedir." ";
			$cmd_own=" chown -R ".$username.":".$username." ".$deshomedir." ";
			passthru($cmd_own);
			
			echo "Backup Files restored successfully.. \n ";
                        $mail_backup_dir=$backupdir.$foldername."/homedir/mail";
                        $public_backup_dir=$backupdir.$foldername."/homedir/public_html";
                        if(is_dir($mail_backup_dir)){
                                unlink($mail_backup_dir);
                        }
                        if(is_dir($public_backup_dir)){
                                unlink($mail_backup_dir);
                        }
			 ///////////////////////////// Upload all files into our domain End /////////////////////////// */

			/* ///////////////////////////// Main Domain Upload and insert a DB start /////////////////////////// */
			$Domain_file = fopen($mainfilepath,"r");
			$in_array_check=array();
			while(! feof($Domain_file))
			{
				  static $flag="";					
				  $doamin="";
				  $rootdirectorypath="";
				  $addon_file_path="";
				  $line=fgets($Domain_file);

					if(trim($line)!="---" && trim($line)!="" )
					{
						if(strpos($line,"_domains:"))
						{
							$split_line=explode("_",$line);						
							$flag=$split_line[0];
							continue;
						}
							echo "\nflag $flag\n";
						if(strpos($line,"main_domain:")!==false)
						{
						$maindomain_split=explode(":",$line);
							$flag="main";
							$maindomain=$maindomain_split[count($maindomain_split)-1];
						}
						if(trim($flag)=="main" )
						{
						// main and addon 
							$domain_split=explode(":",$line);
							$domain=trim($domain_split[count($domain_split)-1]);
							echo "\n came to main block - $domain \n";

						}else if(trim($flag)=="addon")
						{
							$domain_split=explode(":",$line);
							$domain=trim($domain_split[0]);
							$in_array_check[]=trim($domain_split[count($domain_split)-1]);
							$addon_file_path=trim($domain_split[count($domain_split)-1]);
							echo "\n came to addon block - $domain \n";
						}else
						{
							// parked ans sub 
							$domain_split=explode("-",$line);
							$domain=trim($domain_split[count($domain_split)-1]);
							echo "\n sub domain $domain\n";
						}
						
							 if(trim($flag)=="addon")
						{
						
							
							if(file_exists($backupdir.$foldername."/userdata/".$addon_file_path))
							{
							$Inner_Domain_file = fopen($backupdir.$foldername."/userdata/".$addon_file_path,"r");
							while(! feof($Inner_Domain_file))
							{
							$filepathline=fgets($Inner_Domain_file);
							if(strpos($filepathline,"documentroot:")!==false)
							{
							$split_root=explode(":",$filepathline);
							$rootdirectorypath=trim($split_root[count($split_root)-1]);
							break;	
							}
							}
							fclose($Inner_Domain_file);
							}	
							
							
						}
						else
						{
							if(file_exists($backupdir.$foldername."/userdata/".$domain))
							{
							$Inner_Domain_file = fopen($backupdir.$foldername."/userdata/".$domain,"r");
							while(! feof($Inner_Domain_file))
							{
							$filepathline=fgets($Inner_Domain_file);
							if(strpos($filepathline,"documentroot:")!==false)
							{
							$split_root=explode(":",$filepathline);
							$rootdirectorypath=trim($split_root[count($split_root)-1]);
							break;	
							}
							}
							fclose($Inner_Domain_file);
							}	
						}
						
						/* ////////////////////////// Domain Data Insert Start /////////////////// */
						
							echo "Domain restore starting .. \n ";
							echo "Domain restore starting .. domain_name $domain \n ";
							$maindomainname="";				
							$domain_name=$domain;
							$domain_type=$flag;
							$destination="";
							
							$h_file = fopen($backupdir.$foldername."/homedir_paths","r");
							$h_filename="";
							$h_path=trim(fgets($h_file));								
							fclose($h_file);
							//set destination and move the list of files into public_html/

							$destination=str_replace($h_path,"",$rootdirectorypath);

							 if($flag=="parked")
							{
								$destination="/public_html";
							}
							
							echo "\n domain_name $domain_name detination: $destination\n";

							$domaintypeselect = array( 
							"main" => "1",
							"addon" => "1",				
							"sub" => "2", 
							"parked" => "3" ); 
							$vh_type=$domaintypeselect[$domain_type];
							$vh_active_in=0;
							array_push($inserted_domain_name,$domain_name);
							$sql = "SELECT COUNT(*) FROM x_vhosts WHERE vh_name_vc='".$domain_name."' And vh_deleted_ts IS NULL";
							if ($numrows = $zdbh->query($sql)) {
							if ($numrows->fetchColumn() <> 0) {
							// Update the domain path only 
							$sql = $zdbh->prepare("update x_vhosts set vh_directory_vc=:destination,vh_active_in=:vh_active_in,vh_type_in=:vh_type
								where vh_name_vc=:domain");
								
							$sql->bindParam(':destination', $destination);
							$sql->bindParam(':vh_active_in', $vh_active_in);
							$sql->bindParam(':vh_type', $vh_type);
							$sql->bindParam(':domain', $domain_name);
							$sql->execute();

							//echo ""
							$gsql=$zdbh->prepare("select vh_id_pk from x_vhosts where vh_name_vc=:domainName AND vh_acc_fk=:userid AND vh_deleted_ts is NULL");

							$gsql->bindParam(':domainName', $domain_name);
							$gsql->bindParam(':userid', $userid);
							$gsql->execute();
							$res=$gsql->fetch();
							$domainID=$res['vh_id_pk'];
							//	echo "DomainId:".$domainID."<br/>";
							$records_list = ctrl_options::GetSystemOption('dns_hasupdates');
							$record_array = explode(',', $records_list);
							if (!in_array($domainID, $record_array)) {
							if (empty($records_list)) {
							$records_list .= $domainID;
							} else {
							$records_list .= ',' . $domainID;
							}
							$sql = "UPDATE x_settings SET so_value_tx=:newlist WHERE so_name_vc='dns_hasupdates'";
							$sql = $zdbh->prepare($sql);
							$sql->bindParam(':newlist', $records_list);
							$sql->execute();
							}
							$sql = $zdbh->prepare("UPDATE x_settings
							SET so_value_tx='true'
							WHERE so_name_vc='apache_changed'");
							$sql->execute();

							}else
							{
							// Add the Domain path in vhost and 
							$sql = $zdbh->prepare("INSERT INTO x_vhosts (vh_acc_fk,
								vh_name_vc,
								vh_directory_vc,
								vh_type_in,vh_active_in,
								vh_created_ts) VALUES (
								:userid,
								:domain,
								:destination,
								:vh_type,
								:vh_active_in,
								:time)");      //  CLEANER FUNCTION ON $domain and $homedirectory_to_use (Think I got it?)
							$time = time();
							$sql->bindParam(':time', $time);
							$sql->bindParam(':userid', $userid);
							$sql->bindParam(':vh_type', $vh_type);
							$sql->bindParam(':domain', $domain_name);
							$sql->bindParam(':vh_active_in', $vh_active_in);
							$sql->bindParam(':destination', $destination);
							$sql->execute();
							$domainName=$domain_name;
																						$mailserver_db = ctrl_options::GetSystemOption('mailserver_db');
																						include('/etc/sentora/panel/cnf/database.php');
																						$z_db_user = $user;
																						$z_db_pass = $pass;
																						try {
    
	$dsn = "mysql:dbname=$mailserver_db;$ovi_socket_path";
    $mail_db = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
    $mail_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
																						echo $e;
																						}
																						$numrows_do = $mail_db->prepare("SELECT domain FROM domain WHERE domain=:domain");
																						$numrows_do->bindParam(':domain', $domainName);
																						$numrows_do->execute();
																						$result_do = $numrows_do->fetch();
																						if (!$result_do) {
																						$sql_do = $mail_db->prepare("INSERT INTO domain (  domain,
																						description,
																						aliases,
																						mailboxes,
																						maxquota,
																						quota,
																						transport,
																						backupmx,
																						created,
																						modified,
																						active) VALUES (
																						:domain,
																						'',
																						0,
																						0,
																						0,
																						0,
																						'',
																						0,
																						NOW(),
																						NOW(),
																						'1')");
																						$sql_do->bindParam(':domain', $domainName);
																						$sql_do->execute();
																						}
							//	$currentuser = ctrl_users::GetUserDetail();		
							if (!fs_director::CheckForEmptyValue(ctrl_options::GetSystemOption('server_ip'))) {
							$targetIP = ctrl_options::GetSystemOption('server_ip');
							} else {
							$targetIP = $_SERVER["SERVER_ADDR"]; //This needs checking on windows 7 we may need to use LOCAL_ADDR :- Sam Mottley
							}
							$gsql=$zdbh->prepare("select vh_id_pk from x_vhosts where vh_name_vc=:domainName AND vh_acc_fk=:userid AND vh_deleted_ts is NULL");
							$gsql->bindParam(':userid', $userid);
							$gsql->bindParam(':domainName', $domainName);
							$gsql->execute();
							$res=$gsql->fetch();
							$domainID=$res['vh_id_pk'];
						if($vh_type=="1" || $vh_type=="3" )
						{
							$qsql=$zdbh->prepare("select * from x_dns_create");
							$qsql->execute();
							while($get_dns=$qsql->fetch()){

							$dc_target_vc=str_replace(':IP:',$targetIP,$get_dns['dc_target_vc']);
							$dc_target_vc=str_replace(':DOMAIN:', $domainName, $dc_target_vc);
							if($get_dns['dc_priority_in']==NULL || $get_dns['dc_priority_in']==''){
							$get_dns['dc_priority_in']=0;
							}
							if($get_dns['dc_weight_in']==NULL || $get_dns['dc_weight_in']==''){
							$get_dns['dc_weight_in']=0;
							}
							if($get_dns['dc_port_in']==NULL || $get_dns['dc_port_in']==''){
							$get_dns['dc_port_in']=0;
							}
							$sql = $zdbh->prepare("INSERT INTO x_dns (dn_acc_fk,
							dn_name_vc,
							dn_vhost_fk,
							dn_type_vc,
							dn_host_vc,
							dn_ttl_in,
							dn_target_vc,
							dn_priority_in,
							dn_weight_in,
							dn_port_in,
							dn_created_ts) VALUES (
							:userid,
							:domainName,
							:domainID,
							:type_new,
							:hostName_new,
							:ttl_new,
							:target_new,
							:priority_new,
							:weight_new,
							:port_new,
							:time)"
							);
							$sql->bindParam(':userid', $userid);
							$sql->bindParam(':domainName', $domainName);
							$sql->bindParam(':domainID', $domainID);
							$sql->bindParam(':type_new', $get_dns['dc_type_vc']);
							$sql->bindParam(':hostName_new', $get_dns['dc_host_vc']);
							$sql->bindParam(':ttl_new', $get_dns['dc_ttl_in']);
							$sql->bindParam(':target_new', $dc_target_vc);
							$sql->bindParam(':priority_new', $get_dns['dc_priority_in']);
							$sql->bindParam(':weight_new', $get_dns['dc_weight_in']);
							$sql->bindParam(':port_new', $get_dns['dc_port_in']);
							$time = time();
							$sql->bindParam(':time', $time);
							$sql->execute();
							unset($sql);
							}
						}else if($vh_type=="2")
						{
							//subdomain entry will need to add hear 
							/*  ////////////////////////////////////////// Subdomain code started hear /////////////////////////////////////////////// */
								if (!fs_director::CheckForEmptyValue(ctrl_options::GetSystemOption('server_ip'))) 
								{
									$targetIP = ctrl_options::GetSystemOption('server_ip');
								} 
								else 
								{
									$targetIP = $_SERVER["SERVER_ADDR"];
								}
								 $user_id=$userid;
								 $split_domain=explode(".",$domainName);
								 $subDomainName=$split_domain[0];
								 unset($split_domain[0]);
								 $maindomain=implode(".",$split_domain);
								
								$gsql=$zdbh->prepare("select vh_id_pk from x_vhosts where vh_name_vc=:domainName AND vh_acc_fk=:userid AND vh_deleted_ts is NULL");
								$gsql->bindParam(':userid', $user_id);
								$gsql->bindParam(':domainName', $maindomain);
								$gsql->execute();
								$res=$gsql->fetch();
								$domainID=$res['vh_id_pk'];		
								$dsql=$zdbh->prepare("select count(*) as rcd_cnt from x_dns where dn_acc_fk=:userid AND dn_name_vc=:domainName AND dn_vhost_fk=:domainID AND dn_type_vc='A' AND dn_host_vc=:subDomain AND dn_target_vc=:target_new AND dn_deleted_ts is NULL");		
								$dsql->bindParam(':userid', $user_id);
								$dsql->bindParam(':domainName', $maindomain);
								$dsql->bindParam(':domainID', $domainID);
								$dsql->bindParam(':subDomain', $subDomainName);
								$dsql->bindParam(':target_new', $targetIP);
								$dsql->execute();
								$dres=$dsql->fetch();
								if($dres['rcd_cnt']==0){
								$sql = $zdbh->prepare("INSERT INTO x_dns (dn_acc_fk,
								dn_name_vc,
								dn_vhost_fk,
								dn_type_vc,
								dn_host_vc,
								dn_ttl_in,
								dn_target_vc,
								dn_priority_in,
								dn_weight_in,
								dn_port_in,
								dn_created_ts) VALUES (
								:userid,
								:domainName,
								:domainID,
								'A',
								:hostName_new,
								'86400',
								:target_new,
								'0',
								'0',
								'0',
								:time)"
								);
								$sql->bindParam(':userid', $user_id);
								$subdom = "www.$subDomainName";
								$sql->bindParam(':domainName', $maindomain);
								$sql->bindParam(':domainID', $domainID);
								$sql->bindParam(':hostName_new', $subdom);
								$sql->bindParam(':target_new', $targetIP);
								$time = time();
								$sql->bindParam(':time', $time);
								$sql->execute();
								unset($sql);
								}
							/* /////////////////////////////////////////   Subdomain code End hear ///////////////////////////////////////////////////   */
						}
							$records_list = ctrl_options::GetSystemOption('dns_hasupdates');
							$record_array = explode(',', $records_list);
							if (!in_array($domainID, $record_array)) {
							if (empty($records_list)) {
							$records_list .= $domainID;
							} else {
							$records_list .= ',' . $domainID;
							}
							$sql = "UPDATE x_settings SET so_value_tx=:newlist WHERE so_name_vc='dns_hasupdates'";
							$sql = $zdbh->prepare($sql);
							$sql->bindParam(':newlist', $records_list);
							$sql->execute();
							}
							$sql = $zdbh->prepare("UPDATE x_settings
							SET so_value_tx='true'
							WHERE so_name_vc='apache_changed'");
							$sql->execute();
							}
							}
							  


							echo "Domain restored successfully.. \n ";
						
						/* ////////////////////////// Domain Data Insert End /////////////////// */
						/* ////////////////////////////////// Mail Functionality Starting //////////////////////// */

										if(file_exists($deshomedir."/mail/".$domain."/"))
										{
										echo $domain." - Email restore starting .. \n "; 
										$maildesdir = "/var/sentora/vmail/";
										$srchomedir=$backupdir.$foldername."/homedir/mail/".$domain."/";
										$execcopy="cp -Ru ".$srchomedir." ".$maildesdir." ";
										$r=passthru($execcopy); 
										$change_permisssion="chmod -R 774 "."/var/sentora/vmail/".$domain."/";
										$r1=passthru($change_permisssion);

										$path = "/var/sentora/vmail/".$domain."/";

										$getarray = array();

										// directory handle
										$dir = dir($path);

										while (false !== ($entry = $dir->read())) {
										if ($entry != '.' && $entry != '..') {
										if (is_dir($path . '/' .$entry)) {
										$getarray[] = $entry; 
										}
										}
										}

										foreach($getarray as $key => $value)
										{
										//$getfname=explode(":",$value);
										$maindomainname=$domain;
										$fname=trim($value);
										$fulladdress = strtolower(str_replace(' ', '', $fname . "@" . $maindomainname));
										$address=$fname;
										$location=strtolower(str_replace(' ', '', $maindomainname . "/" . $fname."/"));
										$sql = "SELECT COUNT(*) FROM x_mailboxes WHERE mb_address_vc='".$fulladdress."' And mb_deleted_ts IS NULL";
										if ($numrows = $zdbh->query($sql)) {
										if ($numrows->fetchColumn() == 0) {
										$sql = "INSERT INTO x_mailboxes (mb_acc_fk,
										mb_address_vc,
										mb_created_ts,mb_quota) VALUES (
										:userid,
										:fulladdress,
										:time,'2000')";
										$time = time();
										$sql = $zdbh->prepare($sql);
										$sql->bindParam(':time', $time);
										$sql->bindParam(':userid', $userid);
										$sql->bindParam(':fulladdress', $fulladdress);
										$sql->execute();

										$numrows = $mail_db->prepare("SELECT domain FROM domain WHERE domain=:domain");
										$numrows->bindParam(':domain', $maindomainname);
										$numrows->execute();
										$result = $numrows->fetch();
										if (!$result) {
										$sql = $mail_db->prepare("INSERT INTO domain (  domain,
										description,
										aliases,
										mailboxes,
										maxquota,
										quota,
										transport,
										backupmx,
										created,
										modified,
										active) VALUES (
										:domain,
										'',
										0,
										0,
										0,
										0,
										'',
										0,
										NOW(),
										NOW(),
										'1')");
										$sql->bindParam(':domain', $maindomainname);
										$sql->execute();
										}
										//$result = $mail_db->query("SELECT username FROM mailbox WHERE username='" . $fulladdress . "'")->Fetch();
										$numrows = $mail_db->prepare("SELECT username FROM mailbox WHERE username=:fulladdress");
										$numrows->bindParam(':fulladdress', $fulladdress);
										$numrows->execute();
										$result = $numrows->fetch();
										if (!$result) {
										$sql = $mail_db->prepare("INSERT INTO mailbox (username,
										password,
										name,
										maildir,
										local_part,
										quota,
										domain,
										created,
										modified,
										active) VALUES (
										:fulladdress,
										:password,
										:address,
										:location,
										:address2,
										:maxMail,
										:domain,
										NOW(),
										NOW(),
										'1')");
										$password="HrP$1234s";
										$password = '{PLAIN-MD5}' . md5($password);
										//$location = $domain . "/" . $address . "/";
										$maxMail = ctrl_options::GetSystemOption('max_mail_size');

										$sql->bindParam(':fulladdress', $fulladdress); //ok
										$sql->bindParam(':password', $password); //ok
										$sql->bindParam(':address', $address);
										$sql->bindParam(':location', $location);
										$sql->bindParam(':address2', $address);
										$sql->bindParam(':maxMail', $maxMail);   //ok
										$sql->bindParam(':domain', $maindomainname); //ok
										$sql->execute();
										$sql = $mail_db->prepare("INSERT INTO alias  (address,
										goto,
										domain,
										created,
										modified,
										active) VALUES (
										:fulladdress,
										:fulladdress2,
										:domain,
										NOW(),
										NOW(),
										'1')");
										$sql->bindParam(':domain', $maindomainname);
										$sql->bindParam(':fulladdress', $fulladdress);
										$sql->bindParam(':fulladdress2', $fulladdress);
										$sql->execute();
										}

										}
										}
										}

										echo $domain." - restored successfully.. \n ";  

										}

										/* ////////////////////////////////// Mail Functionality End //////////////////////// */


						/* /////////////////////////////////////// Forwarder Start ///////////////////////// */	

						if(trim($domain))
						{
						
						$forwarderdomain=str_replace("www.","",strtolower($domain));
						$mail_domain_fwd=$mailforwarderpath.$forwarderdomain;
						if(file_exists($mail_domain_fwd))
						{
							$file = fopen($mail_domain_fwd,"r");
        						while(! feof($file))
        						{
                						$get_line=fgets($file);
						                $split_fwd=array_map('trim',explode(":",$get_line));
						                if( count($split_fwd) >= 2)
                						{
                        						$from_email=$split_fwd[0];
                        						$destination_email=$split_fwd[1];
                        						if(trim($from_email)&& trim($destination_email)&&(filter_var($from_email,FILTER_VALIDATE_EMAIL))&&(!strpos($destination_email, 'mailman/mail')))
                        						{
                               							 // echo " $from_email => $destination_email \n";
									        $numrows_fwd = $mail_db->prepare("SELECT goto FROM alias WHERE address=:address");
										$numrows_fwd->bindParam(':address', $from_email);
										$numrows_fwd->execute();
										$result = $numrows_fwd->fetch();
										if (!$result) 
										{	
											$sql_fwd = $mail_db->prepare("INSERT INTO alias(address,goto,domain,created,modified,active) VALUES (:fulladdress,:fulladdress2,:domain,NOW(),NOW(),'1')");
											$sql_fwd->bindParam(':domain', $domain);
											$sql_fwd->bindParam(':fulladdress', $from_email);
											$sql_fwd->bindParam(':fulladdress2', $destination_email);
											$sql_fwd->execute();
										}
										else
										{
											$numrows_fwd = $mail_db->prepare("SELECT goto FROM alias WHERE address=:address");
											$numrows_fwd->bindParam(':address', $from_email);
											$numrows_fwd->execute();
											$result = $numrows_fwd->fetch();
											$goto=rtrim($destination_email.",".$result['goto'],",");
											$sql_fwd = "UPDATE alias SET goto=:fw_address_vc, modified=NOW() WHERE address = :fw_address_vc2";
											$sql_fwd = $mail_db->prepare($sql_fwd);
											$sql_fwd->bindParam(':fw_address_vc',$goto );
											$sql_fwd->bindParam(':fw_address_vc2', $from_email);
											$sql_fwd->execute();
										}
										$split_des=array_filter(array_map('trim',explode(",",$goto)), function($value) { return $value !== ''; });
										foreach($split_des as $destination)
										{
										$sql_fwd = "INSERT INTO x_forwarders (fw_acc_fk,fw_address_vc,fw_destination_vc,fw_keepmessage_in,fw_created_ts) VALUES (:userid,:address,:destination,:keepmessage,:time)";
										$sql_fwd = $zdbh->prepare($sql_fwd);
										$keepmessage=0;
										$sql_fwd->bindParam(':userid', $userid);
										$sql_fwd->bindParam(':address', $from_email);
										$sql_fwd->bindParam(':destination', $destination);
										$sql_fwd->bindParam(':keepmessage', $keepmessage);
										$sql_fwd->bindParam(':time', time());
										$sql_fwd->execute();
										}	
                        						}
                						}
        						}
						fclose($file);
						}

						}	
			
						/* /////////////////////////////////////// Forwarder End ///////////////////////// */	
				}   
			}
			fclose($Domain_file);

///////////////////////////////////// SSL PRE INSTALLATION START /////////////////////////////////////////////////////////

echo "\n SSL PRE INSTALLATION START \n";
$apache_tls = $backupdir.$foldername."/apache_tls/";
echo "apache_tls $apache_tls \n";	
if(is_dir($apache_tls)){

        $tls_files = array_diff(scandir($apache_tls), array('.', '..'));
        if(!empty($tls_files)){
                foreach($tls_files as $domain){

                        $ssl_domain = trim($domain);
                        $ssl_sql="SELECT * FROM x_ssl WHERE ssl_doamin='".$ssl_domain."' AND ssl_delete is NULL";
                        $ssl_sql=$zdbh->prepare($ssl_sql);
                        $ssl_sql->execute();
                        $result = $ssl_sql->fetch();
                        $time = time();
                        if (!fs_director::CheckForEmptyValue(ctrl_options::GetSystemOption('server_ip'))) {
                                $ip_address = ctrl_options::GetSystemOption('server_ip');
                        } else {
                                $ip_address = trim(shell_exec("hostname -i"));
                        }
                        $ssl_status2 = 0;
                        if($result){
                                $ssl_sql = "UPDATE x_ssl SET ssl_delete='".$time."',ip_deleted='".$ip_address."' WHERE ssl_doamin='".$ssl_domain."'";
                                $ssl_sql = $zdbh->prepare($ssl_sql);
                                $ssl_sql->execute();
                        }

                        $ssl_sql = "INSERT INTO x_ssl (userid, ssl_email, ssl_doamin, ssl_created, ssl_status) VALUES ($userid,'".$email."','".$ssl_domain."','".$time."', '".$ssl_status2."')";
                        $ssl_sql = $zdbh->prepare($ssl_sql);
                        $ssl_sql->execute();
                }
        }
}

echo "SSL PRE INSTALLATION END\n";

///////////////////////////////////// SSL PRE INSTALLATION END /////////////////////////////////////////////////////////


///////////////////////////////////// PHP VERSION CHANGER START /////////////////////////////////////////////////////////

echo "PHP VERSION CHANGER START\n";

$check_cloudlinux = $backupdir.$foldername."/homedir/.cl.selector/defaults.cfg";

echo "check_cloudlinux $check_cloudlinux \n";

$phpVersionHandle = "cpanelphp";
$phpversion = "";
if(file_exists($check_cloudlinux)){
        
	$phpVersionHandle = "cloudlinux";

        $myfile = fopen($check_cloudlinux, "r");
        while(! feof($myfile)) {
                $line = fgets($myfile);
                if(strstr($line,"php =")){
                        $phpversion = trim($line);
                        $phpversion = str_replace("php = ","",$phpversion);
                        $phpversion = str_replace(".","",$phpversion);
                        $phpversion = "php".$phpversion;
                        break;
                }
        }
}

$vhost_sql = $zdbh->prepare("SELECT * FROM x_vhosts WHERE vh_deleted_ts is NULL AND vh_acc_fk=:userid");
$vhost_sql->bindParam(':userid', $userid);
$vhost_sql->execute();

while($vhost_data = $vhost_sql->fetch()) {

        $domain_id=$vhost_data['vh_id_pk'];
        $vh_directory_vc=$vhost_data['vh_directory_vc'];
        $vh_acc_fk=$vhost_data['vh_acc_fk'];
        $homedir = ctrl_options::GetSystemOption('hosted_dir');
        $phpuser = ctrl_users::GetUserDetail($vh_acc_fk);
	$phpuser = $phpuser['username'];
        $domain_dir = $homedir.$phpuser.$vh_directory_vc;

        if($phpVersionHandle == "cpanelphp"){

		$files = scandir($domain_dir);
		foreach($files as $file){
        		if(strstr($file,".htaccess-") && strstr($file,".orig")){
				$dom_htaccess = $domain_dir.'/'.$file;
				break;				
        		}
		}
                echo "dom_htaccess $dom_htaccess\n";
                if(file_exists($dom_htaccess)){
                        $dom_htacc = fopen($dom_htaccess,"r");
                        while(! feof($dom_htacc)) {
                                $line = fgets($dom_htacc);
                                $cpanel_handler = "application/x-httpd-ea-php";
                                if(strstr($line,$cpanel_handler)){
                                        $handle_line = trim($line);
                                        $handle_line_arr = explode(" ", $handle_line);
                                        foreach($handle_line_arr as $handle_data){
                                                if(strstr($handle_data,$cpanel_handler)){
                                                        $phpversion = str_replace($cpanel_handler,"",$handle_data);
                                                        $phpversion = "php".$phpversion;
                                                        echo "phpversion $phpversion";                                                                                                                 break;
                                                }
                                        }
                                break;
                                }
                        }
                }
        }
	echo "2 phpVersionHandle $phpVersionHandle phpversion $phpversion \n";

	if(empty(trim($phpversion))){
		$phpversion = 'php56';
	}

	echo "2 phpVersionHandle $phpVersionHandle phpversion $phpversion \n";

        $sql = "SELECT * FROM x_phpversion_upgrade WHERE x_client_id=:userid";
        $numrows = $zdbh->prepare($sql);
        $numrows->bindParam(':userid', $domain_id);
        $numrows->execute();
        if ($numrows->fetchColumn() != 0) {

                $sql_update = "Update x_phpversion_upgrade SET x_php_version=:x_php_version,x_flag=:x_flag,x_update_time=:x_update_time WHERE x_client_id=:userid ";
                $numrows1 = $zdbh->prepare($sql_update);
                $numrows1->bindParam(':userid',$domain_id );
                $numrows1->bindParam(':x_php_version', $phpversion);
                $time=time();
                $PHP_Flag="On";
                $numrows1->bindParam(':x_flag', $PHP_Flag);
                $numrows1->bindParam(':x_update_time', $time);
                $numrows1->execute();
		echo "\n UPDATE domain_id $domain_id phpversion $phpversion PHP_Flag $PHP_Flag time $time\n";
        }else
        {
                // Insert the PHP version 
                $sql_update ="INSERT INTO x_phpversion_upgrade (x_php_version,
                                                         x_flag,
                                                         x_update_time,
                                                         x_client_id) VALUES (
                                                         :x_php_version,
                                                         :x_flag,
                                                         :x_update_time,
                                                         :userid)";
                $numrows1 = $zdbh->prepare($sql_update);
                $numrows1->bindParam(':userid',$domain_id );
                $numrows1->bindParam(':x_php_version', $phpversion);
                $time=time();
                $PHP_Flag="On";
                $numrows1->bindParam(':x_flag', $PHP_Flag);
                $numrows1->bindParam(':x_update_time', $time);
                $numrows1->execute();
		echo "\nINSERT domain_id $domain_id phpversion $phpversion PHP_Flag $PHP_Flag time $time\n";
        }
}

echo "PHP VERSION CHANGER END\n";

///////////////////////////////////// PHP VERSION CHANGER END /////////////////////////////////////////////////////////

			$cmd_own=" chown -R vmail:mail /var/sentora/vmail/";
			exec($cmd_own);
			shell_exec('find /var/sentora/vmail/ -name "dovecot*" -exec rm -fv {} \;');
			
			/*  ///////////////////////////// Main Domain Upload and insert a DB End /////////////////////////// */ 


			/*  ///////////////////////////// Final Step Start /////////////////////////// */
	
                        /*  ///////////////////////////// Final Step Start /////////////////////////// */
                                
				$cmd_delfolder=" cd ".$backupdir." && rm -r ".$foldername."";
                                exec($cmd_delfolder);
                                $cmd_own=" chown -R ".$username.":".$username." ".$backupdir;
                                exec($cmd_own);
                                $cmd_own=" chown -R ".$username.":".$username." ".$vhost_path.$username."/public_html/";
                                passthru($cmd_own);
                                // type d -exec chmod 755 {} \;
                                $cmd_mod=" find ".$vhost_path.$username."/public_html"." -type f -exec chmod 644 {} \;";
                                passthru($cmd_mod);
                                $cmd_mod=" find ".$vhost_path.$username."/public_html"." -type d -exec chmod 755 {} \;";
                                passthru($cmd_mod);
                                if(trim($username) != ""){
                                        $cmd_own=" chown -R ".$username.":".$username." "."/tmp/".$username;
                                        passthru($cmd_own);
                                }

                        $date = new DateTime();
                        $date_time = $date->format('Y-m-d H:i:s');
                        $completed_file = $username." Account Successfully Migrated to OVI Panel on ".$date_time."\n";
                        //unlink($filepath);
		
			/*  ///////////////////////////// Final Step End /////////////////////////// */
			/* ///////////modsecurity update start here /////////// */

			$mod_sql = $zdbh->prepare("SELECT * FROM x_vhosts WHERE vh_deleted_ts is NULL");
			$mod_sql->execute();
			while($modrow = $mod_sql->fetch()) {
					$domain_id=$modrow['vh_id_pk'];
					$sql_mod = $zdbh->prepare("select * from x_modsecurity where x_domain_id='$domain_id'");
					$sql_mod->execute();
					$numrows = $sql_mod->fetchColumn();
					if($numrows > 0){
							echo "modsecurity already updated for this domain_id $domain_id\n";
					} else {
							$modsec_sql = $zdbh->prepare("INSERT INTO x_modsecurity (x_domain_id,x_mod_status) VALUES (:modid,'ModOn')");
							$modsec_sql->bindParam(':modid', $modrow['vh_id_pk']);
							$modsec_sql->execute();
					}
            		}

			/* /////////////// modsecurity ends start here //////////////////////// */
	}
	else
	{
		echo "File not found in temp directory!\n";
		return FALSE;
	}
	$SERVICE_EXEC=trim(shell_exec("whereis service | awk '{print $2}'"));
	shell_exec("$SERVICE_EXEC crond start");
	$PHP_EXEC=trim(shell_exec("whereis php | awk '{print $2}'"));
	exec("$PHP_EXEC /etc/sentora/panel/diskusage.php");
	if(count($inserted_domain_name)> 0)
	{
		for($i=0; $i < count($inserted_domain_name); $i++)
		{
			if(trim($inserted_domain_name[$i])!="")
			{
				$conf_file_path="/etc/sentora/configs/apache/domains/".trim($inserted_domain_name[$i]).".conf";
				if(file_exists($conf_file_path) && (!is_dir($conf_file_path)))
				unlink($conf_file_path);
                                $conf_file_path="/etc/sentora/configs/apache/domains/ssl_".trim($inserted_domain_name[$i]).".conf";
                                if(file_exists($conf_file_path) && (!is_dir($conf_file_path)))
                                unlink($conf_file_path);
			}
		}
	}
        $sql = $zdbh->prepare("UPDATE x_settings SET so_value_tx='true' WHERE so_name_vc='apache_changed'");
	$sql->execute();
	
	exec("$PHP_EXEC /etc/sentora/panel/bin/daemon.php");
	return TRUE;
}


?>

