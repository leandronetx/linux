#!/bin/bash
search_dir="/var/sentora/vmail"
for entry in "$search_dir"/*
do
  for Email_Dir in "$entry"/*
  do
        Email_Dir_Sieve=$Email_Dir"/sieve/"
        if [ -d "$Email_Dir_Sieve" ]; then
                Email_Dir_Sieve_File=$Email_Dir_Sieve"managesieve.sieve"
                if [ ! -f "$Email_Dir_Sieve_File" ]; then
                        touch $Email_Dir_Sieve_File
                        chown vmail:mail $Email_Dir_Sieve_File
                fi
                Sieve_Res=`grep 'Ovi_Spam' $Email_Dir_Sieve_File`
                if [ "$Sieve_Res" == "" ]; then
                        FileInto=`grep 'fileinto' $Email_Dir_Sieve_File`
                        if [ "$FileInto" == "" ]; then
                                echo 'require ["fileinto"];' > $Email_Dir_Sieve_File
                        fi
                        echo '# rule:[Ovi_Spam]' >> $Email_Dir_Sieve_File
                        echo 'if header :contains "subject" "[SPAM]" { fileinto "Junk"; }' >> $Email_Dir_Sieve_File
                fi
        else
                mkdir $Email_Dir_Sieve
                Email_Dir_Sieve_File=$Email_Dir_Sieve"managesieve.sieve"
                touch $Email_Dir_Sieve_File
                echo 'require ["fileinto"];' > $Email_Dir_Sieve_File
                echo '# rule:[Ovi_Spam]' >> $Email_Dir_Sieve_File
                echo 'if header :contains "subject" "[SPAM]" { fileinto "Junk"; }' >> $Email_Dir_Sieve_File
                chown -R vmail:mail $Email_Dir_Sieve
        fi
  done
done
