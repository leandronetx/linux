#!/bin/bash
restart_network()
{
        service network restart >>$null_path;
}

null_path="/dev/null";
if [ "$#" -lt 2 ]
then
        echo "";
else
        method_detail=$1;
        case $method_detail in
        addip)			
                IP=$2
		ALREADY=$(grep "IPADDR=$IP" -Rl /etc/sysconfig/network-scripts/ifcfg-*)
		if [ ! -z $ALREADY ]
		then
        		echo "ALREADY IP ADDED $ALREADY";exit;
		fi
		enth=$(ip route | grep -v default | head -n 1 | awk '{ print $3 }')
		orginal_net_file="/etc/sysconfig/network-scripts/ifcfg-$enth"
		IPADDR=$(cat $orginal_net_file | grep "^IPADDR=" | awk -F"=" '{ print $2 }') 
		echo "orginal_net_file $orginal_net_file"
		if [ -f $orginal_net_file ]
		then
			i=0
			while true
			do
				adaterFile=$orginal_net_file:$i	
				if [ ! -f $adaterFile ]
				then
					break;
				fi
				i=`expr $i + 1`		
			done
			cp -pr $orginal_net_file $adaterFile
			sed -i "s/NAME=$enth/NAME=$enth:$i/g" $adaterFile
			sed -i "s/DEVICE=$enth/DEVICE=$enth:$i/g" $adaterFile
			sed -i "s/IPADDR=$IPADDR/IPADDR=$IP/g" $adaterFile
		fi
                restart_network
                echo "1";
                ;;
        remvip)
		IP=$2
		orginal_net_dir="/etc/sysconfig/network-scripts/ifcfg-*"
		adaterFile=$(grep "IPADDR=$IP" -l /etc/sysconfig/network-scripts/ifcfg-*)
		if [ -f $adaterFile ]
		then
			rm -f $adaterFile
		fi  	
		restart_network
		;;
        *)
                echo "";
                ;;
        esac
fi
