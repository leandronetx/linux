yum -y install python34 python34-pip python34-devel python34-virtualenv python36 python36-pip python36-devel python36-virtualenv
wget -O python36u-mod_wsgi-4.5.17-1.ius.centos7.x86_64.rpm http://d.ovipanel.in/Version3.7/python/python36u-mod_wsgi-4.5.17-1.ius.centos7.x86_64.rpm
rpm -Uvh python36u-mod_wsgi-4.5.17-1.ius.centos7.x86_64.rpm
yum -y install mod_wsgi
wget -O pythonenable.zip http://d.ovipanel.in/Version3.7/python/pythonenable.zip
unzip -o pythonenable.zip
php pythonenable.php
mkdir -p /etc/sentora/configs/apache/python/
