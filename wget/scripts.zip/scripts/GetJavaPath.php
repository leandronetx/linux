<?php
    	include_once("/etc/sentora/panel/cnf/db.php");
    	include('/etc/sentora/panel/dryden/db/driver.class.php');
	$zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
	$zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT x_file_path FROM x_java_version";
	$numrows = $zdbh->prepare($sql);
        $result = $numrows->execute();
        if($result !==FALSE) {
            $return = trim($numrows->fetch()[0]);
        } else {
            $return = "table doesnot exist";
        }
        echo $return;
	exit;
?>
