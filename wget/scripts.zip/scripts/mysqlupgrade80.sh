#!/usr/bin/env bash
MYSQL=`whereis mysql | awk '{print $2}'`
server_version()
{
        echo `${MYSQL} -e "SELECT VERSION()"`
}
##############################################
# Checks if the MySQL server version is >= 5 #
##############################################
vercomp () {
   if [[ $1 == $2 ]]
   then
       return 0
   fi
   local IFS=.
   local i ver1=($1) ver2=($2)
   # fill empty fields in ver1 with zeros
   for ((i=${#ver1[@]}; i<${#ver2[@]}; i++))
   do
       ver1[i]=0
   done
   for ((i=0; i<${#ver1[@]}; i++))
   do
       if [[ -z ${ver2[i]} ]]
       then
           # fill empty fields in ver2 with zeros
           ver2[i]=0
       fi
       if ((10#${ver1[i]} > 10#${ver2[i]}))
       then
           return 1
       fi
       if ((10#${ver1[i]} < 10#${ver2[i]}))
       then
           return 2
       fi
   done
   return 0
}
echo "==========================================="
echo "   Mysql Version Upgrade   "
echo "==========================================="
echo "  1. Mysql 5.7 "
echo "  2. Mysql 8.0 "
echo "==========================================="
echo -e "Enter your option (1/2 ) >"
read mysql_version
sv=`server_version | awk '{print $2}'`
    
        mysql_up_yn=1
    echo 'show databases;' | mysql | grep -v ^information_schema$ | grep -v ^mysql$ | grep -v ^sys$ | grep -v ^performance_schema$ | awk '{if(NR>1)print}' | xargs mysqldump --databases > /root/alldb_before_ugrade.sql
    if [ "$?" -ne 0 ]
    then
        echo "==========================================="
        echo "   Mysql dump seems like failed or no database to dump. Do you want to proceed with upgrade now "
        echo "==========================================="
        echo "  1. Yes"
        echo "  2. No "
        echo "==========================================="
        echo -e "Enter your option (1/2 ) >"
        read mysql_up_yn
    fi

    if [ "$mysql_up_yn" != "1" ]
    then
        echo "exiting without install" ;
    fi
        echo "mysql dump start successfully"
        cp /etc/postfix/main.cf /root/postfix_main_for_bk.cf
        cp /etc/postfix/master.cf /root/postfix_master_for_bk.cf
        cp /etc/lighttpd/lighttpd.conf /root/lighttpd.conf_for_bk.cf
        yes | cp /etc/my.cnf /root/my.cnf_preserve
        service mysqld stop
        case "$mysql_version" in
        1)
                vercomp $sv 5.7
                case $? in
                0) op='='
                echo "Already Mysql 5.7 has upgraded. kindly check it"
                service mysqld start
                exit
                ;;
                2) op='<'
                echo "Less than Mysql Version 5.7 ... So continue the process.."      
                ;;
                1) op='>'
                echo "Already Mysql 5.7 has upgraded. kindly check it"
                service mysqld start   
                exit 
                ;;
                esac
            yum -y remove mysql-community-server
            yum -y remove mysql-community-common
            yum -y remove mysql-community-release
            yum -y localinstall https://dev.mysql.com/get/mysql57-community-release-el7-11.noarch.rpm
        ;;
        2)
                vercomp $sv 8.0
                case $? in
                0) op='='
                echo "Already Mysql 8.0 has upgraded. kindly check it"
                service mysqld start
                exit
                ;;
                2) op='<'
                echo "Less than Mysql Version 8.0 ... So continue the process.."      
                ;;
                1) op='>'
                echo "Already Mysql 8.0 has upgraded. kindly check it"
                service mysqld start      
                exit 
                ;;
                esac
                vercomp $sv 5.7
                case $? in
                0) op='='
                echo "Equal to, append one line" ;
                ;;
                2) op='<'
                echo "Less than Mysql Version 5.7 ...kindly upgrade mysqll as 5.7 after that try to upgrade 8.0"      
                service mysqld start
                exit
                ;;
                1) op='>'
                echo "Greater than Mysql Version 5.7 so continue the process"
                ;;
                esac

                                yum -y remove mysql-community-server
                                yum -y remove mysql-community-common
                                yum -y remove mysql-community-release
                                yum -y remove mysql57-community-server
                                yum -y remove mysql57-community-common
                                yum -y remove mysql57-community-release
                                yum -y localinstall https://dev.mysql.com/get/mysql80-community-release-el7-1.noarch.rpm
        ;;
        *) 
            echo -e "You have entered wrong option. Try aftesometime"
            exit
        ;;
        esac
                mv /var/lib/mysql /var/lib/mysql_HOLD
                yum -y install mysql-community-server
                yum -y install mysql-community-common
                yum -y install postfix postfix-perl-scripts  proftpd-mysql redhat-lsb-core perl-DBD-MySQL dovecot-mysql lighttpd lighttpd-fastcgi
                mv /etc/my.cnf /etc/my.cnf_BK_BEFORE_CHANGE

        if [[ $mysql_version == 2 ]];
        then  

                echo "[mysqld]" >> /etc/my.cnf
                echo "skip-grant-tables" >> /etc/my.cnf
                echo "skip-networking" >> /etc/my.cnf
                echo "collation-server = utf8mb4_unicode_ci" >> /etc/my.cnf
                echo "character-set-server = UTF8MB4" >> /etc/my.cnf
                echo "default_authentication_plugin= mysql_native_password" >> /etc/my.cnf
                echo "general-log = 0" >> /etc/my.cnf
                echo "datadir=/var/lib/mysql" >> /etc/my.cnf
                echo "socket=/var/lib/mysql/mysql.sock" >> /etc/my.cnf
                echo "user=mysql" >> /etc/my.cnf
                echo "# Disabling symbolic-links is recommended to prevent assorted security risks" >> /etc/my.cnf
                echo "symbolic-links=0" >> /etc/my.cnf
                echo "#max_connections=150" >> /etc/my.cnf
                echo "port=3306" >> /etc/my.cnf
                echo "sql_mode=NO_ENGINE_SUBSTITUTION" >> /etc/my.cnf
                echo "[mysqld_safe]" >> /etc/my.cnf
                echo "#log-error=/var/log/mysqld.log" >> /etc/my.cnf
                echo "pid-file=/var/run/mysqld/mysqld.pid" >> /etc/my.cnf

        fi
                service mysqld restart

                        orgpass=$(grep "password=" .my.cnf | awk -F'=' {'print $2'} | tr -d \'\")
                        mysql --execute="flush privileges; SET GLOBAL validate_password.policy=LOW; ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$orgpass'; flush privileges;"
                        sed -i '/skip-grant-tables/d' /etc/my.cnf
                        sed -i '/skip-networking/d' /etc/my.cnf

        mysql < /root/alldb_before_ugrade.sql
        mv /etc/postfix/main.cf  /etc/postfix/main.cf_After_Upgrade
        mv /etc/postfix/master.cf /etc/postfix/master.cf_After_Upgrade
        cp /root/postfix_main_for_bk.cf  /etc/postfix/main.cf
        cp /root/postfix_master_for_bk.cf /etc/postfix/master.cf
        rm -frv /usr/sbin/sendmail
        ln /usr/sbin/sendmail.postfix /usr/sbin/sendmail
        yum -y install lighttpd lighttpd-fastcgi
        mv /etc/lighttpd/lighttpd.conf /etc/lighttpd/lighttpd.conf_After_Upgrade
        cp /root/lighttpd.conf_for_bk.cf  /etc/lighttpd/lighttpd.conf

        service mysqld restart
        service lighttpd restart
        service proftpd restart
        service postfix restart
        service dovecot restart
        service spamassassin restart
        service lighttpd restart
        echo "mysql dump Ended successfully"
        echo "=========================================================="
        echo "For Reset mysqld password follow below steps"
        echo "1. Add below lines on /etc/my.cnf files"
        echo "  skip-grant-tables" 
        echo "  skip-networking"
        echo "2. Run command ==> service mysqld restart"
        echo "3. Run command ==> mysql"
        echo "4. Run command ==> use mysql;"
        echo "5. Run command ==> flush privileges;"
        echo "6. Run command ==> SET GLOBAL validate_password.policy=LOW; ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'YOURMYSQLPASSWORD';" 
        echo "7. Run command ==> flush privileges;"
        echo "8. Run command ==> exit;"
        echo "9. At last remove the two line added in skip-grant-tables,skip-networking in /etc/my.cnf"
        echo "10. Run command ==> service mysqld restart"
