#!/bin/bash
rm -rf /etc/sentora/panel/fastcgi/*.socket
