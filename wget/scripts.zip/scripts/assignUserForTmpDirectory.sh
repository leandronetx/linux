mysql --socket="/usr/local/mysql/mysql.sock" -Ne "select ac_user_vc from sentora_core.x_accounts where ac_deleted_ts IS NULL AND ac_id_pk!=1;" | while read ac_user_vc; do
DIRECTORY="/tmp/$ac_user_vc/"
if [ -d "$DIRECTORY" ]; then
  # Control will enter here if $DIRECTORY exists.i
GETUSER=`ls -ld $DIRECTORY | awk '{print $3}'`
GETGROUP=`ls -ld $DIRECTORY | awk '{print $4}'`
if [[ "$GETUSER"  != "$ac_user_vc" || "$GETGROUP" != "$ac_user_vc" ]];
then 
	echo "need to change the permission - $DIRECTORY"
	chown $ac_user_vc:$ac_user_vc -R $DIRECTORY
else
	echo "Already updated properly - $DIRECTORY"
fi
fi
done
