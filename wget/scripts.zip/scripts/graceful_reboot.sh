VER=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
if  [[ "$VER" = "7" ]]; then
		systemctl stop crond.service
		systemctl stop httpd.service
		systemctl stop rsyslog.service
		systemctl stop mysqld.service
		systemctl stop named.service
		systemctl stop postfix.service
		systemctl stop dovecot.service
		systemctl stop spamd.service
		systemctl stop csf.service
		systemctl stop lfd.service
		systemctl stop opendkim.service
		systemctl stop varnish.service
		systemctl stop proftpd.service
		systemctl stop lighttpd.service
else
		/etc/init.d/crond stop
		/etc/init.d/httpd stop
		/etc/init.d/rsyslog stop
		/etc/init.d/mysqld stop
		/etc/init.d/named stop
		/etc/init.d/postfix stop
		/etc/init.d/dovecot stop
		/etc/init.d/spamd stop
		/etc/init.d/csf stop
		/etc/init.d/lfd stop
		/etc/init.d/opendkim stop
		/etc/init.d/varnish stop
		/etc/init.d/proftpd stop
		/etc/init.d/lighttpd stop
fi
REBOOT_CMD=`whereis reboot | awk '{print $2}'`
`$REBOOT_CMD`
