#!/bin/bash
if [ "$#" == 2 ]; then
        if [ "$1" == "--cf" ]; then
                username=$2
                CHMOD_SERV=`whereis chmod | awk '{print $2}'`
                EXPLIST=("adm" "lp" "sync" "shutdown" "halt" "mail" "operator" "games" "ftp" "nobody" "systemd-network" "dbus" "polkitd" "sshd" "postfix" "shellinabox" "mysql" "vmail" "vacation" "dovecot" "dovenull" "apache" "saslauth" "named" "webalizer" "clamupdate" "lighttpd" "clamscan" "opendkim" "nginx" "spamd" "autoresponse" "csf" "varnishlog" "varnish" "ovipanel" "vnstat" "chrony")
                for e in "${exlist[@]}"
                do
                        if [[ "$e" == $username ]]
                        then
                                echo "username is wrong params";exit;
                        fi
                done
                CRONFILE="/var/spool/cron/$username"
                if [ -f $CRONFILE ]
                then
                        rm -f /var/spool/cron/$username
                fi
                LIGHT_CONF="/etc/lighttpd/include-all-user-socket.conf"
                USER_SOCK="$username-socket-include.conf"
                FAST_CGI="/etc/sentora/panel/fastcgi/$username-startup.sh"
                FAST_CGI_SOC="/etc/sentora/panel/fastcgi/$username.socket"
                FAST_CGI_FMSOC="/etc/sentora/panel/fastcgi/$username-fm.socket"
                USER_SOCK_CONF="/etc/lighttpd/$USER_SOCK"
                $CHMOD_SERV +x /usr/bin/setso
                HOST_DIR=`setso --show hosted_dir`
                USER_HOST="$HOST_DIR$username"
                echo "USER_HOST $USER_HOST"
                echo "FAST_CGI_FMSOC $FAST_CGI_FMSOC USER_SOCK_CONF $USER_SOCK_CONF"
                socket_added_check=`grep -ni "$USER_SOCK" $LIGHT_CONF | head -1 | awk -F":" '{print $1}'`

                if [ -f $FAST_CGI ]
                then
                        rm -f $FAST_CGI
                fi

                if [ -S $FAST_CGI_SOC ]
                then                        
                        rm -f $FAST_CGI_SOC
                fi
               
                if [ -S $FAST_CGI_FMSOC ]
                then         
                        rm -f $FAST_CGI_FMSOC
                fi

                if [ "$socket_added_check" != "" ]; then
                        sed -i -e "${socket_added_check}d" $LIGHT_CONF
                fi

                if [ -f $USER_SOCK_CONF ]
                then
                        rm -f $USER_SOCK_CONF 
                fi
                if [ -d $USER_HOST ]
                then
                        rm -rf $USER_HOST
                fi
        fi
else
        echo "Invalid Parameters"
fi
