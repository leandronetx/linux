#!/bin/bash
if [ "$#" -eq 2 ]; then
	USERNAME=$1
	HOSTED_DIR=$2
	if [ "$USERNAME" != "" -a "$USERNAME" != "root" -a "$USERNAME" != "etc" -a "$USERNAME" != "/" -a "$USERNAME" != "home" ]; then
		mkdir -p $HOSTED_DIR$USERNAME/public_html
		mkdir -p $HOSTED_DIR$USERNAME/backups
		chmod 0711 $HOSTED_DIR$USERNAME
		#chmod 0755 $HOSTED_DIR$USERNAME/public_html
		chmod +x /usr/bin/setso
		STATIC_DIR=`setso --show static_dir`
		SENTORA_ROOT=`setso --show sentora_root`
		CP_SER=`whereis cp | awk '{ print $2 }'`
		DATE_TIME=`date "+%Y.%m.%d-%H.%M.%S"`
		mkdir -p $HOSTED_DIR$USERNAME/public_html/_errorpages
		$CP_SER -r "$STATIC_DIR/errorpages/"* $HOSTED_DIR$USERNAME/public_html/_errorpages/
		if [ ! -f $HOSTED_DIR$USERNAME/public_html/index.php ]
		then
			$CP_SER $STATIC_DIR"pages/welcome.html" $HOSTED_DIR$USERNAME/public_html/index.php
		fi
		#$CP_SER $SENTORA_ROOT"etc/styles/CstyleX-master/images/favicon.ico" $HOSTED_DIR$USERNAME/public_html/favicon.ico
		$CP_SER $SENTORA_ROOT"etc/styles/CstyleX-master/images/ovi-logo.png" $HOSTED_DIR$USERNAME/public_html/ovi-logo.png
		$CP_SER /etc/sentora/panel/fastcgi/.startup.txt /etc/sentora/panel/fastcgi/$USERNAME-startup.sh
		sed -i 's/OVIPANEL_FASTCGI_SOCKET_USER/'$USERNAME'/g' /etc/sentora/panel/fastcgi/$USERNAME-startup.sh
		SH_SERV=`whereis sh | awk '{ print $2 }'`
		SOCKET_FILE="/etc/sentora/panel/fastcgi/$USERNAME.socket"
		if [ -f $SOCKET_FILE ]; then
			rm -f /etc/sentora/panel/fastcgi/$USERNAME.socket
		fi
		#$SH_SERV /etc/sentora/panel/fastcgi/$USERNAME-startup.sh
		#chmod 777 $SOCKET_FILE
		#LIGHTTPD_CONF_FILE="/etc/lighttpd/lighttpd.conf"
		
		LIGHTTPD_CONF_FILE="/etc/lighttpd/include-all-user-socket.conf"
		LIGHTTPD_SOCK_CONF="/etc/lighttpd/$USERNAME-socket-include.conf"
                if [ -f $LIGHTTPD_SOCK_CONF ]
                then
                        mv "$LIGHTTPD_SOCK_CONF" "$LIGHTTPD_SOCK_CONF-$DATE_TIME"
                fi
		$CP_SER /etc/sentora/panel/fastcgi/.lighttpd_socket_conf.txt $LIGHTTPD_SOCK_CONF
		sed -i 's/OVIPANEL_FASTCGI_SOCKET_USER/'$USERNAME'/g' $LIGHTTPD_SOCK_CONF
		USER_SOCK="$USERNAME-socket-include.conf"
                
		#socket_added_check=`grep -ni "$USER_SOCK" $LIGHTTPD_CONF_FILE | head -1 | awk -F":" '{print $1}'`
                #if [ "$socket_added_check" != "" ]; then
                #echo "No need to write a configuration again" >/dev/null 2>&1
                #else
                #echo 'include "'$USERNAME'-socket-include.conf"' >> $LIGHTTPD_CONF_FILE
                #fi
		touch $LIGHTTPD_CONF_FILE
		user_list=`echo "select ac_user_vc from x_accounts  where ac_deleted_ts IS NULL and ac_user_vc != 'zadmin' order by ac_user_vc" | mysql --socket="/usr/local/mysql/mysql.sock" sentora_core --skip-column-names | awk '{ print length, $0 }' | sort -n -s | cut -d" " -f2-`
		: > $LIGHTTPD_CONF_FILE
		for i in $user_list
		do
		        echo "include \"$i-socket-include.conf\"" >> $LIGHTTPD_CONF_FILE
        	        sed -i 's/OVIPANEL_FASTCGI_SOCKET_USER/'$i'/g' $LIGHTTPD_SOCK_CONF
			if [ ! -f $LIGHTTPD_SOCK_CONF ]; then
			LIGHTTPD_SOCK_CONF="/etc/lighttpd/$i-socket-include.conf"
                        yes | $CP_SER /etc/sentora/panel/fastcgi/.lighttpd_socket_conf.txt $LIGHTTPD_SOCK_CONF
			fi	
		done
		chown -R $USERNAME:$USERNAME $HOSTED_DIR$USERNAME/
		find $HOSTED_DIR$USERNAME/* -type d -exec chmod 755 {} \;
		find $HOSTED_DIR$USERNAME/* -type f -exec chmod 644 {} \;
		mkdir -p /etc/sentora/configs/apache/fcgi-config/$USERNAME
		cd /etc/sentora/configs/apache/fcgi-config/$USERNAME
		WHERIS_MYSQL=`whereis mysql | awk '{print $2}'`
		if ! $WHERIS_MYSQL --socket="/usr/local/mysql/mysql.sock" -e 'use sentora_core'; then
			touch php.ini
			echo 'upload_max_filesize=512M' > php.ini
			echo 'post_max_size=512M' >> php.ini
			echo 'max_execution_time=300' >> php.ini
			echo 'max_input_time=600' >> php.ini
			echo 'memory_limit=128M' >> php.ini
			echo 'file_uploads=On' >> php.ini
			echo 'max_input_vars=1000' >> php.ini
			echo 'short_open_tag=Off' >> php.ini
			echo 'display_errors=Off' >> php.ini
		else
			myvariable=$($WHERIS_MYSQL --socket='/usr/local/mysql/mysql.sock' sentora_core -s -N -e "select x_value from x_php_config where x_clearname='upload_max_filesize' AND x_old_value='1'")
			if [ -z "$myvariable" ];
			then
			echo 'upload_max_filesize=512M' > php.ini
			else
			echo "upload_max_filesize="$myvariable"M" > php.ini
			fi
                        myvariable=$($WHERIS_MYSQL --socket='/usr/local/mysql/mysql.sock' sentora_core -s -N -e "select x_value from x_php_config where x_clearname='post_max_size' AND x_old_value='1'")
                        if [ -z "$myvariable" ];
                        then
                        echo 'post_max_size=512M' >> php.ini
                        else
                        echo "post_max_size="$myvariable"M" >> php.ini
                        fi
                        myvariable=$($WHERIS_MYSQL --socket='/usr/local/mysql/mysql.sock' sentora_core -s -N -e "select x_value from x_php_config where x_clearname='max_execution_time' AND x_old_value='1'")
                        if [ -z "$myvariable" ];
                        then
                        echo 'max_execution_time=300' >> php.ini
                        else
                        echo "max_execution_time="$myvariable >> php.ini
                        fi
                        myvariable=$($WHERIS_MYSQL --socket='/usr/local/mysql/mysql.sock' sentora_core -s -N -e "select x_value from x_php_config where x_clearname='max_input_time' AND x_old_value='1'")
                        if [ -z "$myvariable" ];
                        then
                        echo 'max_input_time=600' >> php.ini
                        else
                        echo "max_input_time="$myvariable >> php.ini
                        fi
                        myvariable=$($WHERIS_MYSQL --socket='/usr/local/mysql/mysql.sock' sentora_core -s -N -e "select x_value from x_php_config where x_clearname='memory_limit' AND x_old_value='1'")
                        if [ -z "$myvariable" ];
                        then
                        echo 'memory_limit=512M' >> php.ini
			#else if [ "$myvariable" == "-1" ];
			#then 
			#echo 'memory_limit=-1' >> php.ini
                        else
                        echo "memory_limit="$myvariable"M" >> php.ini
                        fi
                        myvariable=$($WHERIS_MYSQL --socket='/usr/local/mysql/mysql.sock' sentora_core -s -N -e "select x_value from x_php_config where x_clearname='file_uploads' AND x_old_value='1'")
                        if [ -z "$myvariable" ];
                        then
                        echo 'file_uploads=On' >> php.ini
                        else
                        echo "file_uploads="$myvariable >> php.ini
                        fi
                        myvariable=$($WHERIS_MYSQL --socket='/usr/local/mysql/mysql.sock' sentora_core -s -N -e "select x_value from x_php_config where x_clearname='max_input_vars' AND x_old_value='1'")
                        if [ -z "$myvariable" ];
                        then
                        echo 'max_input_vars=1000' >> php.ini
                        else
                        echo "max_input_vars="$myvariable >> php.ini
                        fi
                        myvariable=$($WHERIS_MYSQL --socket='/usr/local/mysql/mysql.sock' sentora_core -s -N -e "select x_value from x_php_config where x_clearname='short_open_tag' AND x_old_value='1'")
                        if [ -z "$myvariable" ];
                        then
                        echo 'short_open_tag=Off' >> php.ini
                        else
                        echo "short_open_tag="$myvariable >> php.ini
                        fi
			myvariable=$($WHERIS_MYSQL --socket='/usr/local/mysql/mysql.sock' sentora_core -s -N -e "select x_value from x_php_config where x_clearname='display_errors' AND x_old_value='1'")
                        if [ -z "$myvariable" ];
                        then
                        echo 'display_errors=Off' >> php.ini
			else
                        echo "display_errors="$myvariable >> php.ini
                        fi
		fi
		echo 'expose_php = Off' >> php.ini
	        echo 'enable_dl = Off' >> php.ini
		echo 'open_basedir = "'$HOSTED_DIR$USERNAME':/var/log/spamavoid/:/tmp/:/var/lib/php/session/"' >> php.ini
                echo 'auto_prepend_file = "/var/log/spamavoid/php_execution_block.php"' >> php.ini
		cp /usr/local/bin/phpsendmail.php phpsendmail.php
		chown $USERNAME:$USERNAME phpsendmail.php
		chmod 700 phpsendmail.php 
		#/etc/sentora/configs/apache/fcgi-config/$USERNAME  
                echo "sendmail_path = /etc/sentora/configs/apache/fcgi-config/$USERNAME/phpsendmail.php" >> php.ini
		$CP_SER -r /etc/sentora/panel/etc/apps/rainloop/data/ /etc/sentora/panel/etc/apps/rainloop/$USERNAME/
		chown -R $USERNAME:$USERNAME /etc/sentora/panel/etc/apps/rainloop/$USERNAME/
		mkdir -p /tmp/$USERNAME/
		chown -R $USERNAME:$USERNAME /tmp/$USERNAME/
		service lighttpd force-reload
		echo "Account Created Successfully"
	else
		echo "Invalid Username"
	fi
else
	echo "Invalid Parameters "
fi
