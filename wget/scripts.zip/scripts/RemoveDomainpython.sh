if [ "$#" == 2 ]
then
	username=$1 
	domain_name=$2
	#DEL_LINE=$username" => "$domain_name" => "
	python_conf="/etc/sentora/configs/python_domain"
        filename=$(echo $domain_name | sed 's/\*./wildcard_/g')
        #DEL_LINE=$username" => "$filename" => "
	DEL_LINE=$(echo $username" => "$domain_name" => " | sed 's/*/\\*/g' )
	echo "$DEL_LINE"
	sed -i -e "/$DEL_LINE/d" $python_conf	
	conf=".conf"
	ssl="ssl_"
	#sed -i '/IncludeOptional/c\#IncludeOptional' /etc/sentora/configs/apache/domains/$domain_name$conf
	#sed -i '/WSGIScriptAlias/c\#WSGIScriptAlias' /etc/sentora/configs/apache/domains/$domain_name$conf
	#sed -i '/WSGIDaemonProcess/c\#WSGIDaemonProcess' /etc/sentora/configs/apache/domains/$domain_name$conf
	#sed -i '/WSGIScriptAlias/c\#WSGIScriptAlias' /etc/sentora/configs/apache/domains/$ssl$domain_name$conf
	#sed -i '/WSGIDaemonProcess/c\#WSGIDaemonProcess' /etc/sentora/configs/apache/domains/$ssl$domain_name$conf
	#sed -i '/IncludeOptional/c\#IncludeOptional' /etc/sentora/configs/apache/domains/$ssl$domain_name$conf
	conf=".conf"
	ssl="ssl_"
	python_file_conf="/etc/sentora/configs/apache/python/$filename$conf"
	ssl_python_file_conf="/etc/sentora/configs/apache/python/ssl_$filename$conf"
	domain_ssl_conf_path="/etc/sentora/configs/apache/domains/$ssl$filename$conf"
	domain_conf_path="/etc/sentora/configs/apache/domains/$filename$conf"
        echo '' > $python_file_conf
	echo '' > $ssl_python_file_conf
        DEL_LINE=$(echo "IncludeOptional $python_file_conf" | sed 's/\//\\\//g')
        SSL_DEL_LINE=$(echo "IncludeOptional $ssl_python_file_conf" | sed 's/\//\\\//g')
        sed -i -e "/$DEL_LINE/d" $domain_conf_path
        sed -i -e "/$SSL_DEL_LINE/d" $domain_ssl_conf_path
	SERVICE_PATH=`whereis service | awk '{print $2}'`
	`$SERVICE_PATH httpd reload`
fi
