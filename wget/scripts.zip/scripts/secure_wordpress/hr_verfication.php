<html>
<head>
<link rel="stylesheet" href="./wp-admin/load-styles.php?c=1&amp;dir=ltr&amp;load%5B%5D=dashicons,buttons,forms,l10n,login&amp;ver=4.9.6" type="text/css" media="all">
<script src="https://www.google.com/recaptcha/api.js"></script>
</head>

<body class='login login-action-login wp-core-ui  locale-en-us'>
<div id="login" style="width: 780px;font-size: 15px;">
<h1><a href="https://wordpress.org/" title="Powered by WordPress" tabindex="-1">Powered by WordPress</a></h1>
<?php
session_start();
$CUR_DIR = getcwd();
echo "<h1 style='text-align: left;color: #0073aa;font-size: 26px;'>Message from HostingRaja security team:</h1> <br><br>";
echo "<h2 style='font-size: 15px;'>Being a No.1 hosting company in India, It is our responsibility to take maximum effort to secure your website.<h2><br>";

$pass_rest_path = $_SESSION["passreset"];
$login_path = $_SESSION["log_admin"];

if( isset($_SESSION["pass"]) ){
    echo "<p style='font-size: 15px;'>*) Your password is weak and it is very easy to hack. Please click on change password below. </p><br>";
?>
<p class="submit">
<button style="float:left;margin: 0px 3px;" class="button button-primary button-large" id="wp-submit"><a style="color: white;text-decoration: none;" href="<?php echo $pass_rest_path ;?>" >CHANGE PASSWORD</a> </button>
<button style="float:left;margin: 0px 3px;" class="button button-primary button-large" id="wp-submit"><a style="color: white;text-decoration: none;" href="<?php echo $login_path ;?>" >Continue Login</a></button>
</p>
<?php

}else if( $_SESSION["admin"] == 'admin' ){

$id = $_SESSION["user_id"];
$user_nicename = $_SESSION["user_nicename"];
$user_email = $_SESSION["user_email"];

if ( $user_nicename != ''){

    $username = $user_nicename."_admin_".rand(100,999);

}else if($user_email != ''){

    $user_email = substr($user_email,0,4);
    $username = $user_email."_admin_".rand(100,999);

}else{
    $username = substr($_SERVER['HTTP_HOST'],0,4)."_admin_".rand(100,999);
}
?>
<div id="login" style="width: 780px;font-size: 15px;">
Your admin username is 'admin', Which is not secure. You can add few letters prefix to it such as
        <li style="padding-top: 10px;">rahul_admin</li>
        <li>modi_admin </li>
        <li>raja_admin</li>
</div>

<style>
input[type="submit"], input[type="button"] {
    border: 1px solid #ccc;
    background-color: #0073aa;
    color: #fff;
    font-size: 19px;
    padding: 4px 25px;
    cursor: pointer;
}
.formelm {
    margin-bottom: 40px;
}
#login {
    padding: 15px 0 !important;
}
p.msg {
    font-size: 18px;
    padding-top: 10px;
}
</style>
<?php
if ( file_exists($CUR_DIR.'/wp-load.php') )
{
?>
<form method='post' action="<?php echo $_SERVER['PHP_SELF']; ?>" id="searchForm" name="searchForm">
    <p style="font-size: 18px;margin-bottom: 25px;">Please click yes,if you want to change your admin login username</p>
    <tr>
    <div class="formelm"><label id="jform_captcha-lbl" class="hasTip" style="color: #000; font-weight: bold;float: left; padding-top: 10px;" title="" for="jform_captcha"> Enter the Captcha :<span style="color: #cc0000; margin-right: 50px;">*</span> </label> <input id="captcha" class="inputbox required validate-numeric" style="width: 20%; float: left;" type="text" name="captcha" maxlength="4"> <img src="captcha_code_file.php" border="0" style="padding-left: 10px; padding-top: 10px;"></div>
    </tr>
    <tr>
        <div style="text-align: center;">
        <input type="submit" value="YES"  name='submit'/>
        <a href="/wp-login.php"><input type="button" value="NO" name='button' /></a>
        </div>
    </tr>
</form>
<?php

if(isset($_POST['submit'])){
    if(isset($_POST) & !empty($_POST)){
        if($_POST['captcha'] == $_SESSION['captcha']){
                define( 'WP_USE_THEMES', false );
                require( $CUR_DIR .'/wp-load.php' );
                global $wpdb;
                $results = $wpdb->get_results( "UPDATE {$wpdb->prefix}users SET `user_login` = '$username' WHERE ID = '$id'" );
            ?> <p class="msg">Important: Please make a note of your new admin name <span style="color: #de5327"><?php echo $username ?></span></p> <?php
            ?><p class="submit">
                <button style="float:left;margin: 0px 3px;" class="button button-primary button-large" id="wp-submit"><a style="color: white;text-decoration: none;" href="<?php echo $login_path ;?>" >Continue Login</a></button>
            </p><?php
        } else {
            ?> <p style="color: #ff0000; font-size: 20px;">Please enter the captcha correctly.</p><?php
        }
    }
}
}else{
?>
<button style="float:left;margin: 0px 3px;" class="button button-primary button-large" id="wp-submit"><a style="color: white;text-decoration: none;" href="<?php echo $login_path ;?>" >Continue Login</a></button>
<?php
}
//print_r( $results );
    #echo "<p>Your admin username is 'admin', Which is not secure. You can add few letters prefix to it such as rahul_admin modi_admin raja_admin</p>";

}
?>

</div>
</body>

</html>

