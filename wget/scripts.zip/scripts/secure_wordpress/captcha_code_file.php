<?php
session_start();
$captcha_num = rand(1000, 9999);
$_SESSION['captcha'] = $captcha_num;

// Create a 100*30 image
$im = imagecreate(40, 20);

// White background and blue text
$bg = imagecolorallocate($im, 169, 169, 169);
$textcolor = imagecolorallocate($im, 0, 0, 0);

// Write the string at the top left
imagestring($im, 5, 0, 0, $captcha_num, $textcolor);

// Output the image
header('Content-type: image/png');

imagepng($im);
imagedestroy($im);
?>

