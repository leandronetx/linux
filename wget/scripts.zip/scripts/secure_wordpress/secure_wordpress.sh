#!/usr/bin/env bash
function version { echo "$@" | awk -F. '{ printf("%d%03d%03d%03d\n", $1,$2,$3,$4); }'; }
cd /scripts/
FILE_NAME='WP_CONFIG_FILE_LIST.txt'
FILEPATHS=`find /home -name '*wp-config.php' > $FILE_NAME`
while read -r FILE_PATH
do
        if [ -f $FILE_PATH ]
        then
                DIR=`dirname $FILE_PATH`
                #wordpressversoin=`grep "wp_version =" $DIR/wp-includes/version.php | awk '{print $3}' | sed "s/'//g" | sed "s/;//g"`
                CWPV=`grep "wp_version =" $DIR/wp-includes/version.php | awk '{print $3}' | sed "s/'//g" | sed "s/;//g"`
                VAR='4.8.0'
                if [ $(version $VAR) -ge $(version $CWPV) ]; then
                        checkversion=`grep 'hr_verfication' $DIR/wp-includes/version.php | tail -1 | awk '{print $4}'`
                        #USER=`cut -d/ -f3 <<< "${DIR}"`
                        check=`grep 'hr_verfication' $DIR/wp-includes/functions.php | head -n 1`
                        if [[ ! $check ]]
                        then
                                cat /scripts/secure_wordpress/secure_wp_func.txt >> $DIR/wp-includes/functions.php
                                cp -p /scripts/secure_wordpress/hr_verfication.php $DIR/hr_verfication.php
                                cp -p /scripts/secure_wordpress/captcha_code_file.php $DIR/captcha_code_file.php
                                chmod 644 $DIR/hr_verfication.php $DIR/captcha_code_file.php
                                chown apache:apache $DIR/hr_verfication.php $DIR/captcha_code_file.php
                        fi
                fi
        fi
done < $FILE_NAME
rm -f $FILE_NAME
