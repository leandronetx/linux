#!/bin/bash
hostname_serv=`whereis hostname | awk '{print $2}'`
hostname=`$hostname_serv`
MAX_LOAD=10
TOP=`top -n 1 -b | head -27`
FILE="/var/log/serverload_script.log"
touch $FILE

echo "serverloadcheck.sh running at $hostname " `date`

############# Check if the server load, If it is more than MAX_LOAD restart the apache and send Email
#check=`uptime | awk '{print $10}' | sed 's/,//g'`
check=`cat /proc/loadavg | awk '{print $1}'`
INT=${check/.*}
if [ $INT -ge $MAX_LOAD ]
then
        echo "Server load too high in $hostname  ($check), restarting apache" >> $FILE
        echo "server down, Server load is high($check) in  $hostname at $DT"  >> $FILE
        echo "$TOP" >> $file
    service_name=`lsof -i:80 -S | tail -1 |  cut -d " " -f1`
    if [ $service_name == "nginx" ]
    then
        `service httpd restart`
    elif [ $service_name == "httpd" ]
    then
        `service httpd restart`
    elif [ $service_name == "java" ]
    then
        `service httpd restart`
    else
        echo "No service Running" >> $FILE
    fi
    echo $FILE | mail -s " Server load too high in - $hostname" support@hostingraja.info
else
        echo "Server load OK in $hostname ($check)"
fi
