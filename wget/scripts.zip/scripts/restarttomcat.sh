service tomcat restart
