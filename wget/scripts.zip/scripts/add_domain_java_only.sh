if [ "$#" -ne 3 ]; then
  echo "Enter All Three Arguments" >&2
  exit 1
fi
DOMAIN_NAME=$1
FILE_FULL_PATH=$2
TOMCAT_PATH=$3
CONF_PATH="conf/server.xml"
GREP_PATH="$TOMCAT_PATH$CONF_PATH"
MANAGER_PATH="webapps/manager"
DOCBASE="$TOMCAT_PATH$MANAGER_PATH"
GREPLINE="<Alias>www.$DOMAIN_NAME</Alias>"
if grep -Fxq "$GREPLINE" $GREP_PATH
then
    # code if found
echo "Domain is alredy added"
else
    # code if not found
GREP_LIB=`whereis grep | awk '{print $2}'`
Line_NO=`$GREP_LIB -ni 'Engine' $GREP_PATH | tail -1 | awk -F '[/:]' '{print $1}'`
Line_NO=$((Line_NO-1))
#echo $Line_NO
ADDED_LINE="<Host name=\"$DOMAIN_NAME\"  appBase=\"$FILE_FULL_PATH\" unpackWARs=\"false\" deployXML=\"false\">\n<Alias>www.$DOMAIN_NAME</Alias>\n<Context path=\"\" reloadable=\"true\" docBase=\"$FILE_FULL_PATH\" debug=\"1\"/>\n<!-- <Context path=\"/manager\" debug=\"0\" privileged=\"true\" docBase=\"$DOCBASE\">\n</Context> -->\n</Host>";
EXEC_COMMAND="sed -i '$Line_NO a  $ADDED_LINE' $GREP_PATH"
BASH_LIB=`whereis bash | awk '{print $2}'`
#eval $EXEC_COMMAND
$BASH_LIB -c "$EXEC_COMMAND"
SERVICE_LIB=`whereis service | awk '{print $2}'`
SERVICE_RESTART="$SERVICE_LIB tomcat restart"
#eval $SERVICE_RESTART
#$SERVICE_RESTART
restart=`sh /scripts/restarttomcat.sh`
fi
