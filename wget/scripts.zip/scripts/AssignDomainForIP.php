<?php
$domain_name = $argv[1];
if($argc>1) 
{
	$assign_domain_for_ip = new AssignDomainForIP;
	echo $assign_domain_for_ip->ipPageChange($domain_name);
} 
else 
{
	$assign_domain_for_ip = new AssignDomainForIP;
        echo $assign_domain_for_ip->unAssignDomainIp();
} 

class AssignDomainForIP
{
    	private $zdbh;
    	private $mail_db;
    	public function __construct()
    	{
    	    require('/etc/sentora/panel/cnf/db.php');
    	    require_once('/etc/sentora/panel/dryden/db/driver.class.php');
    	    include_once('/etc/sentora/panel/dryden/debug/logger.class.php');
    	    include_once('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
    	    include_once('/etc/sentora/panel/dryden/runtime/controller.class.php');
    	    include_once('/etc/sentora/panel/dryden/runtime/hook.class.php');
    	    include_once('/etc/sentora/panel/dryden/sys/versions.class.php');
    	    include_once('/etc/sentora/panel/dryden/ctrl/options.class.php');
    	    include_once('/etc/sentora/panel/dryden/fs/director.class.php');
    	    include_once('/etc/sentora/panel/dryden/fs/filehandler.class.php');
    	    include_once('/etc/sentora/panel/inc/dbc.inc.php');
    	    $mailserver_db = ctrl_options::GetSystemOption('mailserver_db');
    	    try
    	    {
		$dsn = "mysql:dbname=$dbname;$ovi_socket_path";
		$this->zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
		$this->zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    	     //   $this->zdbh = new db_driver("mysql:host=" . $host . ";dbname=" . $dbname . "", $user, $pass);
    	        //$this->mail_db = new db_driver("mysql:host=" . $host . ";dbname=" . $mailserver_db . "", $user, $pass);
    		$dsn = "mysql:dbname=$mailserver_db;$ovi_socket_path";
		$this->mail_db = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
		$this->mail_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);   
	 }
    	    catch (PDOException $e)
    	    {
    	        exit();
    	    }
    	}

	public function unAssignDomainIp()
	{
		$static_path = "/etc/sentora/panel/etc/static/pages/";
		$rows = $this->zdbh->prepare("UPDATE x_settings set so_value_tx=:static_path where so_name_vc='ipdomain_dir'");
		$rows->bindParam(':static_path', $static_path);
		$rows->execute();
		$this->setWriteApacheConfigTrue();
		$this->setCallDaemon();
		return "UNASSIGNED_SUCCCESSFULLY";
	}
	public function ipPageChange($which_domain)
	{
		$get_path=$this->getFullPathOfDomain($which_domain);
		$rows = $this->zdbh->prepare("UPDATE x_settings  set so_value_tx=:domain_path where so_name_vc='ipdomain_dir'");
                $rows->bindParam(':domain_path', $get_path);
		$rows->execute();
		$this->setWriteApacheConfigTrue();
		$this->setCallDaemon();
	
		return "IP_DIRECTORY_CHANGE_SUCCESS";
	}
 
 	public function getFullPathOfDomain($domain_name)
	{
		$res = $this->getUsernameBasedOnDomain($domain_name);
	       // code add by nandhini 2.8 to post assign domain ip value to sentora.config for update same domain php version to ip 
		$res = explode("=>",$res);
		$username = $res[0];
		$domain_id = $res[1];
		$sline = "domain_id ".$domain_id;
		$sline .= fs_filehandler::NewLine();
		$sline .= "domain_name ".$domain_name; 
		$sfile = fopen("/etc/sentora/panel/.assigned_domain_for_ip.txt","w");
                fwrite($sfile,$sline);
                fclose($sfile);
		// code end here nandhini		
		$rows = $this->zdbh->prepare("SELECT vh_directory_vc FROM x_vhosts WHERE vh_name_vc='".$domain_name."' AND vh_deleted_ts IS NULL");
		$rows->execute();
		$dbvals = $rows->fetch();
		$path=ltrim($dbvals['vh_directory_vc'],"/");
		// by nandhini 2.8 changed public_html 
		$vhost_path = rtrim( ctrl_options::GetSystemOption('hosted_dir') . $username . "/".$path, "/")."/";
		return $vhost_path;
	}
	public function getUsernameBasedOnDomain($domain_name)
    	{
    	    //$rows = $this->zdbh->prepare("SELECT ac_user_vc FROM x_accounts WHERE ac_id_pk=(SELECT vh_acc_fk FROM x_vhosts WHERE vh_name_vc='".$domain_name."' AND vh_deleted_ts IS NULL);");
    	   // mysql query optimize in 2.8
            $rows = $this->zdbh->prepare("SELECT a.ac_user_vc, b.vh_id_pk FROM x_accounts as a 
						INNER JOIN x_vhosts as b ON (a.ac_id_pk = b.vh_acc_fk) 
						WHERE b.vh_name_vc='".$domain_name."' AND b.vh_deleted_ts IS NULL;");
    	    $rows->execute();
    	    $dbvals = $rows->fetch();
    	    $username=$dbvals['ac_user_vc'];
    	    $domain_id=$dbvals['vh_id_pk'];
    	    return $username."=>".$domain_id;
    	}
	
	public function setWriteApacheConfigTrue()
    	{
		$sql = $this->zdbh->prepare("UPDATE x_settings SET so_value_tx='true' WHERE so_name_vc='apache_changed'");
		$sql->execute();
    	}

	public function setCallDaemon()
    	{
    	    $service_port = 4445 ;
    	    $address = gethostbyname('localhost');
    	    $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
    	    if ($socket === false)
    	    {
    	    }
    	    $result = socket_connect($socket, $address, $service_port);
    	    if ($result === false)
    	    {
    	    }
    	    socket_set_option($socket, SOL_SOCKET, SO_RCVTIMEO, array("sec" => 2000, "usec" =>0));
    	    $in="command DaemonCall ";
    	    socket_write($socket, $in, strlen($in));
    	    socket_close($socket);
    	}
}
?>
