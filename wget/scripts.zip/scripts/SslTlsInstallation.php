<?php
$obj = new SslTlsInstallation;
$result = $obj->checkAccountExists();
echo $result;
class SslTlsInstallation {
	private $HRPanelAISALib;
        private $HRPanelssl;
        private $domain_lists;
        private $privkey_list;
        private $hostname;
        private $host_domain_name;
	private $sub_domain_name;
        private $ip_domain_dir;
	private $server_ip_addr;
        private $zdbh;
	public function __construct() {
		error_reporting(0);
                require('/etc/sentora/panel/cnf/db.php');
                include('/etc/sentora/panel/dryden/db/driver.class.php');
                include('/etc/sentora/panel/dryden/debug/logger.class.php');
                include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
                include('/etc/sentora/panel/dryden/runtime/hook.class.php');
                include('/etc/sentora/panel/dryden/sys/versions.class.php');
                include('/etc/sentora/panel/dryden/ctrl/options.class.php');
                include('/etc/sentora/panel/dryden/fs/director.class.php');
                include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
                include('/etc/sentora/panel/inc/dbc.inc.php');
                try
                {
                       // $this->zdbh = new db_driver("mysql:host=" . $host . ";dbname=" . $dbname . "", $user, $pass);
                	$dsn = "mysql:dbname=$dbname;$ovi_socket_path";
			$this->zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
			$this->zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
                catch (PDOException $e)
                {
                    // exit();
                }
        }
	public function checkAccountExists() {
            // Check connection
            if (mysqli_connect_errno()) {
                echo "Failed to connect to MySQL: " . mysqli_connect_error();
            } else {
		$this->server_ip_addr = ctrl_options::GetSystemOption('server_ip');
		$this->ip_domain_dir  = ctrl_options::GetSystemOption('ipdomain_dir');
		$sql    = "SELECT vh_name_vc FROM x_vhosts WHERE vh_type_in =1 AND vh_deleted_ts is NULL";
		$dom_result = $this->zdbh->prepare($sql);
		$dom_result->execute();
		$host_count = $dom_result->rowCount();
                if($host_count) {
		    $hostname = self::getHostname();
		    if($hostname) {
			//hostname validation	
		    	$hostname_check_res = self::hostnameCheck($hostname);
		    	if($hostname_check_res) {
				//getting hostname A record
				$host_dns_record = dns_get_record($hostname,DNS_A);
                		if($host_dns_record) {
					print_r($host_dns_record);
					$host_ip_addr    = $host_dns_record[0]['ip'];
					echo $host_ip_addr;
					
					//Checking the both host IP and server IP are same.
					if($host_ip_addr == $this->server_ip_addr || $host_ip_addr == '127.0.0.1') {
						$certbot_service = trim(shell_exec('whereis certbot  | awk \'{print $2}\''));
						$certbot_result  = trim(shell_exec($certbot_service.' certificates | grep "'.$hostname.'"'));
						echo "\ncertbot_result ".$certbot_result;
						if(!$certbot_result) {
							self::installSSL($hostname, $this->ip_domain_dir);
							$sh_service = trim(shell_exec('whereis sh | awk \'{ print $2}\''));
							$exec_res = trim(shell_exec($sh_service.' /scripts/ssl_tls_based_on_hostname.sh'));
						} else {
							$sh_service = trim(shell_exec('whereis sh | awk \'{print $2}\''));
                        				shell_exec($sh_service.' /scripts/ssl_tls_based_on_hostname.sh');
						}
					} else {
					$return = "You were pointed different ip for this hostname. Please point this hostname( ".$hostname.") with the same ip of server( ".$server_ip_addr." )";	
					}
				} else {
					$domain_dns_record = dns_get_record($this->host_domain_name, DNS_NS);
					print_r($domain_dns_record);
					$domain_ns_record = $domain_dns_record[0]['target'];
					$ns_rec_ip_addr	  = dns_get_record($domain_ns_record, DNS_A);
					$ns_rec_ip_addr	  = $ns_rec_ip_addr[0]['ip'];
					echo "\nns_rec_ip_addr ".$ns_rec_ip_addr;
					if($ns_rec_ip_addr !=$this->server_ip) {
						self::sendTicket($this->hostname, $message);
					} else {
						self::pointHostName($this->hostname);
					}
					//$return = "It seems like the server hostname is not pointed with this server. Please try to point the hostname with this server.";
				}
		    	} else {
				$return = "There is no valid hostname we found in this server. Please change the hostname or else contact your system administrator";
				self::sendTicket($this->hostname, $return);
		    	}
                    } else {
                    	$return = "Hostname not found";
			self::sendTicket($this->hostname, $return);
                    }
		} else {
			$return = "Thereis no Domain to install SSL and TLS";
			self::sendTicket($this->hostname, $return);
		}
		return $return;
            }
        }
	/*
         * Getting Hostname, domain name, and the subdomain name
         */
        public function getHostname() {
                $hostnamectl_service = trim(shell_exec('whereis hostnamectl | awk \'{print $2}\''));
                $grep_service = trim(shell_exec('whereis grep | awk \'{print $2}\''));
                $this->hostname = trim(shell_exec($hostnamectl_service.'  | '.$grep_service.' "Static hostname" | awk \'{print $3}\''));
		$split_hostname=explode(".",$this->hostname);
                $this->sub_domain_name=$split_hostname[0];
                unset($split_hostname[0]);
                $this->host_domain_name = trim(implode(".",$split_hostname));
		return $this->hostname;
        }
	/*
         * Hostname Validations 
         */
	public function hostnameCheck($hostname) {
		$hostname_valid = explode(".", $hostname);
		if(sizeof($hostname_valid)>2 && $hostname_valid[sizeof($hostname_valid)-1] !="") {
			return true;
		} else {
			return false;
		}
	}
	/*
         * INSTALL SSL
         */
	public function installSSL($hostname, $ip_domain_dir) {
			$email_addr = 'support@hostingraja.info';
			$sh_service = trim(shell_exec('whereis sh | awk \'{print $2}\''));
			$ssl_install_res = trim(shell_exec($sh_service.' /etc/sentora/panel/modules/ssl/code/ssl.sh '.$hostname.' '.$email_addr.' without '.$ip_domain_dir ));
			$sh_service = trim(shell_exec('whereis sh | awk \'{print $2}\''));
			shell_exec($sh_service.' /scripts/ssl_tls_based_on_hostname.sh');
	}
	/*
	 * Adding A record to the Hostname
	 */
	public function pointHostName($hostname) {
		echo "Hostname pointing is start here...";
                $domain_name = $this->host_domain_name;
		$targetIP    = $this->server_ip_addr;
                /* /////////////////////////// Code for adding A record if it does not exists started HERE  ////////////////////// */
                $check_ssl = "SELECT vh_acc_fk,vh_id_pk FROM x_vhosts WHERE vh_name_vc='".$domain_name."' AND vh_deleted_ts IS NULL";
                $numcheck = $this->zdbh->prepare($check_ssl);
                $numcheck->execute();
		$count = $numcheck->rowCount();
                $check_num = $numcheck->fetchColumn();
                if ($count)
                {
                        //$rows = $this->zdbh->prepare("SELECT vh_acc_fk,vh_id_pk FROM x_vhosts WHERE vh_name_vc='".$domain_name."' AND vh_deleted_ts IS NULL;");
                        //$rows->execute();
                        $dbvals = $numcheck->fetch();
                        $domainID=$dbvals['vh_id_pk'];
                        $user_id=$dbvals['vh_acc_fk'];
                        $dsql=$this->zdbh->prepare("SELECT count(*) as rcd_cnt FROM x_dns WHERE dn_acc_fk=:userid AND dn_name_vc=:domainName AND dn_vhost_fk=:domainID AND dn_type_vc='A' AND dn_host_vc=:subDomain AND dn_target_vc=:target_new AND dn_deleted_ts is NULL");
                        $dsql->bindParam(':userid', $user_id);
                        $dsql->bindParam(':domainName', $domain_name);
                        $dsql->bindParam(':domainID', $domainID);
                        $dsql->bindParam(':subDomain', $this->sub_domain_name);
                        $dsql->bindParam(':target_new', $targetIP);
			$dsql->execute();
                        $dres=$dsql->fetch();
                        if($dres['rcd_cnt']==0)
                        {
                                $sql = $this->zdbh->prepare("INSERT INTO x_dns (dn_acc_fk,
                                dn_name_vc,
                                dn_vhost_fk,
                                dn_type_vc,
                                dn_host_vc,
                                dn_ttl_in,
                                dn_target_vc,
                                dn_priority_in,
                                dn_weight_in,
                                dn_port_in,
                                dn_created_ts) VALUES (
                                :userid,
                                :domainName,
                                :domainID,
                                'A',
                                :hostName_new,
                                '3600',
                                :target_new,
                                '0',
                                '0',
                                '0',
                                :time)"
                                );
                                $sql->bindParam(':userid', $user_id);
                                $sql->bindParam(':domainName', $domain_name);
                                $sql->bindParam(':domainID', $domainID);
                                $sql->bindParam(':hostName_new', $this->sub_domain_name);
                                $sql->bindParam(':target_new', $targetIP);
                                $time = time();
                                $sql->bindParam(':time', $time);
                                $sql->execute();
                                unset($sql);
								
				$sql = $this->zdbh->prepare("INSERT INTO x_dns (dn_acc_fk,
                                dn_name_vc,
                                dn_vhost_fk,
                                dn_type_vc,
                                dn_host_vc,
                                dn_ttl_in,
                                dn_target_vc,
                                dn_priority_in,
                                dn_weight_in,
                                dn_port_in,
                                dn_created_ts) VALUES (
                                :userid,
                                :domainName,
                                :domainID,
                                'A',
                                :hostName_new,
                                '3600',
                                :target_new,
                                '0',
                                '0',
                                '0',
                                :time)"
                                );
                                $sql->bindParam(':userid', $user_id);
                                $sql->bindParam(':domainName', $domain_name);
                                $sql->bindParam(':domainID', $domainID);
                                $serv_alias="www.".$this->sub_domain_name;
                                $sql->bindParam(':hostName_new',$serv_alias);
                                $sql->bindParam(':target_new', $targetIP);
                                $time = time();
                                $sql->bindParam(':time', $time);
                                $sql->execute();
                                unset($sql);
								
				$records_list = ctrl_options::GetSystemOption('dns_hasupdates');
                                $record_array = explode(',', $records_list);
                                if (!in_array($domainID, $record_array))
                                {
                                        if (empty($records_list))
                                        {
                                                $records_list .= $domainID;
                                        }
                                        else
                                        {
                                                $records_list .= ',' . $domainID;
                                        }
                                        $sql = "UPDATE x_settings SET so_value_tx=:newlist WHERE so_name_vc='dns_hasupdates'";
                                        $sql = $this->zdbh->prepare($sql);
                                        $sql->bindParam(':newlist', $records_list);
                                        $sql->execute();
                                }
                                $sql = $this->zdbh->prepare("UPDATE x_settings SET so_value_tx='true' WHERE so_name_vc='apache_changed'");
                                $sql->execute();
                                echo "DOMAIN_NAME_CREATED\n";
				$php_service = shell_exec('whereis php | \'awk {print $2}\'');
				shell_exec($php_service.' /etc/sentora/panel/bin/daemon.php');
                                //$this->HRPanelAISALib->SetWriteApacheConfigTrue();
                                //$this->HRPanelAISALib->SetCallDaemon();
                                $hostname_pointed = "DOMAIN_NAME_CREATED";
                        }
                        else
                        {
                                echo "HOSTANEM_ALREADY_ADDED\n";
                                $hostname_pointed = "HOSTNAME_ALREADY_ADDED";
                        }
                /* //////////////////////////// Code for adding A record if it does not exists Ended HERE  /////////////////////////// */

                }
                else
                {
                        echo "DOMAIN_NOT_CREATED\n";
                        $hostname_pointed = "DOMAIN_NOT_CREATED";
                }
                return $hostname_pointed;
	}
	/*
	 * Sending Ticket to support Team mail
	 */
	public function sendTicket($new_hostname, $message) {
                echo "Sending Ticket...";                
                $mail_body = "<html>";
                $mail_body .= "<body>";
                $mail_body .= "<div>";
                $mail_body .= "<div>ISSUE: Point RDNS to the new Hostname.</div>" ;
                $mail_body .= "<div>".$message."</div>" ;
                $mail_body .= "</div>";                
                $mail_body .= "</body>";
                $mail_body .= "</html>";

                $email  	= 'support@hostingraja.info';
		$subject	= "Add RDNS to the new Hostname- ".$new_hostname;
                // To send HTML mail, the 'Content-type' header must be set
                $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                
                // Additional headers
                $headers .= 'From: Support <support@hostingraja.in>' . "\r\n";
                mail($email,$subject,$mail_body, $headers);
        }
} 
