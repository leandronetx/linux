if [ $# -eq 1 ];
then
tz=$1
#echo "$TIMEZONE"
# mysql_tzinfo_to_sql /usr/share/zoneinfo | mysql -u root mysql
echo "Mysql Time change start"
mysql -e "SET GLOBAL time_zone = '$tz' ";
echo "Mysql Time updated successfully"
echo "PHP Time change start"
php54_ini_path=`/opt/remi/php54/root/bin/php -i | grep "Loaded Configuration File" | awk '{print $5}'`;
php55_ini_path=`/opt/remi/php55/root/bin/php -i | grep "Loaded Configuration File" | awk '{print $5}'`;
php56_ini_path=`/opt/remi/php56/root/bin/php -i | grep "Loaded Configuration File" | awk '{print $5}'`;
php70_ini_path=`/opt/remi/php70/root/bin/php -i | grep "Loaded Configuration File" | awk '{print $5}'`;
php71_ini_path=`/opt/remi/php71/root/bin/php -i | grep "Loaded Configuration File" | awk '{print $5}'`;
php72_ini_path=`/opt/remi/php72/root/bin/php -i | grep "Loaded Configuration File" | awk '{print $5}'`;
php73_ini_path=`/opt/remi/php73/root/bin/php -i | grep "Loaded Configuration File" | awk '{print $5}'`;
sed -i "s#^\(date.timezone\).*#\date.timezone = $tz #" /etc/php.ini
sed -i "s#^\(date.timezone\).*#\date.timezone = $tz #" $php54_ini_path
sed -i "s#^\(date.timezone\).*#\date.timezone = $tz #" $php55_ini_path
sed -i "s#^\(date.timezone\).*#\date.timezone = $tz #" $php56_ini_path
sed -i "s#^\(date.timezone\).*#\date.timezone = $tz #" $php70_ini_path
sed -i "s#^\(date.timezone\).*#\date.timezone = $tz #" $php71_ini_path
sed -i "s#^\(date.timezone\).*#\date.timezone = $tz #" $php72_ini_path
sed -i "s#^\(date.timezone\).*#\date.timezone = $tz #" $php73_ini_path
sed -i "s#^\(date.timezone\).*#\date.timezone = $tz #" /etc/sentora/configs/ovipanel/php.ini
sed -i "s#^\(date.timezone\).*#\date.timezone = $tz #" /etc/sentora/configs/ovipanel/app/php.ini
echo "PHP Time change end"
echo "Server Time change start"
rm -fr /etc/localtime
cp /usr/share/zoneinfo/$tz /etc/localtime
echo "Server Time change End"
VER=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
if  [[ "$VER" = "7" ]]; then
/bin/systemctl restart  httpd.service >/dev/null 2>&1
/bin/systemctl force-reload  lighttpd.service >/dev/null 2>&1
mysql --socket="/usr/local/mysql/mysql.sock" -e "SET GLOBAL time_zone = '$tz' ";
else
service httpd restart >/dev/null 2>&1
service lighttpd force-reload >/dev/null 2>&1
fi
fi
