if [ "$#" == 3 ]
then
domain_path=$1
python_version=$2
username=$3
cd $domain_path
file_name2="venv"
current_time=$(date "+%Y.%m.%d-%H.%M.%S")
new_fileName2=$file_name2.$current_time
mv $file_name2 $new_fileName2
virtualenv -p $python_version venv
chown $username:$username venv
fi
