<?php
if ($argc == 2 )
{
	$hostname = $argv[1];
}
else
{
	echo "INVALID_PARAMETRS";
	exit;
}
$point_host = new PointHostname;
$email = "support@hostingraja.info";
$point_host_res = $point_host->pointHostName($hostname); 
//echo $point_host_res."\n";
class PointHostname 
{
	//private $HRPanelAISALib;
	//private $HRPanelssl;
	//private $domain_lists;
	//private $privkey_list;
	//private $hostname;
	//private $hostdomainname;
	//private $dovecotConfFilePath;
	private $zdbh;
	public function __construct()
	{
		error_reporting(0);
		require('/etc/sentora/panel/cnf/db.php');
		include('/etc/sentora/panel/dryden/db/driver.class.php');
		include('/etc/sentora/panel/dryden/debug/logger.class.php');
		include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
		include('/etc/sentora/panel/dryden/runtime/hook.class.php');
		include('/etc/sentora/panel/dryden/sys/versions.class.php');
		include('/etc/sentora/panel/dryden/ctrl/options.class.php');
		include('/etc/sentora/panel/dryden/fs/director.class.php');
		include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
		include('/etc/sentora/panel/inc/dbc.inc.php');
		try 
		{
			//$this->zdbh = new db_driver("mysql:host=" . $host . ";dbname=" . $dbname . "", $user, $pass);
			$dsn = "mysql:dbname=$dbname;$ovi_socket_path";
			$this->zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
			$this->zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
		catch (PDOException $e) 
		{
		    // exit();
		}

	}
	

	public function pointHostName($hostname)
	{
		if (!fs_director::CheckForEmptyValue(ctrl_options::GetSystemOption('server_ip'))) 
		{
			$targetIP = ctrl_options::GetSystemOption('server_ip');
		} 
		else 
		{
			$targetIP = $_SERVER["SERVER_ADDR"];
		}
		$domain_name = explode(".", $hostname);
		$dom_size=sizeOf($domain_name);
		$domain_name = $domain_name[$dom_size-2].".".$domain_name[$dom_size-1];
		$host_name_ns_record = dns_get_record($domain_name, DNS_NS);
		if(count($host_name_ns_record) == 0)
        {
            echo "NS_RECORD_NOT_POINT_WITH_US";
        	exit;
        }
		foreach($host_name_ns_record as $host_ns_rec )
		{
			foreach ($host_ns_rec as $key => $value)
			{
				if($key == "target")
				{
					$host_ns_a_rec = dns_get_record($value, DNS_A);
					$host_ns_a_ip = $host_ns_a_rec[0]['ip'];
					if($host_ns_a_ip != $targetIP)
					{
						echo "NS_RECORD_NOT_POINT_WITH_US";
						exit;
					}
				}
			}
		}
		//echo "Host Domain Name is pointing with us so pointing hostname also with us.\n";	
		$split_hostname = explode(".",$hostname);
	    	$subDomainName = $split_hostname[0];
		unset($split_hostname[0]);
                $domain_name = trim(implode(".",$split_hostname));
		//echo "Sub domain name : ".$subDomainName."\n";
		//echo "Domain name : ".$domain_name."\n";
		//$hostname_pointed = NEED_TO_CHECK;
		/* 
		 * Code for adding A record if it does not exists started HERE  
		 */
	    	$check_ssl = "SELECT vh_acc_fk,vh_id_pk FROM x_vhosts WHERE vh_name_vc='".$domain_name."' AND vh_deleted_ts IS NULL";
        	$numcheck = $this->zdbh->prepare($check_ssl);
        	$numcheck->execute();
        	$check_num = $numcheck->fetchColumn();
        	if ($check_num > 0)
        	{
			
			$rows = $this->zdbh->prepare("SELECT vh_acc_fk,vh_id_pk FROM x_vhosts WHERE vh_name_vc='".$domain_name."' AND vh_deleted_ts IS NULL;");
			$rows->execute();
			$dbvals = $rows->fetch();
			$domainID=$dbvals['vh_id_pk'];
			$user_id=$dbvals['vh_acc_fk'];
			$dsql=$this->zdbh->prepare("SELECT count(*) as rcd_cnt FROM x_dns WHERE dn_acc_fk=:userid AND dn_name_vc=:domainName AND dn_vhost_fk=:domainID AND dn_type_vc='A' AND dn_host_vc=:subDomain AND dn_target_vc=:target_new AND dn_deleted_ts is NULL");		
			$dsql->bindParam(':userid', $user_id);
			$dsql->bindParam(':domainName', $domain_name);
			$dsql->bindParam(':domainID', $domainID);
			$dsql->bindParam(':subDomain', $subDomainName);
			$dsql->bindParam(':target_new', $targetIP);
			$dsql->execute();
			$dres=$dsql->fetch();
			if($dres['rcd_cnt']==0)
			{
				$sql = $this->zdbh->prepare("INSERT INTO x_dns (dn_acc_fk, dn_name_vc, dn_vhost_fk, dn_type_vc,	dn_host_vc,
								dn_ttl_in, dn_target_vc, dn_priority_in, dn_weight_in, dn_port_in,
								dn_created_ts) VALUES ( :userid, :domainName, :domainID, 'A', :hostName_new,
								'3600',	:target_new, '0', '0', '0', :time)"
				);
				$sql->bindParam(':userid', $user_id);
				$sql->bindParam(':domainName', $domain_name);
				$sql->bindParam(':domainID', $domainID);
				$sql->bindParam(':hostName_new', $subDomainName);
				$sql->bindParam(':target_new', $targetIP);
				$time = time();
				$sql->bindParam(':time', $time);
				$sql->execute();
				unset($sql);
				
				$records_list = ctrl_options::GetSystemOption('dns_hasupdates');
				$record_array = explode(',', $records_list);
				if (!in_array($domainID, $record_array)) 
				{
					if (empty($records_list)) 
					{
						$records_list .= $domainID;
					} 
					else 
					{
						$records_list .= ',' . $domainID;
					}
					$sql = "UPDATE x_settings SET so_value_tx=:newlist WHERE so_name_vc='dns_hasupdates'";
					$sql = $this->zdbh->prepare($sql);
					$sql->bindParam(':newlist', $records_list);
					$sql->execute();
				}
				$sql = $this->zdbh->prepare("UPDATE x_settings SET so_value_tx='true' WHERE so_name_vc='apache_changed'");
				$sql->execute();
				echo "HOSTNAME_NAME_CREATED\n";exit;
				//$this->HRPanelAISALib->SetWriteApacheConfigTrue();
	            		//$this->HRPanelAISALib->SetCallDaemon();
				//$hostname_pointed = DOMAIN_NAME_CREATED;
			}
			else 
			{
				echo "HOSTNAME_ALREADY_ADDED\n";exit;
			}
		/* 
		 * Code for adding A record if it does not exists Ended HERE  
		 */
		
		}
		else 
		{
			echo "HOSTNAME_NOT_CREATED\n";exit;
		}
		return $hostname_pointed;		
	}
}
