<?php
$filename = "/var/sentora/logs/weekly_logs.log";
if (!file_exists($filename)) 
{
	shell_exec("touch /var/sentora/logs/weekly_logs.log");  
}
$time = time();
shell_exec("echo 'Start-$time' > $filename");
require('/etc/sentora/panel/cnf/db.php');
include('/etc/sentora/panel/dryden/db/driver.class.php');
include('/etc/sentora/panel/dryden/debug/logger.class.php');
include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
include('/etc/sentora/panel/dryden/runtime/hook.class.php');
include('/etc/sentora/panel/dryden/sys/versions.class.php');
include('/etc/sentora/panel/dryden/ctrl/options.class.php');
include('/etc/sentora/panel/dryden/fs/director.class.php');
include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
include('/etc/sentora/panel/inc/dbc.inc.php');
	try {
		//$zdbh = new db_driver("mysql:host=" . $host . ";dbname=" . $dbname . "", $user, $pass);
		$dsn = "mysql:dbname=$dbname;$ovi_socket_path";
		$zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
		$zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	} catch (PDOException $e) {
		exit();
	}

	global $controller;
	
	/*------Domain log tar----------*/
	$tar_name = "domains_".$time.".tar"; 
	shell_exec("cd /var/sentora/logs/; tar cPfz $tar_name /var/sentora/logs/domains/;");
	
	/*------Delete old Domain log tar----------*/
	$del_domain = trim(shell_exec("ls /var/sentora/logs/domains_*.tar | cut -d '_' -f2 |cut -d '.' -f1 | sort -k 1"));
	$del_arr = explode("\n",$del_domain);
	$del_count = count($del_arr);
	if($del_count > 1)
	{
		$del = array_pop($del_arr);
		foreach($del_arr as $value)
		{
			$file = "/var/sentora/logs/domains_".$value.".tar";
			if(file_exists($file))
			{
				//echo $file."\n";
				shell_exec("echo $file >> $filename");
				$un = unlink($file);
			}
		}
		
	}
	
	/*------Empty Domain logs----------*/
	$sql = $zdbh->prepare("SELECT * FROM x_accounts WHERE ac_user_vc !='zadmin' AND ac_deleted_ts IS NULL");
	$sql->execute();
	
	while($username = $sql->fetch()) 
	{
		$uname = $username['ac_user_vc'];
		$uid = $username['ac_id_pk'];
		shell_exec("echo $uname >> $filename");
		shell_exec("find /var/sentora/logs/domains/$uname -type f -exec sh -c '>{}' \;");
	}
	
	/*------Sentora log tar----------*/
	shell_exec("cd /var/sentora/logs/; tar cvfz sentora_$time.tar sentora-access.log sentora-bandwidth.log sentora-error.log");
	$filenam = "/var/sentora/logs/sentora_$time.tar";
	
	/*------Delete old Sentora log tar----------*/
	$del_sentora = trim(shell_exec("ls /var/sentora/logs/sentora_*.tar | cut -d '_' -f2 |cut -d '.' -f1 | sort -k 1"));
	$del_arrr = explode("\n",$del_sentora);
	$del_countt = count($del_arrr);
	
	if($del_countt > 1)
	{
		$dell = array_pop($del_arrr);
		foreach($del_arrr as $values)
		{
			$files = "/var/sentora/logs/sentora_".$values.".tar";
			if(file_exists($files))
			{
				//echo $files."\n";
				shell_exec("echo $files >> $filename");
				$unn = unlink($files);
			}
		}
		/*------Empty Domain logs----------*/
		shell_exec("echo 'hostingraja clear logs' > /var/sentora/logs/sentora-access.log");
		shell_exec("echo 'hostingraja clear logs' > /var/sentora/logs/sentora-bandwidth.log");
		shell_exec("echo 'hostingraja clear logs' > /var/sentora/logs/sentora-error.log");
	}
	shell_exec("echo 'End-$time' >> $filename");
	shell_exec("service rsyslog restart");
	exit;
?>
