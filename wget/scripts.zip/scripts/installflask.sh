if [ "$#" == 6 ]
then
mkdir -p /etc/sentora/configs/apache/python/
domain_name=$1
python_version=$2
python_version_sanitize=$(echo "$python_version" | sed 's/\//\\\//g')
domainpath=$3
path=$(echo "$domainpath" | sed 's/\//\\\//g')
implode=$4
final_implode=$(echo "$implode" | sed 's/\//\\\//g')
last_one=$5 
username=$6
filename=$(echo $domain_name | sed 's/\*./wildcard_/g')
cd $domainpath
file_name=__init__.py
file_name1=init.wsgi
file_name2=venv
file_name3=index.html
file_name4=index.php
current_time=$(date "+%Y.%m.%d-%H.%M.%S")
new_fileName=$file_name.$current_time
new_fileName1=$file_name1.$current_time
new_fileName2=$file_name2.$current_time
new_fileName3=$file_name3.$current_time
new_fileName4=$file_name4.$current_time
mv $file_name $new_fileName
mv $file_name1 $new_fileName1
mv $file_name2 $new_fileName2
mv $file_name3 $new_fileName3
mv $file_name4 $new_fileName4
cp /etc/sentora/panel/modules/python_management/assets/flask__init__.py __init__.py
cp /etc/sentora/panel/modules/python_management/assets/flask_init.wsgi init.wsgi
#virtualenv venv
virtualenv -p $python_version venv
source venv/bin/activate
pip install Flask
chown $username. -R $domainpath
sed -i "s/DOMAINNAME/$domain_name/g" __init__.py
sed -i "s/PYTHON_VERSION/$python_version_sanitize/g" init.wsgi
sed -i "s/DOMAIN_FULL_PATH/$path/g" init.wsgi
sed -i "s/FIRST_PATH/$final_implode/g" init.wsgi
sed -i "s/LAST_PATH/$last_one/g" init.wsgi
INIT_WSGI=init.wsgi
SCRIPTALIAS=$(echo "WSGIScriptAlias / $domainpath$INIT_WSGI"  | sed 's/\//\\\//g')
DAEMON_PROCESS=$( echo "WSGIDaemonProcess $domain_name user=$username group=$username threads=5"  | sed 's/\//\\\//g')
SSL_DAEMON_PROCESS=$( echo "WSGIDaemonProcess ssl.$domain_name user=$username group=$username threads=5"  | sed 's/\//\\\//g')
echo $SCRIPTALIAS
echo $DAEMON_PROCESS
conf=".conf"
ssl="ssl_"
python_file_conf="/etc/sentora/configs/apache/python/$filename$conf"
ssl_python_file_conf="/etc/sentora/configs/apache/python/ssl_$filename$conf"
echo "WSGIScriptAlias / $domainpath$INIT_WSGI" > $python_file_conf
echo "WSGIDaemonProcess $domain_name user=$username group=$username threads=5 python-home=$domainpath""venv" >> $python_file_conf
echo "WSGIScriptAlias / $domainpath$INIT_WSGI" > $ssl_python_file_conf
echo "WSGIDaemonProcess ssl_$domain_name user=$username group=$username threads=5 python-home=$domainpath""venv" >> $ssl_python_file_conf
include_opt_str=$( echo "IncludeOptional $python_file_conf" | sed 's/\//\\\//g')
include_opt_str_ssl=$( echo "IncludeOptional $ssl_python_file_conf" | sed 's/\//\\\//g')
#sed -i "/IncludeOptional/c\\$include_opt_str" /etc/sentora/configs/apache/domains/$domain_name$conf
#sed -i "/WSGIScriptAlias/c\\$SCRIPTALIAS" /etc/sentora/configs/apache/domains/$domain_name$conf
#sed -i "/WSGIDaemonProcess/c\\$DAEMON_PROCESS" /etc/sentora/configs/apache/domains/$domain_name$conf
#sed -i "/WSGIScriptAlias/c\\$SCRIPTALIAS" /etc/sentora/configs/apache/domains/$ssl$domain_name$conf
#sed -i "/WSGIDaemonProcess/c\\$SSL_DAEMON_PROCESS" /etc/sentora/configs/apache/domains/$ssl$domain_name$conf
#sed -i "/IncludeOptional/c\\$include_opt_str_ssl" /etc/sentora/configs/apache/domains/$ssl$domain_name$conf
#service httpd reload
#service httpd restart
#SERVICE_PATH=`whereis service | awk '{print $2}'`
#`$SERVICE_PATH httpd restart`
domain_ssl_conf_path="/etc/sentora/configs/apache/domains/$ssl$filename$conf"
domain_conf_path="/etc/sentora/configs/apache/domains/$filename$conf"
virtual_detail1=$(grep -no "</virtualhost>" $domain_conf_path);
line6=$(echo $virtual_detail1 | awk '{print $1}' FS=":");
virtual_ssl_detail1=$(grep -no "</virtualhost>" $domain_ssl_conf_path);
linessl6=$(echo $virtual_ssl_detail1 | awk '{print $1}' FS=":");
        if [[ $line6 = *[[:digit:]]* ]]; then
                one=1   
                line7=`expr $line6 - $one`
                linessl7=`expr $linessl6 - $one`
                sed -i "${line7}a $include_opt_str " $domain_conf_path
                sed -i "${linessl7}a $include_opt_str_ssl " $domain_ssl_conf_path
        fi
        SERVICE_PATH=`whereis service | awk '{print $2}'`
        `$SERVICE_PATH httpd reload`
fi
