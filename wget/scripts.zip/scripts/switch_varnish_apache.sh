echo "                 Server status                   "
echo "================================================="
echo "PORT 80 : "`lsof -i :80 -S | awk 'FNR==2 {print $1}'`
echo "PORT 8080 : "`lsof -i :8080 -S | awk 'FNR==2 {print $1}'`
JAVAPATH="whereis java"
JAVACHECK=`eval $JAVAPATH`
if [[ $JAVACHECK == "java:" ]]
then
  echo "Java is not installed"
else
echo "Java is installed already"
echo `eval java -version`
fi
echo "================================================="
if [[ $JAVACHECK == "java:" ]]
then
while true; do
 echo "==============================="
 echo "= 1. On Varnish               ="
 echo "= 2. Off Varnish( Apache Only)="
 echo "= 3. Exit                     ="
 echo "==============================="

read -e -p "Enter your Option:" yn
            case $yn in
                1)
               	/etc/sentora/panel/bin/setso --set apache_port 8080
                /etc/sentora/panel/bin/setso --set sentora_port 8080
		mysql --socket='/usr/local/mysql/mysql.sock' -e "Use sentora_core; Update x_vhosts SET vh_custom_port_in='8080';"
		mysql --socket='/usr/local/mysql/mysql.sock' -e "Use sentora_core; Update x_varnish SET x_varnish='On',x_isactive='0';"
		/etc/sentora/panel/bin/setso --set apache_changed "true"
		php /etc/sentora/panel/bin/daemon.php
		echo "Now your server was running under Varnish"
                exit
		;;
                2)
		/etc/sentora/panel/bin/setso --set apache_port 80                
                /etc/sentora/panel/bin/setso --set sentora_port 80
		mysql --socket='/usr/local/mysql/mysql.sock' -e "Update sentora_core.x_vhosts SET vh_custom_port_in='80';"
                mysql --socket='/usr/local/mysql/mysql.sock' -e "Update sentora_core.x_varnish SET x_varnish='Off',x_isactive='0';"
		/etc/sentora/panel/bin/setso --set apache_changed "true"
		php /etc/sentora/panel/bin/daemon.php
                echo "Now your server was running under Apache"
		exit
		 ;;
                3) exit;;
                * ) continue;;
           esac
done
fi
