bwfile=`whereis wondershaper | cut -d ' ' -f2`
hostname=`hostname`
if [ ! -z $bwfile ]; then
echo $hostname
bwvalue=`curl -s https://www.hostingraja.in/hostapi/bwlimit.php?vmname=$hostname`
#Find active interface
activein=`/usr/sbin//usr/sbin/ifconfig | grep eth0 | cut -d ' ' -f1 | sed 's/://g'`
if [ -z $activein ];then
activein=`/usr/sbin//usr/sbin/ifconfig | grep ens192 | cut -d ' ' -f1 | sed 's/://g'`
if [ -z $activein ]; then
echo "Interface not found" >> /root/bw_limit.log
exit
fi
fi
if [ ! -z $bwvalue ]; then
echo "Bandwidth limit is $bwfile $activein $bwvalue $bwvalue" >> /root/bw_limit.log
$bwfile $activein $bwvalue $bwvalue
fi
else
/usr/bin/yum install -y wondershaper
echo "Wonder shaper is not installed and we are trying to install wondershaper" >> /root/bw_limit.log
exit
fi