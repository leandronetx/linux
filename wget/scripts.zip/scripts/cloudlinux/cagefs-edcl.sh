#!/bin/bash

if [ "$#" -ne 2 ]
then
        echo "Missing Argument";
        exit 1;
fi

username=$1
params=$2

case $params in
        enable)
                #echo "cagefsctl --enable $username"
                cagefsctl --enable $username
                ;;
        disable)
                #echo "cagefsctl --disable $username"   
                cagefsctl --disable $username
                ;;
        *)
                echo "Wrong Argument" 
                exit 1;;
esac
