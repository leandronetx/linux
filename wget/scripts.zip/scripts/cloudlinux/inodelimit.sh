cl-quota --user-id=500 --soft-limit=0 --hard-limit=0
