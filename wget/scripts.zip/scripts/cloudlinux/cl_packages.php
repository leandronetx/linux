<?php
$cagefs_cmd="cagefsctl --init";
shell_exec($cagefs_cmd);
$cl_pk_user=shell_exec("lvectl list-user --json");
$value=json_decode($cl_pk_user,true);
print_r($value);
$value=array_filter($value['data']);
$default_pk = $value[0];
$dspeed = $default_pk['SPEED'];
$dcpu = $default_pk['CPU'];
$dpmem = $default_pk['PMEM'];
$dvmem = $default_pk['VMEM'];
$dep = $default_pk['EP'];
$dnproc = $default_pk['NPROC'];
$dio = $default_pk['IO'];
$diops = $default_pk['IOPS'];
        
include "/etc/sentora/panel/cnf/database.php";

try
{
	$conn = new PDO($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
	// set the PDO error mode to exception
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
	echo "Connection failed: " . $e->getMessage();
}

$sql="select ac_id_pk,ac_user_vc from x_accounts where ac_deleted_ts IS NULL AND ac_id_pk != 1";
$stmt = $conn->prepare($sql);
$stmt->execute();
$row_count = $stmt->rowCount();
if ($row_count == 0 ){
	echo "User Is Empty";
	exit;
}

$ac_user=$stmt->fetchAll();
#echo "ac_user \n";
#print_r($ac_user);
#exit;
foreach( $ac_user as $user ){
	$username = $user['ac_user_vc'];
	$AC_userid = $user['ac_id_pk'];
	$cagefsuser_cmd="cagefsctl --enable $username";
	shell_exec($cagefsuser_cmd);		
	$userid = shell_exec("grep \"^$username\" /etc/passwd | awk -F\":\" '{ print $3 }' | tr -d \"\n\"");
	echo "userid $userid";
	$inodelimit_cmd="cl-quota --user-id=$userid --soft-limit=5000 --hard-limit=5000";
	echo "inodelimit_cmd $inodelimit_cmd \n";
	shell_exec($inodelimit_cmd);	
	$lvectl_set_user = "lvectl set-user $username";
	echo "lvectl_set_user $lvectl_set_user \n";
	shell_exec($lvectl_set_user);
	$lvectl_set_cmd = "lvectl set $userid --speed=$dspeed% --ncpu=$dcpu --pmem=$dpmem --vmem=$dvmem --maxEntryProcs=$dep --nproc=$dnproc --io=$dio --iops=$diops";
	echo "lvectl_set_cmd $lvectl_set_cmd \n";
	shell_exec($lvectl_set_cmd);
	
	/*	
	$phpsql="select x_php_version from x_phpversion_upgrade where x_client_id=$AC_userid";
	echo "phpsql $phpsql \n";
	$phpVer = $conn->prepare($phpsql);
	$phpVer->execute();
	$phprow = $phpVer->rowCount();

	if($phprow == 0){
        	echo "PHP Version Is Empty";
		continue;
	}
        $phpVersion=$phpVer->fetch();
	#print_r($phpVersion);
	#exit;
	$PHPVerCL = $phpVersion['x_php_version'];
	$phpExtEnCL_cmd="php /scripts/cloudlinux/en_selector_user.php $username $PHPVerCL";
	*/

	$phpExtEnCL_cmd="php /scripts/cloudlinux/en_selector_user.php $username";
	echo "phpExtEnCL_cmd $phpExtEnCL_cmd \n";
	shell_exec($phpExtEnCL_cmd);				
}
$conn = null;
?>
