<?php
$username = "";
$phpVer= "5.6";
if(isset($argv[1]) && isset($argv[2])){
	$username = "--user=".$argv[1];
	$phpVer= $argv[2];
}
else{
	shell_exec("selectorctl --enable-alternative=4.4");
	shell_exec("selectorctl --enable-alternative=5.1");
	shell_exec("selectorctl --enable-alternative=5.2");
	shell_exec("selectorctl --enable-alternative=5.3");
	shell_exec("selectorctl --enable-alternative=5.4");
	shell_exec("selectorctl --enable-alternative=5.5");
	shell_exec("selectorctl --enable-alternative=5.6");
	shell_exec("selectorctl --enable-alternative=7.0");
	shell_exec("selectorctl --enable-alternative=7.1");
	shell_exec("selectorctl --enable-alternative=7.2");
	shell_exec("selectorctl --enable-alternative=7.3");
}		

echo "selectorctl --list";
$selectorctl_list=shell_exec("selectorctl --list");
echo $selectorctl_list;
echo "selectorctl --set-current=$phpVer $username";
shell_exec("selectorctl --set-current=$phpVer $username");

$php44_extn=shell_exec("grep \"^php44en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php44_extn --version=4.4 $username");
$php51_extn=shell_exec("grep \"^php51en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php51_extn --version=5.1 $username");
$php52_extn=shell_exec("grep \"^php52en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php52_extn --version=5.2 $username");
$php53_extn=shell_exec("grep \"^php53en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php53_extn --version=5.3 $username");
$php54_extn=shell_exec("grep \"^php54en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php54_extn --version=5.4 $username");
$php55_extn=shell_exec("grep \"^php55en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php55_extn --version=5.5 $username");
$php56_extn=shell_exec("grep \"^php56en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php56_extn --version=5.6 $username");
$php70_extn=shell_exec("grep \"^php70en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php70_extn --version=7.0 $username");
$php71_extn=shell_exec("grep \"^php71en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php71_extn --version=7.1 $username");
$php72_extn=shell_exec("grep \"^php72en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php72_extn --version=7.2 $username");
$php73_extn=shell_exec("grep \"^php73en:\" /scripts/cloudlinux/php_extension_en.txt | awk -F\":\" '{ print $2 }' | tr -d \"\n\"");
shell_exec("selectorctl --enable-extensions=$php73_extn --version=7.3 $username");

?>
