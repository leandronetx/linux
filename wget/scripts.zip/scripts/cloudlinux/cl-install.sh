#!/bin/bash

if [ "$#" -ne 2 ]
then
	echo "Wrongly arg";exit;	
fi
mkdir -p /etc/sentora/configs/cloudlinux
activation_key=$1
ProceedInstall_log=$2
wget https://repo.cloudlinux.com/cloudlinux/sources/cln/cldeploy
sh cldeploy -k $activation_key
yum -y install kernel lve cagefs lvemanager lve-utils lve-stats --disableexcludes=main
yum -y groupinstall alt-php --skip-broken
yum -y install quota

get_dir=$(dirname "$ProceedInstall_log")
echo $get_dir;
if [ "$get_dir" == "/etc/sentora/configs/cloudlinux" ]
then
	rm -rf $ProceedInstall_log;
fi
echo "Initialed Started" > /etc/sentora/configs/cloudlinux/Initialed_Key.txt
reboot
