<?php
$hrp_to_hrp_backup = new HrPanelToHrPanelMigrationBackup();
$hrp_to_hrp_backup->getHostBackup();
class HrPanelToHrPanelMigrationBackup
{
	private $zdbh;
        private $mail_db;
	private $time_stamp;
	private $vhost_path;
	private $backup_filename;
	private $backup_path;
        public function __construct()
        {
            	require('/etc/sentora/panel/cnf/db.php');
            	require_once('/etc/sentora/panel/dryden/db/driver.class.php');
            	include_once('/etc/sentora/panel/dryden/debug/logger.class.php');
            	include_once('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
            	include_once('/etc/sentora/panel/dryden/runtime/controller.class.php');
            	include_once('/etc/sentora/panel/dryden/runtime/hook.class.php');
            	include_once('/etc/sentora/panel/dryden/sys/versions.class.php');
           	include_once('/etc/sentora/panel/dryden/ctrl/options.class.php');
           	include_once('/etc/sentora/panel/dryden/fs/director.class.php');
           	include_once('/etc/sentora/panel/dryden/fs/filehandler.class.php');
           	include_once('/etc/sentora/panel/inc/dbc.inc.php');
           	$mailserver_db = ctrl_options::GetSystemOption('mailserver_db');
           	try
          	{
               		$this->zdbh = new db_driver("mysql:host=".$host.";dbname=".$dbname."", $user, $pass);
               		$this->mail_db = new db_driver("mysql:host=".$host.";dbname=".$mailserver_db."", $user, $pass);
           	}
            	catch (PDOException $e)
            	{
            	 	exit();
            	}
		date_default_timezone_set('Asia/Calcutta');
		$this->time_stamp = date("M-d-Y_hms", time());
		$this->vhost_path = ctrl_options::GetSystemOption('hosted_dir');
		//$this->backup_filename= "full_backup_for_migration_$this->time_stamp";
		$this->backup_path = "/backup/migration/";
		if(!is_dir($this->backup_path)) { echo "directory not exist"; shell_exec('mkdir -p '.$this->backup_path); }
		$this->backup_filename= $this->backup_path."full_backup_for_migration_$this->time_stamp";
        } 
	public function getHostBackup()
	{
		echo "\nHostdata backup started...";
		$zip_hostdata_cmd = "cd $this->vhost_path && zip -r $this->backup_filename ./ 2>&1 ";
		shell_exec($zip_hostdata_cmd);
		echo "\nHostdata backup end...";
		self::getVmailBackup();
		echo "\nFull backup end...";
	}
	public function getVmailBackup()
        {
		echo "\nVmail backup started...";
		$mail  = "Mail_migrate";
                //$dest_path= "/backup/";
		//$mail_zip = $dest_path.$mail;
		$mail_zip = $this->backup_path.$mail;

                $src_path = "/var/sentora/vmail/";
                $cmd="cd $src_path && zip -r $mail_zip ./ 2>&1 ";
		shell_exec($cmd);

		$zip_vmail_cmd = "cd $this->backup_path && zip -ur $this->backup_filename $mail.zip 2>&1 ";
                shell_exec($zip_vmail_cmd);
		if(file_exists($mail_zip.".zip")) shell_exec("rm -rf $mail_zip.zip");
		echo "\nVmail backup end...";
		self::getDbBackup();
        }
	public function getDbBackup()
        {
		echo "\nDatabase backup started...";
		$mysql_bak_dir = $this->backup_path."mysql_migrate/";
		exec("mkdir -p ".$mysql_bak_dir);
		$db_bak_cmd = "cd $mysql_bak_dir && ".ctrl_options::GetSystemOption('mysqldump_exe')." --all-databases > all_database.sql";
		shell_exec($db_bak_cmd);
		$zip_vmail_cmd = "cd $this->backup_path && zip -ur $this->backup_filename mysql_migrate 2>&1 ";
                shell_exec($zip_vmail_cmd);
		if(file_exists($mysql_bak_dir) && ($mysql_bak_dir !="" || $mysql_bak_dir !="/") )
		{
			shell_exec('rm -rf '.$mysql_bak_dir);
		}
		echo "\nDatabase backup end...";
        }
}
?>
