if [ "$#" == 5 ]
then
username=$1
domain_name=$2
domain_path=$3
port=$4
app_path=$5
filename=$(echo $domain_name | sed 's/\*./wildcard_/g')
mkdir -p /var/sentora/logs/nodejs/$username
pm2 start $app_path --name $domain_name --user $username --uid $username --gid $username --error /var/sentora/logs/nodejs/$username/$filename-node-error.log --output /var/sentora/logs/nodejs/$username/$filename-node-out.log   
pm2 save
pm2 startup systemd
chown $username:$username /var/sentora/logs/nodejs/$username
chown $username:$username /var/sentora/logs/nodejs/$username/$filename-node-error.log
chown $username:$username /var/sentora/logs/nodejs/$username/$filename-node-out.log
n_dom_conf_file="/etc/sentora/configs/apache/domains/$filename"".conf"
n_node_dom_conf_file="/etc/sentora/configs/apache/nodejs/$filename"".conf"
n_dom_ssl_conf_file="/etc/sentora/configs/apache/domains/ssl_$filename"".conf"
mkdir -p /etc/sentora/configs/apache/nodejs/
echo "ProxyRequests off" > $n_node_dom_conf_file
echo "<Proxy *>"  >> $n_node_dom_conf_file
echo "AllowOverride All"  >> $n_node_dom_conf_file
echo "Require all granted"  >> $n_node_dom_conf_file
echo "</Proxy>"  >> $n_node_dom_conf_file
echo "<Location />"  >> $n_node_dom_conf_file
echo "ProxyPass  http://localhost:$port/"  >> $n_node_dom_conf_file
echo "ProxyPassReverse http://localhost:$port/"  >> $n_node_dom_conf_file
echo "</Location>"  >> $n_node_dom_conf_file        
virtual_detail1=$(grep -no "</virtualhost>" $n_dom_conf_file);
line6=$(echo $virtual_detail1 | awk '{print $1}' FS=":");
virtual_ssl_detail1=$(grep -no "</virtualhost>" $n_dom_ssl_conf_file);
linessl6=$(echo $virtual_ssl_detail1 | awk '{print $1}' FS=":");
if [[ $line6 = *[[:digit:]]* ]]; then
 echo "came here";
   one=1
   line7=`expr $line6 - $one`
                linessl7=`expr $linessl6 - $one`
                config_detail=$( echo "IncludeOptional $n_node_dom_conf_file" | sed 's/\//\\\//g' );
		echo "${line7}a $config_detail " $n_dom_conf_file
                sed -i "${line7}a $config_detail " $n_dom_conf_file
                sed -i "${linessl7}a $config_detail " $n_dom_ssl_conf_file
        fi
SERVICE_PATH=`whereis service | awk '{print $2}'`
`$SERVICE_PATH httpd restart`
`$SERVICE_PATH csf restart`
`$SERVICE_PATH lfd restart`
fi
