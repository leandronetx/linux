conf_file_path="/etc/sysctl.conf"
sysctl_path=`whereis sysctl | awk '{print $2}'`
mem_bytes=$(awk '/MemTotal:/ { printf "%0.f",$2 * 1024}' /proc/meminfo)
mem_gb=$(awk '/MemTotal:/ { printf "%0.f",$2 / 1048576 }' /proc/meminfo)
shmmax=$(echo "$mem_bytes * 0.90" | bc | cut -f 1 -d '.')
shmall=$(expr $mem_bytes / $(getconf PAGE_SIZE))
msgmni=`expr $mem_gb \* 1024`
shmmni=`expr $mem_gb \* 256`
max_orphan=$(echo "$mem_bytes * 0.10 / 65536" | bc | cut -f 1 -d '.')
file_max=$(echo "$mem_bytes / 4194304 * 256" | bc | cut -f 1 -d '.')
max_tw=$(($file_max*2))
min_free=$(echo "($mem_bytes / 1024) * 0.01" | bc | cut -f 1 -d '.')
msgmax=65536
msgmax_original=`$sysctl_path kernel.msgmax | awk '{print $3}'`
if [ "$msgmax_original" -lt "$msgmax" ]
then
    sed -i /kernel.msgmax/d $conf_file_path
    echo "kernel.msgmax = $msgmax" >> $conf_file_path
    echo "kernel.msgmax value updated"
else
    echo "kernel.msgmax Already update"
fi
msgmnb_original=`$sysctl_path kernel.msgmnb | awk '{print $3}'`
if [ "$msgmnb_original" -lt "$msgmax" ]
then
    sed -i /kernel.msgmnb/d $conf_file_path
    echo "kernel.msgmnb = $msgmax" >> $conf_file_path
    echo "kernel.msgmnb value updated"
else
    echo "kernel.msgmnb Already update"
fi
shmmax_original=`$sysctl_path kernel.shmmax | awk '{print $3}'`
if [ "$shmmax_original" -lt "$shmmax" ]
then
    sed -i /kernel.shmmax/d $conf_file_path
    echo "kernel.shmmax = $shmmax" >> $conf_file_path
    echo "kernel.shmmax value updated"
else
    echo "kernel.shmmax Already update"
fi
shmall_original=`$sysctl_path kernel.shmall | awk '{print $3}'`
if [ "$shmall_original" -lt "$shmall" ]
then
    sed -i /kernel.shmall/d $conf_file_path
    echo "kernel.shmall = $shmall" >> $conf_file_path
    echo "kernel.shmall value updated"
else
    echo "kernel.shmall Already update"
fi
msgmni_original=`$sysctl_path kernel.msgmni | awk '{print $3}'`
if [ "$msgmni_original" -lt "$shmall" ]
then
    sed -i /kernel.msgmni/d $conf_file_path
    echo "kernel.msgmni = $msgmni" >> $conf_file_path
    echo "kernel.msgmni value updated"
else
    echo "kernel.msgmni Already update"
fi
shmmni_original=`$sysctl_path kernel.shmmni | awk '{print $3}'`
if [ "$shmmni_original" -lt "$shmmni" ]
then
    sed -i /kernel.shmmni/d $conf_file_path
    echo "kernel.shmmni = $shmmni" >> $conf_file_path
    echo "kernel.shmmni value updated"
else
    echo "kernel.shmmni Already update"
fi
SEMMSL_original=`$sysctl_path kernel.sem | awk '{print $3}'`
SEMMSL_FINAL=250
SEMMNS_original=`$sysctl_path kernel.sem | awk '{print $4}'`
SEMMNS_FINAL=256000
SEMOPM_original=`$sysctl_path kernel.sem | awk '{print $5}'`
SEMOPM_FINAL=32
SEMMNI_original=`$sysctl_path kernel.sem | awk '{print $6}'`
SEMMNI_FINAL=`expr $mem_gb \* 256`
if [ "$SEMMNI_original" -lt "$SEMMNI_FINAL" ]
then
    sed -i /kernel.sem/d $conf_file_path
    echo "kernel.sem = $SEMMSL_FINAL $SEMMNS_FINAL $SEMOPM_FINAL $SEMMNI_FINAL" >> $conf_file_path
else 
    sed -i /kernel.sem/d $conf_file_path
    echo "kernel.sem = $SEMMSL_original $SEMMNS_original $SEMOPM_original $SEMMNI_original" >> $conf_file_path
fi
$sysctl_path -p $conf_file_path
