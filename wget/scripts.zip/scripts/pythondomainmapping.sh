if [ "$#" == 6 ]
then
mkdir -p /etc/sentora/configs/apache/python/
domain_name=$1 
python_version=$2
domain_path=$3 
full_wsgi_path=$4 
full_virtual_env=$5 
username=$6
conf=".conf"
ssl="ssl_"
filename=$(echo $domain_name | sed 's/\*./wildcard_/g')
python_file_conf="/etc/sentora/configs/apache/python/$filename$conf"
ssl_python_file_conf="/etc/sentora/configs/apache/python/ssl_$filename$conf"
echo "WSGIScriptAlias / $full_wsgi_path" > $python_file_conf
echo "WSGIDaemonProcess $domain_name user=$username group=$username threads=5 python-home=$full_virtual_env" >> $python_file_conf
echo "WSGIScriptAlias / $full_wsgi_path" > $ssl_python_file_conf
echo "WSGIDaemonProcess ssl_$domain_name user=$username group=$username threads=5 python-home=$full_virtual_env" >> $ssl_python_file_conf
include_opt_str=$( echo "IncludeOptional $python_file_conf" | sed 's/\//\\\//g')
include_opt_str_ssl=$( echo "IncludeOptional $ssl_python_file_conf" | sed 's/\//\\\//g')
#sed -i "/IncludeOptional/c\\$include_opt_str" /etc/sentora/configs/apache/domains/$domain_name$conf
#sed -i "/IncludeOptional/c\\$include_opt_str_ssl" /etc/sentora/configs/apache/domains/$ssl$domain_name$conf
#service httpd reload
domain_ssl_conf_path="/etc/sentora/configs/apache/domains/$ssl$filename$conf"
domain_conf_path="/etc/sentora/configs/apache/domains/$filename$conf"
virtual_detail1=$(grep -no "</virtualhost>" $domain_conf_path);
line6=$(echo $virtual_detail1 | awk '{print $1}' FS=":");
virtual_ssl_detail1=$(grep -no "</virtualhost>" $domain_ssl_conf_path);
linessl6=$(echo $virtual_ssl_detail1 | awk '{print $1}' FS=":");
        if [[ $line6 = *[[:digit:]]* ]]; then
                one=1
                line7=`expr $line6 - $one`
                linessl7=`expr $linessl6 - $one`
                sed -i "${line7}a $include_opt_str " $domain_conf_path
                sed -i "${linessl7}a $include_opt_str_ssl " $domain_ssl_conf_path
        fi
        SERVICE_PATH=`whereis service | awk '{print $2}'`
        `$SERVICE_PATH httpd restart`
fi
