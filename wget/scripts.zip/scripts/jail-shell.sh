#!/bin/bash
#jail Shell
if [ "$#" -ne 2 ]
then
	echo "$# Wrong Arugments"
	exit;
fi

username=$1
param=$2
jailshell=`whereis jail-shell | awk '{ print $2 }'`
samplefile="/etc/jail-shell/jail-config/sample-jail.cfg"
userfile="/etc/jail-shell/jail-config/$username-jail.cfg"
passwd="/etc/passwd"
HOST_DIR=`/etc/sentora/panel/bin/setso --show hosted_dir`
case $param in

	jail)
		echo "jail";
		echo "samplefile $samplefile"
		echo "userfile $userfile"
		if [ ! -f $userfile ]
		then	
			echo "file not"
			cp -pr $samplefile $userfile
		fi		
		sed -i -e "s/OVIPANELSAMPLE/$username/g" $userfile
		$jailshell jail -i $username-jail
		$jailshell user -a $username -j $username-jail
		nobashpath=$(grep "^$username:" $passwd | awk -F":" '{print $NF}')
                bashpath='/bin/bash'
                srcvalue=$(echo "$HOST_DIR$username:$nobashpath" | sed 's/\//\\\//g')
                dsrvalue=$(echo "$HOST_DIR$username:$bashpath" | sed 's/\//\\\//g')
                sed -i -e "s/$srcvalue/$dsrvalue/g" $passwd
		echo "bind $HOST_DIR$username rw,dev,exec,suid" >> $userfile
		echo "bind $HOST_DIR$username $HOST_DIR$username rw,dev,exec,suid" >> $userfile
		echo "dir $HOST_DIR 0755 root:root" >> $userfile
	;;

	normal)
		echo "normal";
		$jailshell user -d $username
		$jailshell jail -d $username-jail		                
		nobashpath=$(grep "^$username:" $passwd | awk -F":" '{print $NF}')
		bashpath='/bin/bash'
		srcvalue=$(echo "$HOST_DIR$username:$nobashpath" | sed 's/\//\\\//g')
		dsrvalue=$(echo "$HOST_DIR$username:$bashpath" | sed 's/\//\\\//g')
		sed -i -e "s/$srcvalue/$dsrvalue/g" $passwd
	;;

	*)
		$jailshell user -d $username
		$jailshell jail -d $username-jail		                
		nobashpath=$(grep "^$username:" $passwd | awk -F":" '{print $NF}')
                bashpath='/sbin/nologin'
                srcvalue=$(echo "$HOST_DIR$username:$nobashpath" | sed 's/\//\\\//g')
                dsrvalue=$(echo "$HOST_DIR$username:$bashpath" | sed 's/\//\\\//g')
                sed -i -e "s/$srcvalue/$dsrvalue/g" $passwd	
	;;	

esac	
