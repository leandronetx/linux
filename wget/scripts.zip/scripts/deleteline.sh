if [ "$#" == 3 ]
then
username=$1
domain_name=$2
path=$3
delete_line=$(echo "$username => $domain_name => $path" | sed 's/\//\\\//g' | sed 's/*/\\*/g')
sed -i "/$delete_line/d" /etc/sentora/configs/OneclickInstall
fi
