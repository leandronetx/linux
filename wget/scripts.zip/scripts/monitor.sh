#!/usr/bin/env bash
date=`date +"%Y-%m-%d %H-%M-%S"`
tot=`free -h |grep Mem:| awk '{print $2}'`
used=`free -h |grep Mem:| awk '{print $3}'`
free=`free -h |grep Mem:| awk '{print $4}'`

totdsk=`df -h |grep root| awk '{print $2}'`
useddsk=`df -h |grep root| awk '{print $3}'`
availdsk=`df -h |grep root| awk '{print $4}'`

load1=`w | grep "load average" | awk '{print $10}' |tr -d ,`
load2=`w | grep "load average" | awk '{print $11}' |tr -d ,`
load3=`w | grep "load average" | awk '{print $12}' |tr -d ,`

cpulod=`mpstat | grep all | awk '{print $4}'`


#if [ ! -f /root/monitor.txt ]
#then
#    touch /root/monitor.txt
#    mysqladmin proc > /root/monitor.txt
#else
#       mysqladmin proc > /root/monitor.txt
#fi

#val=`awk '{print $12}' /root/monitor.txt | sort -n | tail -1`
#sql=`grep $val /root/monitor.txt |tr -d " "`

#echo -e "$date;RAM:Total-$tot,used-$used,free-$free|Disk:Total-$totdsk,used-$useddsk,free-$availdsk|Load:Avgload-$load1 $load2 $load3|CPU:$cpulod%|\nSQL DBLoad:\n(Id|User|Host|db|Command|Time|State|Info)\n($sql)"

echo -e "$date;RAM:Total-$tot,used-$used,free-$free|Disk:Total-$totdsk,used-$useddsk,free-$availdsk|Load:Avgload-$load1 $load2 $load3|CPU:$cpulod%---\n"


