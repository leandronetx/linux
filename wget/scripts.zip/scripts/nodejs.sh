#!/bin/sh
install_detail=1
nulldata=/dev/null
function check_node_js_installed
{
	if  yum list installed |grep -F 'nodejs' >$nulldata
	then 
		echo "" >$nulldata
	else 
		curl --silent --location http://hostingraja.info/Version2.0/setup_8.x | sudo bash -
  		yum install gcc-c++ make -y
  		yum install -y nodejs
 	 	npm install -g pm2
	 	npm install -g grunt-cli
  		npm install -g gulp
 		npm install webpack -g
		pm2 startup systemd
		#pm2 update
		#npm install pm2@latest -g		
	fi 
}

function remove_nodejs_config
{
	n_dom_conf_file=$1
	proxy_request_detail=$(grep -no "ProxyRequests"  $n_dom_conf_file);
	rev_proxy_request_detail=""
	for i in $proxy_request_detail
	do
  		rev_proxy_request_detail="$i $rev_proxy_request_detail"
	done
	for  iprx  in $rev_proxy_request_detail
	do
		line1=$(echo $iprx | awk '{print $1}' FS=":");
		if [[ $line1 = *[[:digit:]]* ]]; then
			sed -i "${line1}d" $n_dom_conf_file;
		fi
	done
	proxy_detail1=$(grep -no "<Proxy" $n_dom_conf_file);
	line2=$(echo $proxy_detail1 | awk '{print $1}' FS=":");
	if [[ $line2 = *[[:digit:]]* ]]; then
		proxy_detail2=$(grep -no "</Proxy" $n_dom_conf_file);
		line3=$(echo $proxy_detail2 | awk '{print $1}' FS=":");
		if [[ $line3 = *[[:digit:]]* ]]; then
			sed -i  "${line2},${line3}d" $n_dom_conf_file
		fi
                #        sed -i "${line1}d" $n_dom_conf_file;
	fi

	loc_detail1=$(grep -no "<Location" $n_dom_conf_file);
        line4=$(echo $loc_detail1 | awk '{print $1}' FS=":");
        if [[ $line4 = *[[:digit:]]* ]]; then
                loc_detail2=$(grep -no "</Location" $n_dom_conf_file);
                line5=$(echo $loc_detail2 | awk '{print $1}' FS=":");
                if [[ $line5 = *[[:digit:]]* ]]; then
                        sed -i  "${line4},${line5}d" $n_dom_conf_file
                fi
                #        sed -i "${line1}d" $n_dom_conf_file;
        fi
}

function create_nodejs_file
{
	node_content="\"<div style='width:100%;height:20px;color:#629338;text-align:center;'>Hosting raja node js server started,<br>replace this content with your content </div>\"";
	domain_path=$1
	domain_port=$2
	node_file_txt="const http = require('http');\n";
	node_file_txt+="const port = $domain_port;\n";
	node_file_txt+="const ip = '0.0.0.0';\n";
	node_file_txt+="http.createServer(function (req, res) {\n";
	node_file_txt+="res.writeHead(200, {'Content-Type': 'text/html'});\n";
	node_file_txt+="res.end($node_content);\n";
	node_file_txt+="}).listen(port, ip);";
	index_file=$domain_path"/index.js"
	index_file_bk=$index_file"_bk";
	if [ -f  $index_file ]
	then
		yes | cp -avr $index_file $index_file_bk > $nulldata;
	fi
	echo -e $node_file_txt  > $domain_path"/index.js";
	pm2 delete $index_file
	pm2 start $index_file
	pm2 save
}
function add_nodejs_config
{
	n_dom_conf_file=$1
	n_dom_conf_port=$2
	virtual_detail1=$(grep -no "</virtualhost>" $n_dom_conf_file);
	line6=$(echo $proxy_detail1 | awk '{print $1}' FS=":");
	if [[ $line6 = *[[:digit:]]* ]]; then
		line7=$line6-1
		config_detail="ProxyRequests off\n";
    		$config_detail+="<Proxy *>";
		result1=`httpd -v | cut -d ":" -f2 | head -1 | cut -d "/" -f2 |cut -d " " -f1`
		result2=2.4
		function version_gt() { test "$(printf '%s\n' "$@" | sort -V | head -n 1)" != "$1"; }
		if version_gt $result1 $result2; then
			$config_detail+="\tAllowOverride All\n";
			$config_detail+="\tRequire all granted\n";
		else
			$config_detail+="\tAllowOverride All\n";
		   	$config_detail+="\tRequire all granted\n";
		fi
        	$config_detail+="AllowOverride All";
	    	$config_detail+="Require all granted";
    		$config_detail+="</Proxy>";
		$config_detail+="<Location />";
        	$config_detail+="ProxyPass  http://localhost:$n_dom_conf_port/";
        	$config_detail+="ProxyPassReverse http://localhost:$n_dom_conf_port/";
		$config_detail+="</Location>";
		sed -i "${line7}a $config_detail " $n_dom_conf_file 		
	fi	
}

function restart_server
{
	if [ $ver_d == "7" ]
	then
		systemctl stop  varnish
		systemctl restart httpd
	else
		service varnish stop
		service httpd restart
	fi
}

if [ "$#" -lt 3 ]
#enable apache ovihosting.com 3000
then
	echo "Enter all parameter ";
	$install_detail=2
else
	ver_d=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
	proc_status=$1;
	serv_status=$2;
	dom_detail=$3
	apache_path="/etc/sentora/configs/apache/domains/"	
	case  $proc_status in 
		enable)
			nodejs_port=$4
			case $serv_status in
			apache)
				check_node_js_installed;
				dom_dir_path=$5
				dom_conf_file=$apache_path$dom_detail".conf"
				dom_conf_back_file=$dom_conf_file"_bk"
				if [ -f  $dom_conf_file ]
				then
					yes | cp -avr $dom_conf_file $dom_conf_back_file > $nulldata;
					remove_nodejs_config $dom_conf_file;
					virtual_detail=$(grep -no "</virtualhost>"  $dom_conf_file);
					line6=$(echo $virtual_detail | awk '{print $1}' FS=":");
					if [[ $line6 = *[[:digit:]]* ]]; then
						line7=$((line6 - 1))
						config_detail="ProxyRequests off\n";
                        			config_detail+="<Proxy *>\n";
						result1=`httpd -v | cut -d ":" -f2 | head -1 | cut -d "/" -f2 |cut -d " " -f1`
						result2=2.4
						function version_gt() { test "$(printf '%s\n' "$@" | sort -V | head -n 1)" != "$1"; }
						if version_gt $result1 $result2; then
						     config_detail+="\tAllowOverride All\n";
							 config_detail+="\tRequire all granted\n";
						else
							config_detail+="\tAllowOverride All\n";
							config_detail+="\tRequire all granted\n";
						fi
                        			config_detail+="</Proxy>\n";
                        			config_detail+="<Location />\n";
                       				config_detail+="\tProxyPass  http://localhost:$nodejs_port/\n";
                       				config_detail+="\tProxyPassReverse http://localhost:$nodejs_port/\n";
                       				config_detail+="</Location>\n";
                        			sed -i "${line7}a ${config_detail}" $dom_conf_file
						DB_NAME='sentora_core'
						SQL_Query="SELECT count(*) FROM x_ssl WHERE ssl_doamin='$dom_detail' AND ssl_delete IS NULL;"
						DB_SSL=`mysql --socket=/usr/local/mysql/mysql.sock -D $DB_NAME --skip-column-names -e "$SQL_Query"`
						CRT_Query="SELECT count(*) FROM x_ssl_crt WHERE ssl_crt_doamin='$dom_detail' AND ssl_crt_delete IS NULL;"
						DB_CRT=`mysql --socket=/usr/local/mysql/mysql.sock -D $DB_NAME --skip-column-names -e "$CRT_Query"`
						if [ $DB_SSL -gt 0 -o $DB_CRT -gt 0 ]; then
							ssl_dom_conf_file=$apache_path'ssl_'$dom_detail'.conf'
							ssl_dom_conf_back_file=$ssl_dom_conf_file'_httpd2'
							yes | cp -avr $ssl_dom_conf_file $ssl_dom_conf_back_file > $nulldata;
                                        		remove_nodejs_config $ssl_dom_conf_file;
							ssl_virtual_detail=$(grep -no "</VirtualHost>"  $ssl_dom_conf_file);
							ssl_line6=$(echo $ssl_virtual_detail | awk '{print $1}' FS=":");
							if [[ $ssl_line6 = *[[:digit:]]* ]]; then
								ssl_line7=$((ssl_line6 - 1))
								sed -i "${ssl_line7}a ${config_detail}" $ssl_dom_conf_file
							fi
						fi
						echo $dom_dir_path
						create_nodejs_file $dom_dir_path $nodejs_port
						restart_server
					else
						install_detail=2
					fi
					
				else
					install_detail=2
				fi 
			;;
			nginx)
				echo "Nginx server, for now nothing to do ";
				
			;;
			*)
				install_detail=2
			;;
			esac
		;;
		disable)
			case $serv_status in 
			apache)
				domain_path=$4
				rs_status=$5
				dom_conf_file=$apache_path$dom_detail".conf"
                                dom_conf_back_file=$dom_conf_file"_bk"
                                if [ -f  $dom_conf_file ]
                                then
                                        yes | cp -avr $dom_conf_file $dom_conf_back_file > $nulldata;
                                        remove_nodejs_config $dom_conf_file;
					DB_NAME='sentora_core'
                                        SQL_Query="SELECT count(*) FROM x_ssl WHERE ssl_doamin='$dom_detail' AND ssl_delete IS NULL;"
                                        DB_SSL=`mysql --socket=/usr/local/mysql/mysql.sock -D $DB_NAME --skip-column-names -e "$SQL_Query"`
                                        CRT_Query="SELECT count(*) FROM x_ssl_crt WHERE ssl_crt_doamin='$dom_detail' AND ssl_crt_delete IS NULL;"
                                        DB_CRT=`mysql --socket=/usr/local/mysql/mysql.sock -D $DB_NAME --skip-column-names -e "$CRT_Query"`
                                        if [ $DB_SSL -gt 0 -o $DB_CRT -gt 0 ]; then
                                        	ssl_dom_conf_file=$apache_path'ssl_'$dom_detail'.conf'
                                                ssl_dom_conf_back_file=$ssl_dom_conf_file'_httpd2'
                                                yes | cp -avr $ssl_dom_conf_file $ssl_dom_conf_back_file > $nulldata;
                                                remove_nodejs_config $ssl_dom_conf_file;
                                        fi
					index_file=$domain_path"/index.js";
        				pm2 delete $index_file
        				pm2 save
					if [ $rs_status == "1" ]
					then 
						restart_server
					fi
				fi 
			;;
			*)
				echo "";
			;;
			esac			
		;;

		*)
			echo "";
		;;
	esac
fi
	
