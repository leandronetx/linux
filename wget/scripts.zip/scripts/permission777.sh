touch /var/sentora/logs/permission777.log
: > /var/sentora/logs/permission777.log
chmod 644 /var/sentora/logs/permission777.log
chown ovipanel. /var/sentora/logs/permission777.log
HOSTED_DIR=`/etc/sentora/panel/bin/setso --show hosted_dir`
find $HOSTED_DIR -perm 0777 -type f -name "*.php" > /var/sentora/logs/permission777.log
find $HOSTED_DIR -type d -perm 0777 >> /var/sentora/logs/permission777.log
