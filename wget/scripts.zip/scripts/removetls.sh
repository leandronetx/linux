postfixSslCheck()
{
        postfix_smtp_tls_res=`grep -ni "smtp_use_tls" $1 | grep "yes"`
        postfix_smtpd_tls_res=`grep -ni "smtpd_use_tls" $1 | grep "yes"`
        smtpd_tls_cert_file_res=`grep -ni "smtpd_tls_cert_file" $1 | grep $2`
        smtpd_tls_ca_file_res=`grep -ni "smtpd_tls_CAfile" $1 | grep $2`
        smtpd_tls_key_file_res=`grep -ni "smtpd_tls_key_file" $1  | grep $2`
        if [ "$postfix_smtp_tls_res" == "" ] || [ "$postfix_smtpd_tls_res" == "" ]; then
                        return_val="TLS_NOT_COFIGURED_IN_POSTFIX"
                else
                        return_val="TLS_COFIGURED_IN_POSTFIX"
                
        fi
}

dovecotSslCheck()
{
        ssl_conf_check=`grep -ni "ssl" $1 | grep "yes"`
        ssl_cert_exists=`grep -ni "ssl_cert" $1 | grep $2`
        ssl_key_exists=`grep -ni "ssl_key" $1 | grep $2`
        ssl_ca_exists=`grep -ni "ssl_ca" $1 | grep $2`
	if [ "$ssl_conf_check" == "" ] || [ "$ssl_cert_exists" == "" ] || [ "$ssl_key_exists" == "" ] || [ "$ssl_ca_exists" == "" ]; then
			return_val="TLS_NOT_COFIGURED_IN_DOVECOT"
                else
                        return_val="TLS_CONFIGURED_IN_DOVECOT"

        fi
}



removeTlsFromDevecot()
{
        echo "removeTlsFromDevecot TEST";
        ssl_enable_line_no=`grep -ni "ssl" $1 | head -1 | awk -F":" '{print $1}'`
        ssl_change_to_no=$ssl_enable_line_no"s/.*/ssl = no/"
        sed -i "$ssl_change_to_no" $1
        sed -i '/ssl_cert/d' $1
        sed -i '/ssl_key/d' $1
        sed -i '/ssl_ca/d' $1
        sed -i '/include domains/d' $1
}
removeTlsFromPostfix()
{
        sed -i '/smtp_use_tls/d' $1
        sed -i '/smtpd_use_tls/d' $1
        sed -i '/smtpd_tls_received_header/d' $1
        sed -i '/smtpd_tls_session_cache_timeout/d' $1
        sed -i '/smtpd_tls_security_level/d' $1
        sed -i '/smtp_tls_note_starttls_offer/d' $1
        sed -i '/tls_random_source/d' $1
        sed -i '/smtpd_tls_loglevel/d' $1
        sed -i '/smtpd_tls_cert_file/d' $1
        sed -i '/smtpd_tls_CAfile/d' $1
        sed -i '/smtpd_tls_key_file/d' $1
}

restartPostfix()
{
        SERVICE_SERV=`whereis service | awk '{ print $2}'`
        $SERVICE_SERV postfix restart
}
restartDovecot()
{
        SERVICE_SERV=`whereis service | awk '{ print $2}'`
        $SERVICE_SERV dovecot restart

}

files="/var/sentora/logs/tls.log"
POSTFIX_CONF="/etc/postfix/main.cf"
POSTFIX_MASTER_CONF="/etc/postfix/master.cf"
DOVECOT_CONF="/etc/dovecot/dovecot.conf"
HOSTNAME_SERV=`whereis hostname | awk '{ print $2 }'`
host_name=`$HOSTNAME_SERV`
host_name="${host_name,,}"
dovecotSslCheck $DOVECOT_CONF $host_name
dovecot_ssl_check_res=`echo $return_val`
postfixSslCheck $POSTFIX_CONF $host_name
postfix_ssl_check=`echo $return_val`
if [ "$dovecot_ssl_check_res" == "TLS_CONFIGURED_IN_DOVECOT" ] || [ "$postfix_ssl_check" == "TLS_COFIGURED_IN_POSTFIX" ]; then

		removeTlsFromDevecot $DOVECOT_CONF
                removeTlsFromPostfix $POSTFIX_CONF
                restartPostfix
                restartDovecot
		echo "TLS_REMOVED" > $files
		echo "TLS_REMOVED"
		exit
        else
        	echo "TLS_NOT_REMOVED" > $files
		echo "TLS_NOT_REMOVED"
		exit
fi
