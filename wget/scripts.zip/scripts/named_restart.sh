echo "starting named restart" >> /etc/sentora/panel/modules/server/php-multithreaded-socket-server-master/server.log
/sbin/service named restart
