<?php
        if($argc > 1) {
                include_once("/etc/sentora/panel/cnf/db.php");
                $conn = mysqli_connect($host,$user,$pass,$dbname);

                // Check connection
                if (mysqli_connect_errno())
                {
                        echo "Failed to connect to MySQL: " . mysqli_connect_error();
                }
                $sql    = "SELECT ac_email_vc FROM sentora_core.x_accounts WHERE ac_user_vc='zadmin'";
                $result = $conn->query($sql);
                $email  = $result->fetch_row()[0];
                //$conn->close();
                // To send HTML mail, the 'Content-type' header must be set
                $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

                // Additional headers
                $headers .= 'From: Support <support@hostingraja.in>' . "\r\n";
                mail($email,"Disk Space Alert","you already crossed $argv[1]%. Your root partition remaining free space is critically low.",$headers);
        }
?>