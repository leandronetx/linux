#!/bin/sh
unset IFS                                 # default of space, tab and nl
                                          # Wait for filesystem events
inotifywait -rm -e close_write /etc/sentora/panel | while read dir op file
do
	if [ $op == "CLOSE_WRITE,CLOSE" ]
	then
		if [[ ${file: -4} == ".php" || ${file: -5} == ".ztml" ]]
		then 
			echo "Dir is " $dir
			echo "File is " $file
			#check md5 checksum, If not matching chmod to 000
			GetFromDB=$(echo "SELECT checksum FROM x_md5_file where path='$dir$file'" | /usr/local/mysql/bin/mysql -N --socket="/usr/local/mysql/mysql.sock" sentora_core)
			getCurrentSum=`md5sum "$dir$file"  | awk '{ print $1 }'`
			if [ "$GetFromDB" == "$getCurrentSum" ]
			then
				echo "No issues" >/dev/null 2>&1
			else
				#echo "Need to change the permission"
				echo "File Permission changed - $dir$file" >> /var/sentora/logs/inotifywait.log
				CHMOD_PATH=`whereis chmod | awk '{print $2}'`
				`$CHMOD_PATH 000 $dir$file`
			fi
		fi
	fi
done

