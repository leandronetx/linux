#some functions used many times below
# Random password generator function
passwordgen() {
    l=$1
    [ "$l" == "" ] && l=16
    tr -dc A-Za-z0-9 < /dev/urandom | head -c ${l} | xargs
}
PANEL_PATH="/etc/sentora"
PANEL_CONF="$PANEL_PATH/configs"
Old_Root="2kxlL7f4iotgYFJM"
Old_Postfix="gK7QbNDstOc3YVim"
Old_ProFTPd="7YUUyhBXoKMrgRqG"
Old_Roundcube="DGSBAE4F6cAe1frl"
ROUNDCUBE_DESKEY="ilwBzOJ1K6mgP0a6ozJZ7oxP"
blowfishsecret="KpoVI5T8oSo6QwUo"
Old_PublicIp="103.145.50.3"
old_PRIVATE_IP="103.145.50.3"
old_cnf_sec="XD7ZqnXY93fCagfalaXA86"

PUBLIC_IP="NEW_PUBLIC_IP"
PRIVATE_IP="NEW_PRIVATE_IP"
PANEL_FQDN="NEW_HOSTNAME"
HOSTNAME="NEW_HOSTNAME"

clientemailid="CLIENT_EMAIL"
#echo "Public IP:$PUBLIC_IP"
#echo "Private Ip: $PRIVATE_IP"

#--- Prepare hostname
old_hostname=$(cat /etc/hostname)
# In file hostname
echo "$PANEL_FQDN" > /etc/hostname
service crond stop
service mysqldovi stop
service mysqld restart
service mysqldovi restart
service crond start
# In file hosts
sed -i "/127.0.1.1[\t ]*$old_hostname/d" /etc/hosts
sed -i "s|$old_hostname|$PANEL_FQDN|" /etc/hosts
sed -i "s|$old_hostname|$PANEL_FQDN|" /etc/hosts
sed -i "s|$old_PRIVATE_IP|$PRIVATE_IP|" /etc/hosts

mysqlpassword=$(passwordgen);

getkey=`cat /etc/ovi/.key`
php_path=`whereis php | awk '{ print $2 }'`
$php_path /etc/sentora/panel/dbencrypt.php $getkey $mysqlpassword

# For current session
hostname "$PANEL_FQDN"
service inotifywait stop
#--- Set some Sentora database entries using. setso and setzadmin (require PHP)
echo -e "\n-- Configuring Sentora"
cnf_sec=$(passwordgen 22);
sed -i "s|$old_cnf_sec|$cnf_sec|" /etc/sentora/panel/cnf/security.php
chmod 644 /etc/sentora/panel/cnf/security.php
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly  /etc/sentora/panel/cnf/security.php
chmod +x /usr/bin/setzadmin
zadminpassword=$(passwordgen);
/usr/bin/setzadmin --regen --set "$zadminpassword";
$PANEL_PATH/panel/bin/setso --set sentora_domain "$PANEL_FQDN"
$PANEL_PATH/panel/bin/setso --set server_ip "$PUBLIC_IP"
rm -f /etc/sentora/configs/apache/sentora/sentora.conf
$PANEL_PATH/panel/bin/setso --set apache_changed true
php /etc/sentora/panel/bin/daemon.php
# Create and configure mysql password for roundcube
roundcubepassword=$(passwordgen);
sed -i "s|$Old_Roundcube|$roundcubepassword|" $PANEL_CONF/roundcube/roundcube_config.inc.php
/usr/local/mysql/bin/mysql --socket="/usr/local/mysql/mysql.sock"  -e "UPDATE mysql.user SET Password=PASSWORD('$roundcubepassword') WHERE User='roundcube' AND Host='localhost'";
mysql -e "ALTER USER 'roundcube'@'localhost' IDENTIFIED BY '$roundcubepassword'"

# Create and configure des key
roundcube_des_key=$(passwordgen 24);
sed -i "s|$ROUNDCUBE_DESKEY|$roundcube_des_key|" $PANEL_CONF/roundcube/roundcube_config.inc.php
chmod 644 $PANEL_CONF/roundcube/roundcube_config.inc.php
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly $PANEL_CONF/roundcube/roundcube_config.inc.php 

#--- phpMyAdmin
phpmyadminsecret=$(passwordgen);
sed -i "s|\$cfg\['blowfish_secret'\] \= '$blowfishsecret';|\$cfg\['blowfish_secret'\] \= '$phpmyadminsecret';|" /etc/sentora/panel/etc/apps/phpmyadmin/config.inc.php
sed -i "s|\$cfg\['blowfish_secret'\] \= '$blowfishsecret';|\$cfg\['blowfish_secret'\] \= '$phpmyadminsecret';|" /etc/sentora/panel/etc/apps/phpmyadmin_v4_6_6/config.inc.php
sed -i "s|\$cfg\['blowfish_secret'\] \= '$blowfishsecret';|\$cfg\['blowfish_secret'\] \= '$phpmyadminsecret';|" /etc/sentora/panel/etc/apps/phpmyadmin_4_8_4/config.inc.php
# ln -s $PANEL_CONF/phpmyadmin/config.inc.php $PANEL_PATH/panel/etc/apps/phpmyadmin/config.inc.php
chmod 644 /etc/sentora/panel/etc/apps/phpmyadmin/config.inc.php 
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly  /etc/sentora/panel/etc/apps/phpmyadmin/config.inc.php

chmod 644 /etc/sentora/panel/etc/apps/phpmyadmin_v4_6_6/config.inc.php
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly  /etc/sentora/panel/etc/apps/phpmyadmin_v4_6_6/config.inc.php

chmod 644 /etc/sentora/panel/etc/apps/phpmyadmin_4_8_4/config.inc.php
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly  /etc/sentora/panel/etc/apps/phpmyadmin_4_8_4/config.inc.php

# Create and configure mysql password for proftpd
proftpdpassword=$(passwordgen);
sed -i "s|$Old_ProFTPd|$proftpdpassword|" $PANEL_CONF/proftpd/proftpd-mysql.conf
sed -i "s|$Old_ProFTPd|$proftpdpassword|" /etc/proftpd.conf
/usr/local/mysql/bin/mysql --socket="/usr/local/mysql/mysql.sock" -e "UPDATE mysql.user SET Password=PASSWORD('$proftpdpassword') WHERE User='proftpd' AND Host='localhost'";
mysql -e "ALTER USER 'proftpd'@'localhost' IDENTIFIED BY '$proftpdpassword'"
sed -i '/MasqueradeAddress/d' /etc/proftpd.conf
echo "MasqueradeAddress $PUBLIC_IP" >> /etc/proftpd.conf
#--- Postfix

postfixpassword=$(passwordgen);
/usr/local/mysql/bin/mysql --socket="/usr/local/mysql/mysql.sock" -e "UPDATE mysql.user SET Password=PASSWORD('$postfixpassword') WHERE User='postfix' AND Host='localhost';";
mysql -e "ALTER USER 'postfix'@'localhost' IDENTIFIED BY '$postfixpassword'"


sed -i "s|$Old_Postfix|$postfixpassword|" $PANEL_CONF/postfix/*.cf
sed -i "s|$Old_Postfix|$postfixpassword|" $PANEL_CONF/postfix/vacation.conf
sed -i "s|$Old_Postfix|$postfixpassword|" $PANEL_CONF/dovecot2/dovecot-mysql.conf

# Setup acl IP to forbid zone transfer
sed -i "s|$Old_PublicIp|$PUBLIC_IP|" $PANEL_CONF/bind/named.conf
/usr/local/mysql/bin/mysql --socket="/usr/local/mysql/mysql.sock" -e "update sentora_core.x_accounts set ac_email_vc='$clientemailid' where ac_id_pk=1;"
mysql  -e "FLUSH PRIVILEGES"
/usr/local/mysql/bin/mysql --socket="/usr/local/mysql/mysql.sock"  -e "FLUSH PRIVILEGES"

/usr/local/mysql/bin/mysql --socket="/usr/local/mysql/mysql.sock"  -e "UPDATE mysql.user SET Password=PASSWORD('$mysqlpassword') WHERE User='root' AND Host='localhost'"
mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '$mysqlpassword'"

mysql  -e "FLUSH PRIVILEGES"
/usr/local/mysql/bin/mysql --socket="/usr/local/mysql/mysql.sock"  -e "FLUSH PRIVILEGES"
sed -i "s|$Old_Root|$mysqlpassword|" /root/.my.cnf
#sed -i "s|$Old_Root|$mysqlpassword|"  /etc/sentora/panel/cnf/db.php
chmod 644 /etc/sentora/panel/cnf/db.php 
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly /etc/sentora/panel/cnf/db.php 
sed -i "s|$Old_Root|$mysqlpassword|"  /scripts/mysql_maint.sh
sed -i "s|$Old_Root|$mysqlpassword|"  /scripts/mysql_maint_ovi.sh
sed -i "s|$old_hostname|$PANEL_FQDN|" /etc/postfix/main.cf
sed -i "s|$Old_PublicIp|$PUBLIC_IP|" /etc/postfix/main.cf
sed -i "s|$old_hostname|$PANEL_FQDN|" $PANEL_CONF/postfix/main.cf
sed -i "s|$Old_PublicIp|$PUBLIC_IP|" $PANEL_CONF/postfix/main.cf
$PANEL_PATH/panel/bin/setso --set apache_changed "true"
#cd /etc
#wget -O csf.zip http://hostingraja.info/Version2.7/csf.zip
#unzip -o csf.zip
#chmod 600 /etc/csf/csf.conf
#chmod 600 /etc/csf/csf.pignore
#/usr/bin/openssl req -x509 -nodes -days 730 -newkey rsa:2048 -keyout /etc/csf/ui/server.key -out /etc/csf/ui/server.crt -subj "/C=IN/ST=Karnataka/L=Bengalore/O=OVI/OU=IT Department/CN=HRPANEL"
# Bandwidth Usage Reset
################################# SELF SIGNED SSL CERTIFICATE #############################
mkdir /etc/httpd/httpscertificate
cd /etc/httpd/httpscertificate
openssl genrsa -des3 -passout pass:x -out keypair.key 2048
openssl rsa -passin pass:x -in keypair.key -out /etc/httpd/httpscertificate/$PUBLIC_IP.key
openssl req -new -key /etc/httpd/httpscertificate/$PUBLIC_IP.key -subj "/C=IN/ST=karnataka/L=bangalore/O=ovipanel/OU=software/CN=$PUBLIC_IP" -keyout /etc/httpd/httpscertificate/$PUBLIC_IP.key -out /etc/httpd/httpscertificate/$PUBLIC_IP.csr
openssl x509 -req -days 365 -in /etc/httpd/httpscertificate/$PUBLIC_IP.csr -signkey /etc/httpd/httpscertificate/$PUBLIC_IP.key -out /etc/httpd/httpscertificate/$PUBLIC_IP.crt
sed -i 's/^SSLCertificateFile.*/SSLCertificateFile \/etc\/httpd\/httpscertificate\/'$PUBLIC_IP'.crt/' /etc/httpd/conf.d/ssl.conf
sed -i 's/^SSLCertificateKeyFile.*/SSLCertificateKeyFile \/etc\/httpd\/httpscertificate\/'$PUBLIC_IP'.key/' /etc/httpd/conf.d/ssl.conf
cd ~
service httpd restart
################################# SELF SIGNED SSL CERTIFICATE #############################
vnstat=`whereis "vnstat" | awk {'print $2'}`
$vnstat --cleartop --force
csfpassword=$(passwordgen);
#sed -i "s|!hostingrajapwd!|$csfpassword|" /etc/csf/csf.conf
sed -i 's/.*UI_PASS.*/UI_PASS = "'$csfpassword'"/' /etc/csf/csf.conf
echo "CSF Username : ovicsf " >> /root/passwords.txt
echo "CSF Password : $csfpassword " >> /root/passwords.txt
/etc/init.d/csf restart
csf -r
csf -e
service lfd restart
php /etc/sentora/panel/bin/daemon.php
#sed -i "s|!USR_LIB!|$USR_LIB_PATH|" $PANEL_CONF/postfix/master.cf
#sed -i "s|!USR_LIB!|$USR_LIB_PATH|" $PANEL_CONF/postfix/main.cf
mv /root/passwords.txt /root/passwords_hold.txt
service proftpd restart
service postfix restart
service dovecot restart
service spamassassin restart
service csf restart
service lfd restart
touch /root/passwords_vmware.txt
echo "$zadminpassword:$mysqlpassword:$csfpassword" > /root/passwords_vmware.txt
echo "IP Address :  $PUBLIC_IP" > /etc/sentora/panel/version.txt
echo "Created Date : "`date +%d-%m-%Y' '%H:%M:%S` >> /etc/sentora/panel/version.txt
echo "Version : 3.6C" >> /etc/sentora/panel/version.txt
rm -f /root/pwd.txt

touch  /root/passwords_hold.txt
{
    echo "Server IP address : $PUBLIC_IP"
    echo "Panel URL         : http://$PUBLIC_IP:2086"
    echo "zadmin Password   : $zadminpassword"
    echo ""
    echo "MySQL Root Password      : $mysqlpassword"
    echo "MySQL Postfix Password   : $postfixpassword"
    echo "MySQL ProFTPd Password   : $proftpdpassword"
    echo "MySQL Roundcube Password : $roundcubepassword"
    echo "CSF Username : ovicsf "
    echo "CSF Password : $csfpassword "

} >> /root/passwords.txt


`php /etc/sentora/panel/createIP.php $PUBLIC_IP`
php /etc/sentora/panel/generate_key_for_email_encryption.php
rm -f /etc/sentora/panel/generate_key_for_email_encryption.php
#--- Advise the admin that Sentora is now installed and accessible.
service inotifywait start
/usr/bin/php /etc/sentora/panel/modules/server/php-multithreaded-socket-server-master/server.php >> /etc/sentora/panel/modules/server/php-multithreaded-socket-server-master/server.log &
/usr/bin/php /etc/sentora/panel/modules/daemonserver/php-multithreaded-socket-server-master/server.php >> /etc/sentora/panel/modules/daemonserver/php-multithreaded-socket-server-master/server.log &


############################# FILE PERMISSION FOR OVIPANEL #######################

chown spamd. /usr/bin/spamfilter.sh
chmod 700 /usr/bin/spamfilter.sh
chmod 700 /usr/bin/phpsendingmail.php
chmod 700 /usr/local/bin/phpsendmail.php
chmod 755 /etc/sentora/
chmod 755 /etc/sentora/docs/
chmod 700 /etc/proftpd.conf
chmod 700 /etc/sentora/configs/proftpd/proftpd-mysql.conf
cd /etc/sentora/configs/
chown dovecot. -R dovecot2
find /etc/sentora/configs/dovecot2 -type f -exec chmod 700 {} \;
chmod 644 /etc/sentora/configs/dovecot2/dovecot-trash.conf
chown postfix. -R /etc/sentora/configs/postfix
chmod 600 /etc/sentora/configs/postfix/mysql-virtual_mailbox_maps.cf
chmod 600 /etc/sentora/configs/postfix/mysql-relay_domains_maps.cf
chmod 600 /etc/sentora/configs/postfix/mysql-virtual_alias_maps.cf
chmod 600 /etc/sentora/configs/postfix/mysql-virtual_domains_maps.cf
chmod 600 /etc/sentora/configs/postfix/mysql-virtual_mailbox_limit_maps.cf
chmod 600 /etc/sentora/configs/postfix/vacation.conf
chown -R ovipanel. /etc/sentora/configs/roundcube
chmod 600 /etc/sentora/configs/roundcube/sieve_config.inc.php 
chmod 600 /etc/sentora/configs/roundcube/roundcube_config.inc.php
rm -frv /etc/sentora/configs/ovi-install/
chmod 755 /usr/local/bin/pflogsumm-1.1.1
chown ovipanel. -R /usr/local/bin/pflogsumm-1.1.1
chmod 600 /usr/local/bin/pflogsumm-1.1.1/pflogsumm.pl
rm -f /etc/postfix/log_test
chmod 700 /var/mailq
chmod 700 /usr/bin/perl
chmod 700 /usr/bin/perl5.16.3
chmod 755 /var/sentora/backups
setso --set apache_backup false
chmod 600 /var/sentora/logs/inotifywait.log
chmod 700 /var/opt/remi/php74/tmp
chmod 700 /var/opt/remi/php72/tmp
chmod 700 /var/opt/remi/php73/tmp
chmod 700 /var/opt/remi/php71/tmp
chmod 700  /var/opt/remi/php70/tmp
chmod 700 /opt/remi/php56/root/var/tmp
chmod 700 /opt/remi/php55/root/var/tmp
chmod 700 /opt/remi/php54/root/var/tmp
chmod 700 /opt/remi/php54/root/tmp
chmod 700 /opt/remi/php55/root/tmp
chmod 700 /opt/remi/php56/root/tmp
chmod 700 /opt/remi/php70/root/tmp
chmod 700 /opt/remi/php71/root/tmp
chmod 700 /opt/remi/php72/root/tmp
chmod 700 /opt/remi/php73/root/tmp
chmod 700 /opt/remi/php74/root/tmp
chmod 600 /etc/sentora/configs/apache/httpd-vhosts.conf_dont_use
chown ovipanel. /var/sentora/logs/sentora-error.log
chown -R root. /var/log/spamavoid
chmod 755 /var/log/spamavoid
chmod 444 /var/log/spamavoid/php_execution_block.php
chown apache. /var/log/spamavoid/php_execution_block.log
chown apache. /var/log/spamavoid/php_execution_allow.txt
chmod 666 /var/log/spamavoid/php_execution_block.log
chmod 666 /var/log/spamavoid/php_execution_allow.txt
chmod 666 /var/log/x_php_page_block.log
chown apache. /var/log/x_php_page_block.log
rm -f /var/log/rootmaillog
chmod 666 /var/log/cxscgi.log
chown apache. /var/log/cxscgi.log
chown apache. /var/log/mail_php.log
chmod 666 /var/log/mail_php.log
chown ovipanel. /var/log/mail_php.log
chmod 666 /var/log/mail_php.log
chmod 666 /var/log/smtp_log
chown apache:apache  /var/log/smtp_log
chmod -R 0755 /var/spool/autoresponse
chmod 600 /etc/sentora/panel/cnf/database.php
chmod 600 /etc/sentora/panel/.dbroot
chmod 600 /etc/sentora/iriscryt.txt
chsh -s /sbin/nologin ovipanel
#$PANEL_PATH/panel/bin/setso --set openbase_temp "/tmp/:/tmp/:/var/lib/php/session/"
#$PANEL_PATH/panel/bin/setso --set upload_temp_dir "/tmp/"
#$PANEL_PATH/panel/bin/setso --set temp_dir "/tmp/"
touch /var/log/login_ip.log
chown ovipanel. /var/log/login_ip.log
chmod 644 /var/log/login_ip.log
chown named:named /etc/sentora/configs/bind -R
chmod 755 /etc/sentora/configs/bind/zones
chown -R named:named /var/named/
chown named:named /etc/named.conf
chmod 600 /etc/named.conf
touch /var/log/spamavoid/mail_php.log
touch /var/log/spamavoid/mail_php_mod_change.log
touch /var/log/spamavoid/x_php_page_block.log
chmod 666 /var/log/spamavoid/mail_php.log
chmod 666 /var/log/spamavoid/mail_php_mod_change.log
chmod 666 /var/log/spamavoid/x_php_page_block.log
chown apache. /var/log/spamavoid/mail_php.log
chown apache. /var/log/spamavoid/mail_php_mod_change.log
chown apache. /var/log/spamavoid/x_php_page_block.log
############################# FILE PERMISSION FOR OVIPANEL #######################
############################# FILE PERMISSION FOR OVIPANEL #######################
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly  /etc/sentora/panel/cnf/security.php
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly /etc/sentora/configs/roundcube/roundcube_config.inc.php
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly  /etc/sentora/panel/etc/apps/phpmyadmin/config.inc.php
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly  /etc/sentora/panel/etc/apps/phpmyadmin_v4_6_6/config.inc.php
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly  /etc/sentora/panel/etc/apps/phpmyadmin_4_8_4/config.inc.php
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly /etc/sentora/panel/cnf/db.php
$PANEL_PATH/panel/bin/setso --set sentora_domain "$PANEL_FQDN"
$PANEL_PATH/panel/bin/setso --set server_ip "$PUBLIC_IP"
$PANEL_PATH/panel/bin/setso --set apache_changed true

service crond stop
service inotifywait stop
/usr/bin/setzadmin --regen --set "$zadminpassword";
php /etc/sentora/panel/md5_file_creation.php UpdateparticularKeyOnly  /etc/sentora/panel/cnf/security.php
service crond start
service inotifywait start
