CP_SERVICE=`whereis cp | awk '{print $2}'`
SER_SERVICE=`whereis service | awk '{print $2}'`
cp /etc/dovecot/dovecot.conf /etc/dovecot/dovecot.conf_bkup_preserve
cp /etc/postfix/main.cf /etc/postfix/main.cf_bkup_preserve
cd /etc/sentora/panel/
wget -O class.zip http://hostingraja.info/Version2.9/Patch/class.zip
unzip -o class.zip
PHP_PATH=`whereis php | awk '{print $2}'`
`$PHP_PATH /etc/sentora/panel/class/DovecotConfSSLSetup.php`
OUTPUT=`$PHP_PATH /etc/sentora/panel/class/MainConfTLSSetup.php`
$SER_SERVICE postfix restart
$SER_SERVICE dovecot restart
rm -frv /etc/sentora/panel/class.zip
rm -frv /etc/sentora/panel/class/
$SER_SERVICE postfix status
$SER_SERVICE dovecot status
