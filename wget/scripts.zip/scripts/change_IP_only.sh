#!/bin/sh
oldip=$1
newip=$2
/etc/sentora/panel/bin/setso --set server_ip $newip
mysql --socket="/usr/local/mysql/mysql.sock" -e "Use sentora_core; UPDATE x_dns SET dn_target_vc = REPLACE(dn_target_vc,'$oldip','$newip');"
mysql --socket="/usr/local/mysql/mysql.sock" -e "Use sentora_core; UPDATE x_changeip SET ci_ip = REPLACE(ci_ip,'$oldip','$newip');"
output=$(mysql  --socket="/usr/local/mysql/mysql.sock" -e "Use sentora_core; select GROUP_CONCAT(vh_id_pk) from x_vhosts where vh_deleted_ts IS NULL")
IP=$(echo $output | awk '{print $2}')
echo $IP
/etc/sentora/panel/bin/setso --set dns_hasupdates "$IP"
cd /etc/sentora/configs/apache/domains/
rm -rf ./*
cd /etc/sentora/configs/apache/sentora/
rm -rf ./*
cd /root
sed -i 's/'$oldip'/'$newip'/g' passwords.txt
sed -i 's/'$oldip'/'$newip'/g' /etc/postfix/main.cf

################################# SELF SIGNED SSL CERTIFICATE #############################
mkdir /etc/httpd/httpscertificate
cd /etc/httpd/httpscertificate
openssl genrsa -des3 -passout pass:x -out keypair.key 2048
openssl rsa -passin pass:x -in keypair.key -out /etc/httpd/httpscertificate/$newip.key
openssl req -new -key /etc/httpd/httpscertificate/$newip.key -subj "/C=IN/ST=karnataka/L=bangalore/O=ovipanel/OU=software/CN=$newip" -keyout /etc/httpd/httpscertificate/$newip.key -out /etc/httpd/httpscertificate/$newip.csr
openssl x509 -req -days 365 -in /etc/httpd/httpscertificate/$newip.csr -signkey /etc/httpd/httpscertificate/$newip.key -out /etc/httpd/httpscertificate/$newip.crt
sed -i 's/^SSLCertificateFile.*/SSLCertificateFile \/etc\/httpd\/httpscertificate\/'$newip'.crt/' /etc/httpd/conf.d/ssl.conf
sed -i 's/^SSLCertificateKeyFile.*/SSLCertificateKeyFile \/etc\/httpd\/httpscertificate\/'$newip'.key/' /etc/httpd/conf.d/ssl.conf
cd ~
service httpd restart
################################# SELF SIGNED SSL CERTIFICATE #############################

/etc/sentora/panel/bin/setso --set apache_changed true
php /etc/sentora/panel/bin/daemon.php
