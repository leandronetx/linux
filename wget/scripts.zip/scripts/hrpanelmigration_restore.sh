mkdir -p /backups/restore
cd /backups && unzip hrmigration.zip -d  /backups/restore
rm -rf /var/sentora/hostdata
rm -rf /var/sentora/vmail
mv -f /backups/restore/hostdata /var/sentora
mv -f /backups/restore/vmail /var/sentora
chown -R apache. /var/sentora/hostdata
chmod -R 755 /var/sentora/hostdata
chmod -R 755 /var/sentora/vmail
chown -R vmail:mail /var/sentora/vmail
chown -R apache. /var/sentora/hostdata
mysql < /backups/restore/backups/mysql/mysql.sql
rm -fr /backups/restore/

