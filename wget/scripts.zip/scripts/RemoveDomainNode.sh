if [ "$#" == 2 ]
then
	username=$1 
	domain_name=$2
	#DEL_LINE=$username" => "$domain_name" => "
        filename=$(echo $domain_name | sed 's/\*./wildcard_/g')
        DEL_LINE=$(echo $username" => "$domain_name" => " | sed 's/*/\\*/g' )
	pm2 delete $domain_name
	pm2 save
	python_conf="/etc/sentora/configs/node_domain"
	echo $DEL_LINE
	sed -i -e "/$DEL_LINE/d" $python_conf	
	conf=".conf"
	ssl="ssl_"
	domain_conf="/etc/sentora/configs/apache/domains/$filename$conf"
	ssl_domain_conf="/etc/sentora/configs/apache/domains/$ssl$filename$conf"
	node_conf_file="/etc/sentora/configs/apache/nodejs/$filename"".conf"
	echo '' > $node_conf_file
 	DEL_LINE=$(echo "IncludeOptional $node_conf_file" | sed 's/\//\\\//g')
	sed -i -e "/$DEL_LINE/d" $domain_conf
	sed -i -e "/$DEL_LINE/d" $ssl_domain_conf	
	SERVICE_PATH=`whereis service | awk '{print $2}'`
	`$SERVICE_PATH httpd restart`
fi
