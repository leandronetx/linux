<?php
if($argc!==2)
{
	echo "could you please pass the parameters correctly.";
	exit();
}
require('/etc/sentora/panel/cnf/db.php');
include('/etc/sentora/panel/dryden/db/driver.class.php');
include('/etc/sentora/panel/dryden/debug/logger.class.php');
include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
include('/etc/sentora/panel/dryden/runtime/hook.class.php');
include('/etc/sentora/panel/dryden/sys/versions.class.php');
include('/etc/sentora/panel/dryden/ctrl/options.class.php');
include('/etc/sentora/panel/dryden/fs/director.class.php');
include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
include('/etc/sentora/panel/inc/dbc.inc.php');
$z_db_user = $user;
$z_db_pass = $pass;
try 
{
//    $zdbh = new db_driver("mysql:host=" . $host . ";dbname=" . $dbname . "", $user, $pass);
	$dsn = "mysql:dbname=$dbname;$ovi_socket_path";
        $zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
	$zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$mysqli=mysqli_connect("localhost",$user, $pass);
} catch (PDOException $e) {
exit();
}
$download=1;
if (isset($argv[1]) && $argv[1] != "") {
  
				$username=trim($argv[1]);
				$rows = $zdbh->prepare("
				SELECT * FROM x_accounts 
				LEFT JOIN x_profiles ON (x_accounts.ac_id_pk=x_profiles.ud_user_fk) 
				LEFT JOIN x_groups   ON (x_accounts.ac_group_fk=x_groups.ug_id_pk) 
				LEFT JOIN x_packages ON (x_accounts.ac_package_fk=x_packages.pk_id_pk) 
				LEFT JOIN x_quotas   ON (x_accounts.ac_package_fk=x_quotas.qt_package_fk) 
				WHERE x_accounts.ac_user_vc= :ac_user_vc AND x_accounts.ac_deleted_ts is NULL
				");
				$rows->bindParam(':ac_user_vc', $username);
				$rows->execute();
				$res_count = $rows->rowCount();
				if($res_count > 0 ) {
				/*if ($rows->fetchColumn() != 0) {		
					$rows = $zdbh->prepare("
					SELECT * FROM x_accounts 
					LEFT JOIN x_profiles ON (x_accounts.ac_id_pk=x_profiles.ud_user_fk) 
					LEFT JOIN x_groups   ON (x_accounts.ac_group_fk=x_groups.ug_id_pk) 
					LEFT JOIN x_packages ON (x_accounts.ac_package_fk=x_packages.pk_id_pk) 
					LEFT JOIN x_quotas   ON (x_accounts.ac_package_fk=x_quotas.qt_package_fk) 
					WHERE x_accounts.ac_user_vc= :ac_user_vc
					");
					$rows->bindParam(':ac_user_vc', $username);
					$rows->execute();*/
					$dbvals = $rows->fetch();
					$userid=$dbvals['ac_id_pk'];		
					$DBList="";
				$rows = $zdbh->prepare("
					SELECT * FROM  x_mysql_databases 
					WHERE x_mysql_databases.my_acc_fk=:ac_user_vc AND  x_mysql_databases.my_deleted_ts IS NULL
					");
					$rows->bindParam(':ac_user_vc', $userid);
					$rows->execute();
					$mysql_res_count = $rows->rowCount();
					if( $mysql_res_count > 0 )
					//if ($rows->fetchColumn() != 0) 
					{
						//$rows = $zdbh->prepare("SELECT * FROM  x_mysql_databases WHERE x_mysql_databases.my_acc_fk=:ac_user_vc AND  x_mysql_databases.my_deleted_ts IS NULL");
						//$rows->bindParam(':ac_user_vc', $userid);
						//$rows->execute();
						$total_bk_size_in_kb=0;
						while($dbvals = $rows->fetch())
						{

							if (mysqli_select_db($mysqli,$dbvals['my_name_vc'])) 
							{
								$DBList.=" ".$dbvals['my_name_vc'];
								$currentdb = new db_driver("mysql:host=$host;dbname=" . $dbvals['my_name_vc'] . "", $z_db_user, $z_db_pass);
								$currentdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
								$dbsize = $currentdb->query("SHOW TABLE STATUS");
								$dbgetsize = 0;
								while($row = $dbsize->fetch()) 
								{
									$dbgetsize = $dbgetsize + ($row['Data_length'] + $row['Index_length']);
									$dbgetsize *= 0.00012207;
								}
								$total_bk_size_in_kb += $dbgetsize;
								$available_size_in_kb=shell_exec("df | awk '{print $4}' | head -2 | tail -1");
								$overall_size_in_kb=shell_exec("df | awk '{print $2}' | head -2 | tail -1");
								if($available_size_in_kb < $total_bk_size_in_kb )
								{
									$msg="Due to disk space exceeed, your mysql backup not working. kindly contact your administrator.";
									echo $msg;
									exit;
								}
								$remaining_kb=$available_size_in_kb - $total_bk_size_in_kb;
								$remaining_percentage = $remaining_kb / $overall_size_in_kb * 100 ;
								if($remaining_percentage < 5 )
								{
									$msg="Due to disk space exceeed, your mysql backup not working. kindly contact your administrator.";
									echo $msg;
									exit;
								}
							}
							//$DBList.=" ".$dbvals['my_name_vc'];
						}
						
					}
					else
					{
						echo "No Database Available for Backup\n";
						exit;
					}
					//echo $DBList;
					if(trim($DBList)=="")
					{
						echo "No Database Available for Backup\n";
						exit;	
					}
					
			if ($backup = ExecuteBackup($userid, $username, $download,$DBList)) {
			echo "backup completed.";
			
			} else {
			
			echo "<h2>Unauthorized Access!</h2>";
			echo "You have no permission to view this module.";
			
			}
	}
	else
	{
	echo "Username does not exists.";
	exit();		
	}
}

function ExecuteBackup($userid, $username, $download = 0,$DBList) {
	include('/etc/sentora/panel/cnf/db.php');
   echo "backup Started. \n";
   // mysql_
	exec("mkdir -p /backup/".$username."/mysql");
	shell_exec("mkdir -p /backup/$username");
	$timestamp=date("M-d-Y_hms", time());
	$dest_path="/backup/".$username."/"."MySQL_".$username . "_" .$timestamp;
	$cur_file_name="MySQL_".$username . "_" .$timestamp.".zip";			
	$src_path="/backup/".$username."/";
    shell_exec("echo $cur_file_name > /backup/current_mysql_$username");
	$cmd="cd $src_path && zip -r $dest_path mysql 2>&1 ";
	$dbname=md5(sha1($username."SQL"));
	//--single-transaction - Since I am using InnoDB tables, I will want to use this option.
	echo $bkcommand =" cd /backup/$username/mysql && ".ctrl_options::GetSystemOption('mysqldump_exe')." -h ". $host . " -u " . $user . " -p'" . $pass . "' --databases $DBList > " . $dbname . ".sql ";
	$output=passthru($bkcommand,$return_val);           
	$output=array();
	$return_val="";
	$output=passthru($cmd,$return_val);
        /* //////////////////////////////////////  symlink Creation Started ////////////////////////////////////// */
        $vhost_dir=ctrl_options::GetSystemOption('hosted_dir');
         $cmd="mkdir -p ".$vhost_dir.$username."/backups/"." &&  cd ".$vhost_dir.$username."/backups/ && ln -S ".$cur_file_name." ".$src_path.$cur_file_name." ";
        shell_exec($cmd);
        $wheris_chown=trim(shell_exec("whereis chown | awk '{print $2}'"));
        shell_exec("$wheris_chown -R $username:$username ".$vhost_dir.$username."/backups");
        shell_exec("$wheris_chown -R $username:$username /backup/$username/mysql");

        /* //////////////////////////////////////  symlink Creation End ////////////////////////////////////// */
	 passthru(" rm -fr /backup/".$username."/mysql");
	return TRUE;
}

?>
