<?php
if($argc!==2)
{
	echo "could you please pass the parameters correctly.";
	exit();
}
require('/etc/sentora/panel/cnf/db.php');
include('/etc/sentora/panel/dryden/db/driver.class.php');
include('/etc/sentora/panel/dryden/db/mysqldriver.class.php');
include('/etc/sentora/panel/dryden/debug/logger.class.php');
include('/etc/sentora/panel/dryden/runtime/dataobject.class.php');
include('/etc/sentora/panel/dryden/runtime/hook.class.php');
include('/etc/sentora/panel/dryden/sys/versions.class.php');
include('/etc/sentora/panel/dryden/ctrl/options.class.php');
include('/etc/sentora/panel/dryden/fs/director.class.php');
include('/etc/sentora/panel/dryden/fs/filehandler.class.php');
include('/etc/sentora/panel/inc/dbc.inc.php');
try 
{
        $dsn = "mysql:dbname=$dbname;$ovi_socket_path";
        $zdbh = new db_driver($dsn, $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
        $zdbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    exit();
}
$download=1;
if (isset($argv[1]) && $argv[1] != "") {  
	$username=trim($argv[1]);
	$rows = $zdbh->prepare("SELECT a.* FROM x_accounts a,x_profiles p,x_groups g,x_packages pa,x_quotas q 
				WHERE a.ac_id_pk=p.ud_user_fk AND a.ac_group_fk=g.ug_id_pk AND a.ac_package_fk=pa.pk_id_pk 
				AND a.ac_package_fk=q.qt_package_fk AND a.ac_user_vc= :ac_user_vc AND a.ac_deleted_ts is NULL");
	$rows->bindParam(':ac_user_vc', $username);
	$rows->execute();
    	$res_count = $rows->fetch();
	if ($res_count) {
		//$rows = $zdbh->prepare("SELECT a.* FROM x_accounts a,x_profiles p,x_groups g,x_packages pa,x_quotas q  WHERE a.ac_id_pk=p.ud_user_fk AND a.ac_group_fk=g.ug_id_pk AND a.ac_package_fk=pa.pk_id_pk AND a.ac_package_fk=q.qt_package_fk AND a.ac_user_vc= :ac_user_vc");
        	//$rows->bindParam(':ac_user_vc', $username);
	        //$rows->execute();			
		//$dbvals = $rows->fetch();
		$userid=$dbvals['ac_id_pk'];							
    	if ($backup = ExecuteBackup($userid, $username, $download)) {			
			echo "backup completed.";			
		} else {			
			echo "<h2>Unauthorized Access!</h2>";
			echo "You have no permission to view this module.";			
		}
	}
	else
	{
	    echo "Username does not exists.";
	    exit();		
	}
}
function ExecuteBackup($userid, $username, $download = 0) {
    $vhost_dir=ctrl_options::GetSystemOption('hosted_dir');
    echo "backup Started. \n";
    shell_exec("mkdir -p /backup/$username");
	$timestamp= date("M-d-Y_hms", time());
	$dest_path="/backup/".$username."/"."home_".$username . "_" .$timestamp;
	$currentfilename="home_".$username . "_" .$timestamp.".zip";
    shell_exec("echo $currentfilename > /backup/current_home_$username");
	$src_path=$vhost_dir.$username."/";
	//$src_path="/var/sentora/hostdata/".$username."/";
	/* ///////////////////////////////////////// Calculating all data Start //////////////////////////////////////////////////// */
	//$total_bk_size_in_kb=0;
	$total_bk_size_in_kb = (int)shell_exec("du -sc $src_path --exclude=".$src_path."backups | cut -f1 | awk '{print $1; exit}'");
	//$total_bk_size_in_kb += $size;
	$available_size_in_kb = (int)trim(shell_exec("df | awk '{print $4}' | head -2 | tail -1"));
	$overall_size_in_kb = (int)trim(shell_exec("df | awk '{print $2}' | head -2 | tail -1"));
    echo "\ntotal_bk_size_in_kb ".$total_bk_size_in_kb;
    echo "\navailable_size_in_kb ".$available_size_in_kb;
    echo "\noverall_size_in_kb ".$overall_size_in_kb;
	if($available_size_in_kb < $total_bk_size_in_kb )
	{
	    $msg="Due to disk exceeed, your home backup does not taken. kindly contact your administrator.";
	    echo $msg;
	    return true;
	}
	$remaining_kb = $available_size_in_kb - $total_bk_size_in_kb;
	$remaining_percentage = $remaining_kb / $overall_size_in_kb * 100 ;
    echo "\nremaining_kb ".$remaining_kb;
    echo "\nremaining_percentage ".$remaining_percentage; 
	if($remaining_percentage < 5 )
	{
		$msg="Due to disk space exceeed, your home backup does not taken. kindly contact your administrator.";
		echo $msg;
		return true;
	}

	/* ///////////////////////////////////////// Calculating all data End //////////////////////////////////////////////////// */
	//$cmd="cd $vhost_dir && zip -r $dest_path $username 2>&1 ";
	$cmd="cd $src_path && zip -r $dest_path ./* -x ./backups/\*  2>&1 ";
	$output=array();
	$return_val="";
	$output=passthru($cmd,$return_val);
    	//exec("chown apache. -R /backup/$username");
    	exec("chown $username:$username -R /backup/$username");
    	//exec("chmod 755 -R /backup/$username");
	/* //////////////////////////////////////  symlink Creation Started ////////////////////////////////////// */
	$cmd="mkdir -p ".$vhost_dir.$username."/backups/"." &&  cd ".$vhost_dir.$username."/backups/ && ln -S ".$currentfilename." ".$dest_path.".zip";
	shell_exec($cmd);
	/* //////////////////////////////////////  symlink Creation End ////////////////////////////////////// */
	return TRUE;
}

?>
