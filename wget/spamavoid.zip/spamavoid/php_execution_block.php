<?php
$php_file_path = '';
$php_file_array = '';
$php_blacklist_array = '';
$hr_pac_result = '';
$hr_pac_result = '';
$php_file_path = $_SERVER['SCRIPT_FILENAME'];
$php_file_array = explode("/",$php_file_path);
$allowed_file_list = "/var/log/spamavoid/php_execution_allow.txt";
$RepalcedFilePath = str_replace("/","\/", $php_file_path);
$RepalcedFilePath = str_replace("*",".*", $RepalcedFilePath);
$check_allowed = shell_exec("grep $RepalcedFilePath $allowed_file_list");
if(!$check_allowed)
{
    $php_blacklist_array = array('uploads','upload','images','image','css');

    //$php_whitelist_array = array('wp-tinymce.php','captions.php');

    $hr_pac_result=array_intersect($php_file_array,$php_blacklist_array);

    //$hr_whitelist_result=array_intersect($php_file_array,$php_whitelist_array);

    if(count($hr_pac_result) > 0){
        //if(empty($hr_whitelist_result)){
        $block_list_file="/var/log/spamavoid/php_execution_block.log";
        $list_of_ip_files = file($block_list_file, FILE_IGNORE_NEW_LINES);
        if (!(($key = array_search($php_file_path, $list_of_ip_files)) !== false))
        {
                $fp = fopen($block_list_file, 'a');
                fwrite($fp, $php_file_path."\n");
                fclose($fp);
        }
        exit;

        //}
    }
}
?>
