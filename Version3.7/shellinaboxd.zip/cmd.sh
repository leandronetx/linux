#!/bin/bash

url=$(python -c "import os;url = os.environ['SHELLINABOX_URL'];print(url)")
token=$(python -c "import urlparse;import os;url = os.environ['SHELLINABOX_URL'];parsed = urlparse.urlparse(url);print urlparse.parse_qs(parsed.query)['token'][0]")
if [ "$token" == "terminal" ];
then
        echo "Enter the username:"
        read user
        echo "Enter the password:"
        read -s pass
        ip=$(python -c "import urlparse;import os;url = os.environ['SHELLINABOX_URL'];parsed = urlparse.urlparse(url);print urlparse.parse_qs(parsed.query)['ip'][0]")
        sshpass -p "$pass" ssh -o StrictHostKeyChecking=no -t "$user@$ip"
elif [ "$token" == "node" ]
then
        user=$(python -c "import urlparse;import os;url = os.environ['SHELLINABOX_URL'];parsed = urlparse.urlparse(url);print urlparse.parse_qs(parsed.query)['user'][0]")
        ip=$(python -c "import urlparse;import os;url = os.environ['SHELLINABOX_URL'];parsed = urlparse.urlparse(url);print urlparse.parse_qs(parsed.query)['ip'][0]")
        path=$(python -c "import urlparse;import os;url = os.environ['SHELLINABOX_URL'];parsed = urlparse.urlparse(url);print urlparse.parse_qs(parsed.query)['path'][0]")
        #path=`cat /etc/sentora/configs/terminal/$user`
        if [[  "$user" != "" &&  "$ip" != ""  && "$path" != "" ]]
        then
        echo "Enter the UCP password of user $user:"
        read -s pass
        sshpass -p "$pass" ssh -o StrictHostKeyChecking=no -t "$user@$ip" -t "cd $path ; bash"
        #sshpass -p "$pass" ssh -o StrictHostKeyChecking=no -t "$user@$ip" "cd /home/saravanab" 2>/dev/null 
        fi
elif [ "$token" == "python" ]
then
        user=$(python -c "import urlparse;import os;url = os.environ['SHELLINABOX_URL'];parsed = urlparse.urlparse(url);print urlparse.parse_qs(parsed.query)['user'][0]")
        ip=$(python -c "import urlparse;import os;url = os.environ['SHELLINABOX_URL'];parsed = urlparse.urlparse(url);print urlparse.parse_qs(parsed.query)['ip'][0]")
        path=$(python -c "import urlparse;import os;url = os.environ['SHELLINABOX_URL'];parsed = urlparse.urlparse(url);print urlparse.parse_qs(parsed.query)['path'][0]")
        venv=$(python -c "import urlparse;import os;url = os.environ['SHELLINABOX_URL'];parsed = urlparse.urlparse(url);print urlparse.parse_qs(parsed.query)['venv'][0]")
        #path=`cat /etc/sentora/configs/terminal/$user`
        if [[  "$user" != "" &&  "$ip" != ""  && "$path" != "" && "$venv" != "" ]]
        then
        echo "Enter the UCP password of user $user:"
        read -s pass
        sshpass -p "$pass" ssh -o StrictHostKeyChecking=no -t "$user@$ip" -t "cd $path;source $venv""/bin/activate; bash"
        #sshpass -p "$pass" ssh -o StrictHostKeyChecking=no -t "$user@$ip" "cd /home/saravanab" 2>/dev/null 
        fi
fi
