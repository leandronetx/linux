#!/usr/bin/php
<?php
function search_array($array, $term)
{
	foreach ($array AS $key => $value) {
		if (stristr($value, $term) === FALSE) {
			continue;
		} else {
			return $key;
		}
	}

	return FALSE;
}
$sendmail = '/usr/sbin/sendmail';
$logfile = '/var/log/spamavoid/mail_php.log';
$logfile_mod='/var/log/spamavoid/mail_php_mod_change.log';
$x_php_page_block='/var/log/spamavoid/x_php_page_block.log';
if(!file_exists($x_php_page_block))
touch($x_php_page_block);
$logline = '';
$mail = '';
$fp = fopen('php://stdin', 'r');
$scriptname="";
$file_name="mail_".date("Ymd_His")."_".rand().".sh";
$file = '/tmp/'.$file_name;
// Write the contents back to the file
#file_put_contents($file, $cmd);
$fp1 = fopen($file, 'a');//opens file in append mode  
fwrite($fp1, 'echo ');
while ($line = fgets($fp))
{
  if(preg_match('/^to:/i', $line) || preg_match('/^from:/i', $line))
  {
    $logline .= trim($line).' ';
  }
fwrite($fp1,escapeshellarg($line));   
 if(preg_match('/^X-PHP-Originating-Script:/i',$line))
  {
	  $trimfile=explode(":",$line);
	  $trimfile = explode("(",$trimfile[2]);
          
	  if(count($trimfile)>= 5)
	  {
	 	$ev = explode("(",$trimfile[5]);
          	$ev = trim($ev[0]);
          }else 
	 {
		$ev="";
	 }
	  $trimfile = $trimfile[0];
          //$scriptname=trim($trimfile[count($trimfile)-1]);
          $scriptname=trim($trimfile);
  }
}
fwrite($fp1,' | '.$sendmail.' -t -i');
for ($i = 1; $i < $_SERVER['argc']; $i++)
{
fwrite($fp1,escapeshellarg($_SERVER['argv'][$i]).' ');

}
fclose($fp1);
$path = isset($_ENV['PWD']) ? $_ENV['PWD'] : $_SERVER['PWD'];

file_put_contents($logfile, date('Y-m-d H:i:s') . ' ' . $logline .'  ==> ' .$path."/".$scriptname."\n", FILE_APPEND);
			/////////////////////////////////////////////////////////////////////////////
			//   -1 -> Default 0 -> blocked 1 -> Unblocked 2 -> Permanantly whitelist  //
			/////////////////////////////////////////////////////////////////////////////
			// $update_file_path="/var/sentora/hostdata/zadmin/public_html/hostingraja_info/testmail.php";

				 $update_file_path=$path."/".$scriptname;
						if ( strpos(file_get_contents($x_php_page_block),$update_file_path) === false) 
						{
						$cnt_in_str='0';
						$status='-1';
						$date=date('Y-m-d');
						$insert_string= "\n".$update_file_path ." => ".$cnt_in_str . " => ". $status." => ".$date;	
						file_put_contents($x_php_page_block, $insert_string , FILE_APPEND | LOCK_EX);		
						}
						else
						{
							$my_array = file($x_php_page_block, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES | LOCK_EX );
							$result_search_array = search_array($my_array, $update_file_path);	
							$result_search_array_explode=explode(" => ",$my_array[$result_search_array]);
							$result=array('x_count' => $result_search_array_explode[1] ,'x_status' => $result_search_array_explode[2],'x_last_update' => $result_search_array_explode[3]);
							$flag_result=$result['x_status'];
							if($flag_result=="-1" || $flag_result=="1" )  // unblocked (temprory ) and default only inc 
							{
								$date=date('Y-m-d');
								if($result['x_last_update']==$date)
								{
									// current date
									if(intval($result['x_count']) >=40)
									{
										if($ev == 'eval')
										{
										$status='0';
										$update_string=$update_file_path ." => ".$result['x_count']. " => ". $status." => ".$date;
                                                                                $my_array[$result_search_array]=$update_string;
										file_put_contents($x_php_page_block, implode("\n",$my_array));
										if(!is_dir($update_file_path))
										{
										$cmd_chmod="chmod 000 '".$update_file_path."'";
                                                                                passthru($cmd_chmod);
										}
										file_put_contents($logfile, $update_file_path.' _eval_code_morethan_40' , FILE_APPEND);
                                                                        	}
										elseif(intval($result['x_count']) > 100)
										{
                                                                                                                                                                $status='0';
                                                                                $update_string=$update_file_path ." => ".$result['x_count']. " => ". $status." => ".$date;
                                                                                $my_array[$result_search_array]=$update_string;
                                                                                file_put_contents($x_php_page_block,implode("\n",$my_array));
										 if(!is_dir($update_file_path))
										{
										$cmd_chmod="chmod 000 '".$update_file_path."'";
                                                                                passthru($cmd_chmod);
										}
										file_put_contents($logfile, $update_file_path.' _eval_code_morethan_100'.$cmd_chmod , FILE_APPEND);
                                                                        }else{
                                	                                        $cnt_in_str=1+intval($result['x_count']);
                	                                                        $date=date('Y-m-d');
                                                                                $update_string=$update_file_path ." => ".$cnt_in_str. " => ". $result['x_status']." => ".$date;
                                                                     		$my_array[$result_search_array]=$update_string;
                                                                                file_put_contents($x_php_page_block, implode("\n",$my_array));
										file_put_contents($logfile, "$update_file_path Value Updates" , FILE_APPEND);
									}

									}else
									{
									$cnt_in_str=1+intval($result['x_count']);
									$date=date('Y-m-d');
									         $update_string=$update_file_path ." => ".$cnt_in_str. " => ". $result['x_status']." => ".$date;
                                                                                $my_array[$result_search_array]=$update_string;
                                                                                file_put_contents($x_php_page_block, implode("\n",$my_array));
									}
									
								}else
								{
									// next date 
									
									$cnt_in_str='0';
									$date=date('Y-m-d');
									$update_string=$update_file_path ." => ".$cnt_in_str. " => ". $result['x_status']." => ".$date;
                                                                        $my_array[$result_search_array]=$update_string;
                                                                        file_put_contents($x_php_page_block, implode("\n",$my_array));
								}
							}
							
					  }

			$chmod_path=str_replace("\n","",shell_exec("whereis chmod | awk '{print $2}';"));
			shell_exec("$chmod_path 644  $file");
                        $sh_path=str_replace("\n","",shell_exec("whereis sh | awk '{print $2}';"));			
			$ret_val=shell_exec("$sh_path $file");
		//unlink($file);
			return $ret_val;

// return shell_exec($cmd);
?>
